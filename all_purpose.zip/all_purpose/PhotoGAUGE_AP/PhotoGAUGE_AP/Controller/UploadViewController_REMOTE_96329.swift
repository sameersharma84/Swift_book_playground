//
//  UploadViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 30/11/21.
//

import UIKit
import AWSS3


class UploadViewController: UIViewController {
    @IBOutlet var viewUploading: UIView!
    @IBOutlet var viewRetryUpload: UIView!
    @IBOutlet var viewNoUploads: UIView!
    @IBOutlet var viewLoader: UIView!
    @IBOutlet var lblVideoName: UILabel!
    @IBOutlet var lblVideoAdditionalDetails: UILabel!
    @IBOutlet weak var lblErrorMsg1: UILabel!
    @IBOutlet weak var lblErrorMsg2: UILabel!
    @IBOutlet weak var noInternetView: UIView!
    var videoLink: String = ""
    var videoData = VideoData(name: "", additionalDescription: "")
    var uploadInProgress = Bool()
    var isScreenLoaded: Bool = false
    var toastMessage = String()
    private var uploadedVideoUrl = ""
    private var progressRing: CircularProgressBar!
    var tempUpload: Uploads?
    var progress: Float = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        lblVideoName.text = videoData.name
        lblVideoAdditionalDetails.text = videoData.additionalDescription
        initialiseLoader()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.isScreenLoaded = true
        self.noInternetView.isHidden = true
        if !(viewLoader.layer.sublayers?.contains(progressRing) ?? false){
            viewLoader.layer.addSublayer(progressRing)}
        if !uploadInProgress {
            viewNoUploads.isHidden = false
        }else{
            viewNoUploads.isHidden = true
            updateUI()
        }
    }
    
    func initialiseLoader(){
        let xPosition = viewLoader.center.x - 90
        let yPosition = viewLoader.center.y
        let position = CGPoint(x: xPosition, y: yPosition)
        
        
        progressRing = CircularProgressBar(radius: 80, position: position, innerTrackColor: Color.themeBlueColor, outerTrackColor: .clear, lineWidth: 5)
        let helper = UploadHelper.sharedInstance
        helper.uploadUpdateDelegate = self
    }
    
    func updateErrorMsg() {
        if (self.isScreenLoaded) {
//            if (UploadHelper.sharedInstance.showSSLError) {
//                lblErrorMsg1.text = "You are not logged in to your network"
//                lblErrorMsg2.text = "Please login to your network and "
//            } else {
//                lblErrorMsg1.text = "Network is not available"
//                lblErrorMsg2.text = "Check your connection and "
//            }
        }
    }
    
    func updateUI() {
        Logger.debug("")
        if self.lblVideoName.text == "" {
            self.fetchUploadingScanInfo()
            //            if (self.showNetworkDisconnection) {
            //                self.updateErrorMsg()
            //                self.noInternetView.isHidden = false
            //                self.progressRing.removeFromSuperlayer()
            //    //            self.cancelUploadView.isHidden = true
            //    //            self.scanNewUnitBtn.isHidden = true
            //                //self.uploadStatusLbl.isHidden = true
            //                //self.scrollview.isScrollEnabled = true
            //            }
            //
        } else {
            DispatchQueue.main.async {
                if self.progress >= 1.0{
                    self.viewUploading.isHidden = true
//                    self.progressRing.removeFromSuperlayer()
                }else{
                    let newProgress = self.progress
                    self.progressRing.progress = CGFloat(Int(newProgress*100))
                    if !(self.viewLoader.layer.sublayers?.contains(self.progressRing) ?? false){
                        self.viewLoader.layer.addSublayer(self.progressRing)
                    }
                    self.viewUploading.isHidden = false
                }
            }
        }
    }
    
    func fetchUploadingScanInfo() {
        let partName: String = UserDefaults.standard.string(forKey: "uploadingPartName") ?? ""
        self.progress = UserDefaults.standard.float(forKey: "uploadProgress")
        self.lblVideoName.text = partName
        updateUI()
    }
    
    func showNetworkDisconnectionScreen() {
        if (self.isScreenLoaded) {
            self.updateErrorMsg()
            self.noInternetView.isHidden = false
            self.progressRing.removeFromSuperlayer()
//            self.cancelUploadView.isHidden = true
//            self.scanNewUnitBtn.isHidden = true
            //self.uploadStatusLbl.isHidden = true
            //self.scrollview.isScrollEnabled = true
//            if helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
//                UploadHelper.sharedInstance.queueUpload()
//            }
//            let subviews = helperGetAppDeleate().window?.subviews
//            if subviews!.contains(helperGetAppDeleate().snackBarView) {
//                helperGetAppDeleate().snackBarView.removeFromSuperview()
//            }
        }
    }
    
    func handleUploadCompletion(response:Any?, error: Error?){
        self.viewUploading.isHidden = true
        if let publicURL = response as? String{
            uploadedVideoUrl = publicURL
        }
    }
    
    //MARK: Actions
    @IBAction func btnViewResultsClicked(_ sender: UIButton){
//        let vc = ViewResultsViewController(nibName: "ViewResultsView", bundle: nil)
//        vc.publicURL = uploadedVideoUrl
//        self.navigationController?.navigationBar.isHidden = true
//        self.navigationController?.pushViewController(vc, animated: true)
        
//        let vc = AllUploadsViewController(nibName: "AllUploadsView", bundle: nil)
//        if let uploadData = tempUpload{
//            vc.arrayUploads = [uploadData]
//        }
//        self.navigationController?.navigationBar.isHidden = true
//        self.navigationController?.pushViewController(vc, animated: true)
        
        if helperGetAppDeleate().navigation.contains(helperGetAppDeleate().allUploadScreen){
            helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().allUploadScreen, animated: false)
        }else{
            helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
        }
//        helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
    }
    
    @IBAction func btnCameraClicked(_ sender: UIButton){
        let cameraStartScreen = CameraScreen()
        helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
        helperGetAppDeleate().hideActivityView()
    }
    
    @IBAction func dismissView(){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnRetryClicked(_ sender: Any) {
        Logger.debug("UploadScreen - Retry Connection Clicked")
        if !NetStatus.shared.isConnected {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Internet unavailable please check your network and try again")
        } else {
            if !helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                if !helperGetAppDeleate().isOffline {
                    //change
//                    self.showNetworkDisconnection = false
                    UploadHelper.sharedInstance.changeFromRetryToQueued()
//                    self.hideNetworkDisconnectionScreen()
                }
            }
        }
    }
}

extension UploadViewController: UploadUpdateDelegate {
    func textInfoUpdated(projectName: String, windowName: String, uploadCount: Int, totalUploadsCount: Int, progress: Float, location: String, isVideo: Bool) {
        //        self.isUploadCompleted = false
        self.progress = progress
        if projectName.contains("-"){
            let projectName = projectName.components(separatedBy: "-")
            self.lblVideoName.text = projectName[0]
        }
        if (self.isScreenLoaded) {
            self.updateUI()
        }
    }
    
    func uploadStartTimeUpdated(time: String, isVideo: Bool) {
        if (self.isScreenLoaded) {
            self.updateUI()
        }
    }
    
    func uploadSuccessUIUpdate(nwSpeedValue: String, uploadTimeValue: String, isVideo: Bool) {
        if (self.isScreenLoaded) {
            self.updateUI()
        }
    }
    
    func updateNetworkSpeed(speed: String) {
        
    }
    
    func percentageUpdated(uploadedImgCount: Int, totalImgCount: Int, progress: Float, isVideo: Bool) {
        let newProgress = progress
//        self.progressRing.progress = CGFloat(Int(newProgress*100))
        print(newProgress)
        
        
        if (self.isScreenLoaded) {
            self.progress = newProgress
            self.updateUI()
//            if !self.noInternetView.isHidden {
//                self.hideNetworkDisconnectionScreen()
//            }
        }
    }
}


