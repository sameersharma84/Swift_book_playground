//
//  UploadViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 30/11/21.
//

import UIKit
import AWSS3


class UploadViewController: UIViewController {
    @IBOutlet var viewUploading: UIView!
    @IBOutlet var viewRetryUpload: UIView!
    @IBOutlet var viewNoUploads: UIView!
    @IBOutlet var viewLoader: UIView!
    @IBOutlet var lblVideoName: UILabel!
    @IBOutlet var lblVideoAdditionalDetails: UILabel!
    @IBOutlet weak var lblErrorMsg1: UILabel!
    @IBOutlet weak var lblErrorMsg2: UILabel!
    @IBOutlet weak var noInternetView: UIView!
    var videoLink: String = ""
    var videoData = VideoData(name: "", additionalDescription: "")
    var uploadInProgress = Bool()
    var isScreenLoaded: Bool = false
    var toastMessage = String()
    private var uploadedVideoUrl = ""
    private var progressRing: CircularProgressBar!
    var tempUpload: Uploads?
    var progress: Float = 0.0
    var isUploadCompleted: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        lblVideoName.text = videoData.name
        lblVideoAdditionalDetails.text = videoData.additionalDescription
        initialiseLoader()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.uploadScreen
        self.isScreenLoaded = true
        //        self.noInternetView.isHidden = true
        if !(viewLoader.layer.sublayers?.contains(progressRing) ?? false){
            viewLoader.layer.addSublayer(progressRing)}
        if !uploadInProgress {
            viewNoUploads.isHidden = false
        }else{
            viewNoUploads.isHidden = true
            updateUI()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.none
    }
    
    func initialiseLoader(){
        let xPosition = viewLoader.center.x - 90
        let yPosition = viewLoader.center.y
        let position = CGPoint(x: xPosition, y: yPosition)
        
        
        progressRing = CircularProgressBar(radius: 80, position: position, innerTrackColor: Color.themeBlueColor, outerTrackColor: .clear, lineWidth: 5)
        let helper = UploadHelper.sharedInstance
        helper.uploadUpdateDelegate = self
    }
    
    func updateErrorMsg() {
        if (self.isScreenLoaded) {
//            if (UploadHelper.sharedInstance.showSSLError) {
//                lblErrorMsg1.text = "You are not logged in to your network"
//                lblErrorMsg2.text = "Please login to your network and "
//            } else {
//                lblErrorMsg1.text = "Network is not available"
//                lblErrorMsg2.text = "Check your connection and "
//            }
        }
    }
    
    func updateUI() {
        Logger.debug("")
        if self.lblVideoName.text == "" {
            self.fetchUploadingScanInfo()
            //            if (self.showNetworkDisconnection) {
            //                self.updateErrorMsg()
            //                self.noInternetView.isHidden = false
            //                self.progressRing.removeFromSuperlayer()
            //    //            self.cancelUploadView.isHidden = true
            //    //            self.scanNewUnitBtn.isHidden = true
            //                //self.uploadStatusLbl.isHidden = true
            //                //self.scrollview.isScrollEnabled = true
            //            }
            //
        } else {
            DispatchQueue.main.async {
                if self.progress >= 1.0{
                    self.viewUploading.isHidden = true
//                    self.progressRing.removeFromSuperlayer()
                }else{
                    let newProgress = self.progress
                    self.progressRing.progress = CGFloat(Int(newProgress*100))
                    if !(self.viewLoader.layer.sublayers?.contains(self.progressRing) ?? false){
                        self.viewLoader.layer.addSublayer(self.progressRing)
                    }
                    self.viewUploading.isHidden = false
                }
            }
        }
    }
    
    func fetchUploadingScanInfo() {
        let partName: String = UserDefaults.standard.string(forKey: "uploadingPartName") ?? ""
        self.progress = UserDefaults.standard.float(forKey: "uploadProgress")
        self.lblVideoName.text = partName
        updateUI()
    }
    
    func showNetworkDisconnectionScreen() {
        if (self.isScreenLoaded) {
            self.updateErrorMsg()
            self.noInternetView.isHidden = false
            self.progressRing.removeFromSuperlayer()
//            self.cancelUploadView.isHidden = true
//            self.scanNewUnitBtn.isHidden = true
            //self.uploadStatusLbl.isHidden = true
            //self.scrollview.isScrollEnabled = true
//            if helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
//                UploadHelper.sharedInstance.queueUpload()
//            }
//            let subviews = helperGetAppDeleate().window?.subviews
//            if subviews!.contains(helperGetAppDeleate().snackBarView) {
//                helperGetAppDeleate().snackBarView.removeFromSuperview()
//            }
        }
    }
    
    func handleUploadCompletion(response:Any?, error: Error?){
        self.viewUploading.isHidden = true
        if let publicURL = response as? String{
            uploadedVideoUrl = publicURL
        }
    }
    
    //MARK: Actions
    @IBAction func btnViewResultsClicked(_ sender: UIButton){
//        let vc = ViewResultsViewController(nibName: "ViewResultsView", bundle: nil)
//        vc.publicURL = uploadedVideoUrl
//        self.navigationController?.navigationBar.isHidden = true
//        self.navigationController?.pushViewController(vc, animated: true)
        
//        let vc = AllUploadsViewController(nibName: "AllUploadsView", bundle: nil)
//        if let uploadData = tempUpload{
//            vc.arrayUploads = [uploadData]
//        }
//        self.navigationController?.navigationBar.isHidden = true
//        self.navigationController?.pushViewController(vc, animated: true)
        
        if helperGetAppDeleate().navigation.contains(helperGetAppDeleate().allUploadScreen){
            helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().allUploadScreen, animated: false)
        }else{
            helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
        }
//        helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
    }
    
    @IBAction func btnCameraClicked(_ sender: UIButton){
        let cameraStartScreen = CameraScreen()
        helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
        helperGetAppDeleate().hideActivityView()
    }
    
    @IBAction func dismissView(){
        self.navigationController?.popViewController(animated: true)
    }
    
    ///UploadScreen specific Network changes handling
     func handleNetworkChange() {
         Logger.debug("Network Changed - Handle Network change called")
         if NetStatus.shared.isConnected {
             Logger.debug("Network Connected BACK")
             DispatchQueue.main.async {
                
                //SURBHI - HANDLE UPLOAD SCREEN FOR NET CONNECTION BACK
                
                 //show the upload progress
//                if !(self.isUploadCompleted) {
//                    UploadHelper.sharedInstance.showSSLError = false
//                    self.noInternetView.isHidden = true
//                    self.view.layer.addSublayer(self.progressRing)
//                    let newProgress = Int(self.progress * 100)
//                    self.progressRing.progress = CGFloat(newProgress)
//
//                    if !helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
//                        if !helperGetAppDeleate().isOffline {
//                            if helperGetAppDeleate().allUploadScreen.currentScreen == .uploadScreen {
//                                UploadHelper.sharedInstance.changeFromRetryToQueued()
//                            }
//                        }
//                    }
//                }
             }
         } else {
             Logger.debug("Network Disconnected")
             DispatchQueue.main.async {
                 
                 if (self.isUploadCompleted || Int(self.progress * 100) == 100) {
                     //If network is disconnected and upload was completed, don't change the view
                     return
                 } else {
                    //SURBHI - HANDLE ERROR SCREEN FOR NET DISCONNECTION
                    
                     //If network is disconnected and upload was not completed,
                     //show the error message and No Internet view
//                     if !(self.isUploadCompleted) {
//                         UploadHelper.sharedInstance.showSSLError = false
//                         self.updateErrorMsg()
//                         self.noInternetView.isHidden = false
//                         self.progressRing.removeFromSuperlayer()
//                         let subviews = helperGetAppDeleate().window?.subviews
//                         if subviews!.contains(helperGetAppDeleate().snackBarView) {
//                             helperGetAppDeleate().snackBarView.removeFromSuperview()
//                         }
//                     } else {
//                         //Show retry screen for the first time when upload is interrupted
//                         let retryScreen = helperGetAppDeleate().retryScreen
//                         retryScreen.fromPartsScreen = false
//                         retryScreen.fromScanScreen = false
//                         retryScreen.fromUploadScreen = true
//                         retryScreen.fromUpdateScreen = false
//                         retryScreen.fromCameraScreen = self.fromCameraScreen
//                         retryScreen.handleBackClick = true
//                         if !(helperGetAppDeleate().navigation.viewControllers.contains(retryScreen)){
//                             helperGetAppDeleate().navigation.pushViewController(retryScreen, animated: true)
//                         }
//                     }
                 }
             }
         }
     }
}

extension UploadViewController: UploadUpdateDelegate {
    func textInfoUpdated(projectName: String, windowName: String, uploadCount: Int, totalUploadsCount: Int, progress: Float, location: String, isVideo: Bool) {
        
        print("PROJEVT NAME: \(projectName)")
        self.isUploadCompleted = false
        self.progress = progress
        self.lblVideoName.text = projectName
//        if projectName.contains("-"){
//            let projectName = projectName.components(separatedBy: "-")
//            self.lblVideoName.text = projectName[0]
//        }
        if (self.isScreenLoaded) {
            self.updateUI()
        }
    }
    
    func uploadStartTimeUpdated(time: String, isVideo: Bool) {
        if (self.isScreenLoaded) {
            self.updateUI()
        }
    }
    
    func uploadSuccessUIUpdate(nwSpeedValue: String, uploadTimeValue: String, isVideo: Bool) {
        self.isUploadCompleted = true
        if (self.isScreenLoaded) {
            self.updateUI()
        }
    }
    
    func updateNetworkSpeed(speed: String) {
        
    }
    
    func percentageUpdated(uploadedImgCount: Int, totalImgCount: Int, progress: Float, isVideo: Bool) {
        let newProgress = progress
//        self.progressRing.progress = CGFloat(Int(newProgress*100))
        print(newProgress)
        
        
        if (self.isScreenLoaded) {
            self.progress = newProgress
            self.updateUI()
            
            
            //            if !self.noInternetView.isHidden {
            //                self.hideNetworkDisconnectionScreen()
            //            }
        }
    }
}


