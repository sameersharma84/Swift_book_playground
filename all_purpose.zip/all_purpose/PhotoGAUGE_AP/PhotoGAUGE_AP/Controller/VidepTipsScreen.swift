//
//  VidepTipsScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 10/01/22.
//

import UIKit
import AVFoundation
import AVKit

class VidepTipsScreen: UIViewController {

    @IBOutlet weak var videoPlayerView: UIView!
    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var closeBtn: UIButton!
    

    var playerViewController = AVPlayerViewController()
    var player = AVPlayer()
    var playerLayer = AVPlayerLayer()
    var videoURLString = String()
    var isVideoPlaying = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadPlayer()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer.frame = videoPlayerView.bounds
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        NotificationCenter.default.addObserver(self, selector: #selector(videoDidEnd), name:
        NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        AppUtility.lockOrientation(.portrait)
        player.pause()
    }
    
    @IBAction func playPausePressed(_ sender: UIButton) {
        if isVideoPlaying {
            player.pause()
            sender.isSelected = !sender.isSelected
        }else{
            player.play()
            sender.isSelected = !sender.isSelected
        }
        isVideoPlaying = !isVideoPlaying
    }
    
    @IBAction func closePlayer(_ sender: UIButton) {
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    
    @objc func videoDidEnd(notification: NSNotification) {
        print("video ended")
        playPausePressed(playBtn)
        loadPlayer()
    }
    
    func loadPlayer() {
        self.playerLayer.removeFromSuperlayer()
        let filepath: String? = Bundle.main.path(forResource: "dummy_video", ofType: "mp4")
        if let videoPath = filepath {
            let url = URL.init(fileURLWithPath: videoPath)
            player = AVPlayer(url: url)
            playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = self.view.bounds
            playerLayer.videoGravity = .resize
            videoPlayerView.layer.addSublayer(playerLayer)
            videoPlayerView.layer.addSublayer(closeBtn.layer)
        }
    }
}
