//
//  HomeViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 02/12/21.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var gifView: UIImageView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var phoneImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.homeScreen
        if let type = UserSession.shared.getUserSelection(){
            descriptionLabel.text = "Record a video of the object & get \(type)"
            phoneImg.isHidden = true
            gifView.isHidden = true
            if type == str_measurements {
                phoneImg.isHidden = false
            }else if type == str_3d_model {
                gifView.isHidden = false
                gifView.loadGif(name: "DigitalTwinGif")
            }
        }
        DispatchQueue.main.async {
            helperGetAppDeleate().allUploadScreen.setupUploadTasks()
            helperGetAppDeleate().allUploadScreen.loadAllParts()
        }
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.none
    }

    @IBAction func shootPressed(_ sender: UIButton) {
        if UserSession.shared.isDontShowScreenTipsScreenSet() {
            if helperGetAppDeleate().isMeasurement {
                if UserSession.shared.isDontShowTargetScreenSet() {
                    let cameraStartScreen = CameraScreen()
                    cameraStartScreen.fromDownloadScreen = false
                    helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
                }else{
                    helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().targetScreen, animated: true)
                }
            }else{
                let cameraStartScreen = CameraScreen()
                cameraStartScreen.fromDownloadScreen = false
                helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
            }
        }else{
            let tipsScreen = ScanTipsViewController()
            helperGetAppDeleate().navigation.pushViewController(tipsScreen, animated: true)
        }
        
    }
    
    @IBAction func videoTipsPressed(_ sender: UIButton) {
        let tipsScreen = ScanTipsViewController()
        helperGetAppDeleate().navigation.pushViewController(tipsScreen, animated: true)
    }
}
