//
//  FilterViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 24/02/22.
//

import UIKit

protocol FilterData: NSObject{
    func filterData(categories: [Category], date: Dates?)
}

enum Category: String{
    case Measurements = "Measurements"
    case CAD = "CAD"
    case Model = "3D Model"
}

enum Dates: String{
    case today = "Today"
    case yesterday = "Yesterday"
    case lastWeek = "Last Week"
    case lastMonth = "Last Month"
}

class FilterViewController: UIViewController {
    @IBOutlet var btnCategories: [UIButton]!
    @IBOutlet var btnDates: [UIButton]!
    @IBOutlet var btnDatesConstraints: [NSLayoutConstraint]!
    @IBOutlet var btnCategoriesConstraints: [NSLayoutConstraint]!
    weak var delegate: FilterData?
    var filterCategories = [Category]()
    var filterDate: Dates?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if filterCategories.count > 0 {
            for category in filterCategories {
                for index in btnCategories.indices {
                    if btnCategories[index].title(for: .normal) == category.rawValue {
                        btnCategories[index].isSelected = true
                        btnCategories[index].buttonSize(iconName: "Icon checkmark", widthConstraints: btnCategoriesConstraints[index])
                        
                    }
                }
            }
        }
        if let date = filterDate {
            for index in btnDates.indices {
                if btnDates[index].title(for: .normal) == date.rawValue {
                    btnDates[index].isSelected = true
                    btnDates[index].buttonSize(iconName: "Icon checkmark", widthConstraints: btnDatesConstraints[index])
                }
            }
        }
    }
    
    func resetDates(){
        for index in btnDates.indices{
            let button = btnDates[index]
            button.buttonSize(iconName: "", widthConstraints: btnDatesConstraints[index])
            button.isSelected = false
        }
    }
    
    @IBAction func dismissFilter(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnCategoryClicked(_ sender: UIButton){
        var imageTitle = ""
        if sender.isSelected{
            imageTitle = ""
        }else{
            imageTitle = "Icon checkmark"
        }
        for index in btnCategories.indices {
            let button = btnCategories[index]
            if button.tag == sender.tag {
                button.buttonSize(iconName: imageTitle, widthConstraints: btnCategoriesConstraints[index])
            }
        }
        
        sender.isSelected = !sender.isSelected
        view.layoutSubviews()
    }
    
    @IBAction func btnDateClicked(_ sender: UIButton){
        resetDates()
        for index in btnDates.indices {
            let button = btnDates[index]
            if button.tag == sender.tag {
                button.buttonSize(iconName: "Icon checkmark", widthConstraints: btnDatesConstraints[index])
                button.isSelected = true
            }
        }
        view.layoutSubviews()
    }
    
    @IBAction func btnApplyFilterClicked(_ sender: UIButton){
        var categorySelected = [Category]()
        let dateSelected: Dates?
        
        
        if btnCategories[0].isSelected{
            categorySelected.append(.Measurements)
        }
        if btnCategories[1].isSelected{
            categorySelected.append(.CAD)
        }
        if btnCategories[2].isSelected{
            categorySelected.append(.Model)
        }
        
        if btnDates[0].isSelected{
            dateSelected = .today
        }else if btnDates[1].isSelected{
            dateSelected = .yesterday
        }else if btnDates[2].isSelected {
            dateSelected = .lastWeek
        }else if btnDates[3].isSelected{
            dateSelected = .lastMonth
        }else{
            dateSelected = nil
        }
        
        delegate?.filterData(categories: categorySelected, date: dateSelected)
        self.dismiss(animated: true, completion: nil)
    }
}
