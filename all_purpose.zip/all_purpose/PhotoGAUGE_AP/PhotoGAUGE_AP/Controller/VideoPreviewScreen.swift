//
//  VideoPreviewScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 03/12/21.
//

import UIKit
import AVFoundation
import AVKit

class VideoPreviewScreen: UIViewController {

    var playerViewController = AVPlayerViewController()
    var player = AVPlayer()
    var playerLayer = AVPlayerLayer()
    var isVideoPlaying = false
    var fromCameraScreen: Bool = false
    var videoURLString = String()
    var videoSize = Int64()
    var newFileURLStr = String()
    @IBOutlet weak var playBtn: UIButton!
    
    //parameters to be sent to Addlabelscreen
    var customAlbumName : String!
    var timeStampArr = [String]()
    var videoTimeElapased = Int()
    var dateStrToSave : String = ""
    var fileName = String()
    var orientation: Int = 0
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var retryBtn: UIButton!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var consTopVideoView: NSLayoutConstraint!
    
    var delegateVar: VideoCompletion?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if !fromCameraScreen {
            retryBtn.isHidden = true
            nextBtn.isHidden = true
        }else{
            retryBtn.isHidden = false
            nextBtn.isHidden = false
        }
        resetConstraintForLandscape()
        loadPlayer()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer.frame = videoView.bounds
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        LogConfig.logD(message:"Video Preview Screen - view will Disappear", displayToThirdParty: true)
//        AppUtility.lockOrientation(.portrait)
        player.pause()
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        LogConfig.logD(message:"Video Preview Screen - view will appear", displayToThirdParty: true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        NotificationCenter.default.addObserver(self, selector: #selector(videoDidEnd), name:
        NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: nil)
    }
    
    func resetConstraintForLandscape(){
        let width = UIScreen.main.bounds.width
        let height = UIScreen.main.bounds.height
        let window = UIApplication.shared.windows.first
        var topPadding = window!.safeAreaInsets.left
        var heightOfView = 0.0
        var consValue = 0.0
        if width>height{
            heightOfView = height*9/16
            consValue = (width-heightOfView)/2
        }else{
            topPadding = window!.safeAreaInsets.top
            heightOfView = width*9/16
            consValue = (height-heightOfView)/2
        }
        switch(orientation) {
        case 3, 4:
            consTopVideoView.constant = consValue - topPadding
            break
        default:
            break
        }
    }
    
    @IBAction func playPressed(_ sender: UIButton) {
        if isVideoPlaying {
            player.pause()
            sender.isSelected = !sender.isSelected
        }else{
            player.play()
            sender.isSelected = !sender.isSelected
        }
        isVideoPlaying = !isVideoPlaying
    }
    
    @IBAction func nextPressed(_ sender: UIButton) {
        AppUtility.lockOrientation(.portrait)
        if !fromCameraScreen {
            helperGetAppDeleate().navigation.popViewController(animated: true)
        } else {
//            self.delegateVar?.saveVideoAfterPreview()
            
            let labelScreen = helperGetAppDeleate().labelScreen
            labelScreen.customAlbumName = self.customAlbumName
            labelScreen.timeStampArr = self.timeStampArr
            labelScreen.videoTimeElapased = self.videoTimeElapased
            labelScreen.dateStrToSave = self.dateStrToSave
            labelScreen.videoLink = videoURLString
            labelScreen.videoSize = videoSize
            labelScreen.fileName = fileName
            labelScreen.newFileURLStr = newFileURLStr
            if helperGetAppDeleate().navigation.contains(labelScreen){
                helperGetAppDeleate().navigation.popToViewController(labelScreen, animated: false)
            }else{
                helperGetAppDeleate().makeRootController(controller: labelScreen)
            }
//            helperGetAppDeleate().navigation.pushViewController(labelScreen, animated: true)
        }
    }
    
    @IBAction func retryPressed(_ sender: UIButton) {
        self.delegateVar?.retryShoot()
        AppUtility.lockOrientation(.all)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @objc func videoDidEnd(notification: NSNotification) {
        print("video ended")
        playPressed(playBtn)
        loadPlayer()
    }
    
    func loadPlayer() {
        LogConfig.logD(message:"LOAD PLAYER \(videoURLString)", displayToThirdParty: true)
        playerLayer.removeFromSuperlayer()
        guard let url = URL(string: videoURLString)
        else {
            LogConfig.logD(message:"LOAD PLAYER - ERROR OCCURED", displayToThirdParty: true)
            return
        }
        // Create an AVPlayer, passing it the HTTP Live Streaming URL.
        player = AVPlayer(url: url)
        
        playerLayer = AVPlayerLayer(player: player)
        playerLayer.videoGravity = .resize
        videoView.layer.addSublayer(playerLayer)
    }
}
