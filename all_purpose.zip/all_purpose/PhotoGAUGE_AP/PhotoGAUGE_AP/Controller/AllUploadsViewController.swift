//
//  AllUploadsViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 10/12/21.
//

import UIKit
import PGMeasure
import SnackBar_swift
import QuickLook
import ARKit

struct cellData {
    var isUploaded =  Bool()
    var title = String()
    var scanDetails = [String : Any]()
    var partDetails = [String : Any]()
    var latestShootTime = String()
}

enum Screens {
    case homeScreen
    case allUploadScreen
    case uploadScreen
    case addLabelSceen
    case printTargetScreen
    case none
}


class AllUploadsViewController: UIViewController {
    
    @IBOutlet weak var screenTitle: UILabel!
    @IBOutlet var tblUploads: UITableView!
    @IBOutlet var logoutView: UIView!
    @IBOutlet weak var logoutDialogView: UIView!
    @IBOutlet weak var lblLogoutText: UILabel!
    @IBOutlet var noNetworkView: UIView!
    @IBOutlet var noInternetkView: UIView!
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet weak var searchBtn: UIButton!
    @IBOutlet var btnFilters: [UIButton]!
    @IBOutlet var btnFilterConstraints: [NSLayoutConstraint]!
    @IBOutlet var viewFilters: UIView!
    @IBOutlet weak var fixedCameraBtn: UIButton!
    
    let searchController = UISearchController(searchResultsController: nil)
    var isSearch: Bool = false
    var filterCategories = [Category]()
    var filterDate: Dates?
    @IBOutlet weak var noResultsView: UIView!
    
    @IBOutlet weak var lblLogoutTitle: UILabel!
    //SideOut Menu
    private var sideMenuViewController: SideMenuViewController!
    private var sideMenuShadowView: UIView!
    private var sideMenuRevealWidth: CGFloat = 300
    private let paddingForRotation: CGFloat = 150
    private var isExpanded: Bool = false
    private var draggingIsEnabled: Bool = false
    private var panBaseLocation: CGFloat = 0.0
    private var sideMenuTrailingConstraint: NSLayoutConstraint!
    private var revealSideMenuOnTop: Bool = true
    var gestureEnabled: Bool = true
    
    var arrayUploads = [PartsDatum]()
    var arrayPartDict = [[String: Any]]()
    var tableData = [cellData]()
    var filteredData = [Dictionary<String, Any>]()
    var sections = Dictionary<String, Array<Dictionary<String, Any>>>()
    var sortedSections = [String]()
    var currentScreen: Screens = Screens.none
    var firstLoad: Bool = true
    var etagTimer : Timer?
    var actionButton : ActionButton!
    @IBOutlet weak var noShootsFoundView: UIStackView!
    @IBOutlet weak var lblNoRecordsFoundDescription: UILabel!
    
    var isUserInteractingWithMyUplodsPageFunctionalities : Bool = false
    var isFromUploadScreen: Bool = true
    
    @IBOutlet weak var btnHeaderPlus: UIButton!
    var uploadingProgressValue : Double = 0.01
    var isFromAddLabelScreen: Bool = false
    
    var timeStampArr = [String]()
    var arrMeasurementSessionFiles = [URL]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
#if AVATAR
        self.screenTitle.text = "My Avatars"
        self.addCameraShootButton(width: 150, height: 70)
        self.fixedCameraBtn.isHidden = true
#elseif ARKIT
        self.screenTitle.text = "My Uploads"
        self.fixedCameraBtn.isHidden = false
#else
        self.screenTitle.text = "My Uploads"
        self.addCameraShootButton(width: 150, height: 70)
        self.fixedCameraBtn.isHidden = true
#endif
        
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        registerTableCell()
        setupUploadTasks()
        initSideOutMenu()
        
        if etagTimer == nil {
            startEtagTimer()
        }
        _ = getETagDelegate()
    }
    
    func addCameraShootButton(width:Int,height:Int){
        
        let threeDModel =  ActionButtonItem(title: "3D Model", image: UIImage.init(named: "floating_btn_3d"))
        threeDModel.action = { action in
            self.actionButton.toggleMenu()
            UserSession.shared.set(userSelection: str_3d_model)
            helperGetAppDeleate().isMeasurement = false
            self.goToVideoShootScreen()
        }
        
        let measurements = ActionButtonItem(title: "Measurements", image: UIImage.init(named: "floating_btn_measurement"))
        measurements.action = { item in self.view.backgroundColor = UIColor.red }
        measurements.action = { action in
            self.actionButton.toggleMenu()
            helperGetAppDeleate().isMeasurement = true
            UserSession.shared.set(userSelection: str_measurements)
            self.goToVideoShootScreen()
        }
        
        
        actionButton = ActionButton(attachedToView: self.view, items: [measurements, threeDModel],width:width,height:height)
        if width == 70 {
            actionButton.setImage(UIImage.init(named: "floating_btn_camera"), forState: .normal)
        }else{
            actionButton.setImage(UIImage.init(named: "Camera transition"), forState: .normal)
        }
        actionButton.backgroundColor = .clear
        actionButton.action = { button in button.toggleMenu()}
        
    }
    
    @IBAction func onClickHeaderPlusIcon(_ sender: Any) {
        self.chooseMeasurmentOr3DModel()
        //self.goToVideoShootScreen()
    }
    
    func goToVideoShootScreen(){
        if UserSession.shared.isDontShowScreenTipsScreenSet() {
            if helperGetAppDeleate().isMeasurement {
                if UserSession.shared.isDontShowTargetScreenSet() {
                    let cameraStartScreen = CameraScreen()
                    cameraStartScreen.fromDownloadScreen = false
                    helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
                }else{
                    helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().targetScreen, animated: true)
                }
            }else{
                let cameraStartScreen = CameraScreen()
                cameraStartScreen.fromDownloadScreen = false
                helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
            }
        }else{
            let tipsScreen = ScanTipsViewController()
            helperGetAppDeleate().navigation.pushViewController(tipsScreen, animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
        LogConfig.logD(message:"VIEW WILL APPEAR", displayToThirdParty: true)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.allUploadScreen
        if isFromUploadScreen{
            dismissAllFilter()
        }
        if UserSession.shared.getUserData() != nil && UserSession.shared.getUserPartsCount() > 0 && UserSession.shared.getIsAllPartsRequestRunning() {
            helperGetAppDeleate().showActivityView()
        }else{
            //if db count >= getuserpartcount do loading
            loadAllParts()
            //else -> getall parts again from API
        }
        
        handleNetworkChange()
        dismissView(self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
        LogConfig.logD(message:"VIEW WILL DIS APPEAR", displayToThirdParty: true)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.none
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        sideMenuViewController.loadSideMenu()
        UserDefaults.standard.addObserver(self, forKeyPath: kVideoUploadingStart, options: [.new], context: nil)
        UserDefaults.standard.addObserver(self, forKeyPath: kVideoUploadingEnd, options: [.new], context: nil)
        UserDefaults.standard.addObserver(self, forKeyPath: kVideoUploadingPercentage, options: [.new], context: nil)
        
        debugPrint("Progress Value =====",self.uploadingProgressValue)
        
        if self.isFromAddLabelScreen {
            self.isFromAddLabelScreen = false
            PGSnackBar.make(in: self.view, message: str_processing_upload, duration: .lengthLong).show()
        }
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        UserDefaults.standard.removeObserver(self, forKeyPath: kVideoUploadingStart)
        UserDefaults.standard.removeObserver(self, forKeyPath: kVideoUploadingEnd)
        UserDefaults.standard.removeObserver(self, forKeyPath: kVideoUploadingPercentage)
    }
    
    
    // Keep the state of the side menu (expanded or collapse) in rotation
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate { _ in
            if self.revealSideMenuOnTop {
                self.sideMenuTrailingConstraint.constant = self.isExpanded ? 0 : (-self.sideMenuRevealWidth - self.paddingForRotation)
            }
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        guard let change = change, object != nil else { return }
        if keyPath == kVideoUploadingStart {
            
            DispatchQueue.main.async {
                debugPrint("Video Uploading Start========",change[NSKeyValueChangeKey.newKey] ?? "")
                if let value =  UserDefaults.standard.object(forKey: kVideoUploadingStart) as? String, value != "" {
                    self.uploadingProgressValue = 0.005
                    PGSnackBar.make(in: self.view, message: str_processing_upload, duration: .lengthLong).show()
                }
            }
        }else if keyPath == kVideoUploadingEnd {
            DispatchQueue.main.async {
                debugPrint("Video Uplooading End ==========",change[NSKeyValueChangeKey.newKey] ?? "")
                if let value =  UserDefaults.standard.object(forKey: kVideoUploadingEnd) as? String, value != "" {
                    self.uploadingProgressValue = 0
                    self.tblUploads.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: .none)
                }
            }
        }else if keyPath == kVideoUploadingPercentage {
            DispatchQueue.main.async {
                if let progressValue = change[NSKeyValueChangeKey.newKey] as? Double {
                    self.uploadingProgressValue = progressValue
                    if self.uploadingProgressValue == 0{
                        self.uploadingProgressValue = 0.005
                    }
                    self.tblUploads.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: .none)
                }
                
                debugPrint("Video Uploading Percentage =======",change[NSKeyValueChangeKey.newKey] ?? "")
            }
        }
    }
    
    
    func initSideOutMenu(){
        self.sideMenuShadowView = UIView(frame: self.view.bounds)
        self.sideMenuShadowView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.sideMenuShadowView.backgroundColor = .black
        self.sideMenuShadowView.alpha = 0.0
        //        self.tblUploads.bringSubviewToFront(sideMenuShadowView)
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(TapGestureRecognizer))
        tapGestureRecognizer.numberOfTapsRequired = 1
        tapGestureRecognizer.delegate = self
        //        view.addGestureRecognizer(tapGestureRecognizer)
        if self.revealSideMenuOnTop {
            view.insertSubview(self.sideMenuShadowView, at: 1)
            sideMenuShadowView.addGestureRecognizer(tapGestureRecognizer)
        }
        
        // Side Menu
        self.sideMenuViewController = SideMenuViewController(nibName: "SlideOutMenuView", bundle: nil)
        self.sideMenuViewController.defaultHighlightedCell = 0 // Default Highlighted Cell
        self.sideMenuViewController.delegate = self
        view.insertSubview(self.sideMenuViewController!.view, at: self.revealSideMenuOnTop ? 2 : 0)
        addChild(self.sideMenuViewController!)
        self.sideMenuViewController!.didMove(toParent: self)
        //        self.view.bringSubviewToFront(sideMenuViewController.view)
        // Side Menu AutoLayout
        
        self.sideMenuViewController.view.translatesAutoresizingMaskIntoConstraints = false
        
        if self.revealSideMenuOnTop {
            self.sideMenuTrailingConstraint = self.sideMenuViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: -self.sideMenuRevealWidth - self.paddingForRotation)
            self.sideMenuTrailingConstraint.isActive = true
        }
        NSLayoutConstraint.activate([
            self.sideMenuViewController.view.widthAnchor.constraint(equalToConstant: self.sideMenuRevealWidth),
            self.sideMenuViewController.view.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
            self.sideMenuViewController.view.topAnchor.constraint(equalTo: view.topAnchor),
            self.sideMenuViewController.view.heightAnchor.constraint(equalToConstant: view.frame.height)
        ])
        
        // Side Menu Gestures
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture))
        panGestureRecognizer.delegate = self
        view.addGestureRecognizer(panGestureRecognizer)
    }
    
    
    func loadAllParts(){
        if NetStatus.shared.isConnected {
            LogConfig.logD(message:"Network Connected - Get All part API", displayToThirdParty: true)
            let sessionData = UserSession.shared
            if (sessionData.getUserData() != nil){
                if sessionData.isFirstLoadOfMyUploads() ?? true {
                    callAllPartsApi()
                    sessionData.setFirstLoadOfMyUploadScreen()
                }else{
                    setupScanDetails()
                }
            }else{
                setupScanDetails()
            }
        }else{
            LogConfig.logD(message:"Network NotConnected", displayToThirdParty: true)
            setupScanDetails()
        }
    }
    
    func registerTableCell(){
        tblUploads.tableFooterView = UIView()
        tblUploads.register(UINib(nibName: "UploadCellView", bundle: nil), forCellReuseIdentifier: "UploadCell")
        tblUploads.dataSource = self
        tblUploads.delegate = self
        tblUploads.reloadData()
    }
    
    func callAllPartsApi(){
        if helperGetAppDeleate().allUploadScreen.currentScreen ==  Screens.allUploadScreen{
            helperGetAppDeleate().showActivityView()
        }
        UserSession.shared.setAllPartsRequestRunning(status: true)
        APIClient.delegateAllParts = self
        APIClient.getAllParts()
    }
    
    func setupUploadTasks() {
        
        UploadHelper.sharedInstance.uploadUpdateDelegate = UploadHelper.sharedInstance.uploadScreen
        //ask Ellyn
        //        UploadHelper.sharedInstance.pushCopyScreen = false
        
        NetStatus.shared.netStatusChangeHandler = {
            DispatchQueue.main.async { [unowned self] in
                handleScreenSpecificNetworkChange()
            }
        }
        NetStatus.shared.startMonitoring()
        
        if NetStatus.shared.isConnected {
            DispatchQueue.main.async {
                if !helperGetAppDeleate().isOffline {
                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                        LogConfig.logD(message:"GetUploading called", displayToThirdParty: true)
                        UploadHelper.sharedInstance.getUploadingScan()
                    }
                }
            }
        }
    }
    
    func handleScreenSpecificNetworkChange() {
        
        LogConfig.logD(message:"handleScreenSpecificNetworkChange : ALL UPLOADS SCREEN", displayToThirdParty: true)
        if !NetStatus.shared.isConnected {
            helperGetAppDeleate().isOffline = true
            DispatchQueue.main.async {
                if helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                    UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                }
                self.firstLoad = false
            }
        } else {
            helperGetAppDeleate().isOffline = false
            DispatchQueue.main.async {
                if self.currentScreen == .allUploadScreen {
                    if self.firstLoad {
                        self.firstLoad = false
                        if !helperGetAppDeleate().isOffline {
                            LogConfig.logD(message:"GetUploading called", displayToThirdParty: true)
                            UploadHelper.sharedInstance.getUploadingScan()
                        }
                    }
                }
                self.firstLoad = false
            }
        }
        
        switch self.currentScreen {
        case .allUploadScreen:
            self.handleNetworkChange()
            break
        case .uploadScreen:
            helperGetAppDeleate().uploadScreen.handleNetworkChange()
            break
        case .addLabelSceen:
            helperGetAppDeleate().labelScreen.handleNetworkChange()
            break
        case .none:
            break
        case .homeScreen:
            break
        case .printTargetScreen:
            break
        }
        
        self.setupScanDetails()
    }
    
    func handleNetworkChange() {
        LogConfig.logD(message:"Network Changed - Handle Network change called", displayToThirdParty: true)
        if !NetStatus.shared.isConnected {
            noNetworkView.isHidden = false
            LogConfig.logD(message:"NO INTERNET", displayToThirdParty: true)
            UploadHelper.sharedInstance.timer.invalidate()
        }else{
            LogConfig.logD(message:"NETWORK CONNECTED", displayToThirdParty: true)
            if !NetStatus.shared.isInternetAvailable{
                noInternetkView.isHidden = false
            }else{
                noNetworkView.isHidden = true
                noInternetkView.isHidden = true
                if !helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                    if !helperGetAppDeleate().isOffline {
                        UploadHelper.sharedInstance.videoFileName = ""
                        UploadHelper.sharedInstance.changeFromRetryToQueued()
                    }
                }
            }
        }
    }
    
    func openUploadScreen(){
        if  helperGetAppDeleate().navigation.viewControllers.contains(UploadHelper.sharedInstance.uploadScreen!){
            helperGetAppDeleate().navigation.popToViewController(UploadHelper.sharedInstance.uploadScreen!, animated: false)
        }else{
            helperGetAppDeleate().navigation.pushViewController(UploadHelper.sharedInstance.uploadScreen!, animated: false)
        }
    }
    
    func openUploadDetailsScreen(part: [String: Any], status: String,link: String, date: String, desc: String){
        let uploadDetails = UploadDetailsViewController(nibName: "UploadDetailsView", bundle: nil)
        uploadDetails.publicURL = link
        uploadDetails.status = status
        uploadDetails.uploadDate = date
        uploadDetails.allDetails = part
        uploadDetails.partName = part[kPartName] as! String
        (desc != "") ? (uploadDetails.additionalDetails = part[kPartDesc] as! String) : (uploadDetails.additionalDetails = "-")
        //Disabling details view for Vallourec build
        helperGetAppDeleate().navigation.pushViewController(uploadDetails, animated: false)
    }
    
    func resetDefaults() {
        let environment = UserDefaults.standard.value(forKey: kEnvironment)
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()
        let guestUserData = UserSession.shared.getGuestUserData()
        dictionary.keys.forEach { key in
            if key != "userLoginDetail"{
                defaults.removeObject(forKey: key)
            }
        }
        if let guestData = guestUserData {
            UserSession.shared.setGuestUserData(data: guestData)
        }
        UserDefaults.standard.set(false, forKey: kLoggedIn)
        UserDefaults.standard.set(false, forKey: kHasAllParts)
        UserDefaults.standard.setValue(environment, forKey: kEnvironment)
        UserDefaults.standard.removeObject(forKey: kNoParts)
    }
    
    func deleteAllScanFiles() {
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            for eachUrl in fileURLs{
                let urlString = eachUrl.absoluteString
                let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
                let documentsDirectory = paths[0] as String
                
                let fileName = urlString.components(separatedBy: documentsDirectory)
                if fileName[1] != "/parts.sqlite3" && fileName[1] != "/logFile.txt"{
                    if fileManager.fileExists(atPath: eachUrl.path) {
                        try? fileManager.removeItem(at: eachUrl)
                        LogConfig.logD(message:"Removed SCANs FOLDER from Local Directory", displayToThirdParty: true)
                    }
                }
            }
        } catch {
            LogConfig.logE(message:"Error while enumerating files \(documentsURL.path): \(error.localizedDescription)", displayToThirdParty: true)
        }
    }
    
    //MARK: Actions
    @IBAction func openCamera(_ sender: UIButton) {
#if ARKIT
        showFromFramework()
#else
        showCustomCamera()
#endif
    }
    
    func showCustomCamera() {
        if helperGetAppDeleate().isMeasurement {
            if UserSession.shared.isDontShowTargetScreenSet() {
                let cameraStartScreen = CameraScreen()
                cameraStartScreen.fromDownloadScreen = false
                helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
            }else{
                if  helperGetAppDeleate().navigation.viewControllers.contains(helperGetAppDeleate().targetScreen){
                    helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().targetScreen, animated: false)

                }else{
                    helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().targetScreen, animated: true)
                }
            }
        }else{
            let cameraStartScreen = CameraScreen()
            cameraStartScreen.fromDownloadScreen = false
            helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
        }
        helperGetAppDeleate().hideActivityView()
    }
    
    func showFromFramework()
    {
        UserSession.shared.arrSavedVideos = []
        let measureController = MeasureController()
        measureController.modalPresentationStyle = .fullScreen
        measureController.onDismiss = { measurementResult in
            // schedule the files for upload
            if case .completed(let measurementDescriptor) = measurementResult {
//                let sessionFileUrl = measurementDescriptor.urls.session
                let meshFileUrl = measurementDescriptor.urls.mesh
                //let measurementsFileUrl = measurementDescriptor.urls.measurements
                
                //let customAlbumName = self.createCustomAlbumName()
                
                self.arrMeasurementSessionFiles = [URL]()
//                self.arrMeasurementSessionFiles.append(sessionFileUrl)
                self.arrMeasurementSessionFiles.append(meshFileUrl)
                
                // schedule session files for upload
//                let sessionId = measurementDescriptor.sessionId
//                [sessionFileUrl, meshFileUrl, measurementsFileUrl]
//                    .upload(sessionId: sessionId)
                
                for frameSample in measurementDescriptor.frameSamples {
                    let frameFileUrl = frameSample.frameUrl
                    let frameImageFileUrl = frameSample.imageUrl
                    
                    self.arrMeasurementSessionFiles.append(frameFileUrl)
                    self.arrMeasurementSessionFiles.append(frameImageFileUrl)
                    
                    // schedule frame files for upload
//                    [frameFileUrl, frameImageFileUrl]
//                        .upload(frameSampleId: frameSample.sampleId, sessionId: sessionId)
                }
                
                self.saveVideo(videoURL: self.arrMeasurementSessionFiles[0], videoSize: 0)
                
                
            }
        }
        
        present(measureController, animated: true)
    }
    
    func saveVideo(videoURL: URL, videoSize: Int64) {
        debugPrint("Video url: \(videoURL)")
        DispatchQueue.global().async {
            let customAlbumName = self.createCustomAlbumName()
            let dateStrToSave = helperGetDateStrForLocal()
            let timeStampToSave = helperGetCurrentTimeStamp()
            
            self.timeStampArr.append(timeStampToSave)
            
            //let arrSavedVideos = UserSession.shared.arrSavedVideos
            //let countSavedVideos = arrSavedVideos.count
            let filename = videoURL.lastPathComponent
//            switch (countSavedVideos) {
//            case 0:
//                filename = (self.customAlbumName + "_" + "video_A.mp4")
//            case 1:
//                filename = (self.customAlbumName + "_" + "video_B.mp4")
//            default:
//                filename = (self.customAlbumName + "_" + "video_C.mp4")
//            }
            
            let fileManager = FileManager.default
            let documentDirectoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let directoryURL = documentDirectoryURL.appendingPathComponent(customAlbumName, isDirectory: true)
            
            do {
                try fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true, attributes: nil)
                let newFileURL = directoryURL.appendingPathComponent(filename)
                let isFileCopied = fileManager.copyFile(at: videoURL, to: newFileURL)
                if isFileCopied {
                    LogConfig.logD(message:"Video Saved \(filename)", displayToThirdParty: true)
                    
                    do {
                        if fileManager.fileExists(atPath: videoURL.path) {
                            try fileManager.removeItem(at: videoURL)
                            LogConfig.logD(message:"VIDEO FILE DELETED!!", displayToThirdParty: true)
                        }
                    }catch let error as NSError {
                        LogConfig.logD(message:"An error took place while deleting copied video file: \(error)", displayToThirdParty: true)
                    }
                    
                    var arrSavedVideos = UserSession.shared.arrSavedVideos
                    debugPrint("Saved Video Count ====1",arrSavedVideos.count)
                    arrSavedVideos.append(VideoInfoModel.init(dateStrToSave: dateStrToSave, videoLink: newFileURL.absoluteString, customAlbumName: customAlbumName, fileName: filename, newFileURLStr: newFileURL.absoluteString, videoSize: videoSize, timeStampArr: self.timeStampArr, videoTimeElapased: 30))
                    UserSession.shared.arrSavedVideos = arrSavedVideos
                    
                    
                    
                    debugPrint("Saved Video Count ====2",arrSavedVideos.count)
                    if arrSavedVideos.count == 3 {
                        debugPrint(UserSession.shared.arrSavedVideos)
                        DispatchQueue.main.async {
                            let labelScreen = helperGetAppDeleate().labelScreen
                            labelScreen.customAlbumName = customAlbumName
                            labelScreen.timeStampArr = self.timeStampArr
                            labelScreen.videoTimeElapased = 30
                            labelScreen.dateStrToSave = dateStrToSave
                            labelScreen.videoLink = newFileURL.absoluteString
                            labelScreen.videoSize = 0
                            labelScreen.fileName = filename
                            labelScreen.newFileURLStr = newFileURL.absoluteString
                            if helperGetAppDeleate().navigation.contains(labelScreen){
                                helperGetAppDeleate().navigation.popToViewController(labelScreen, animated: false)
                            }else{
                                helperGetAppDeleate().makeRootController(controller: labelScreen)
                            }
                        }
                    }else{
                        self.saveVideo(videoURL: self.arrMeasurementSessionFiles[arrSavedVideos.count], videoSize: 0)
                    }
                    
                    
                }else{
                    LogConfig.logD(message:"Video File Copy Failed", displayToThirdParty: true)
                }
            } catch {
                LogConfig.logE(message:"Error in video saving", displayToThirdParty: true)
                LogConfig.logE(message:error.localizedDescription, displayToThirdParty: true)
            }
            
        }
    }
    
    func createCustomAlbumName() -> String {
        var customAlbumName = ""
        let arrSavedVideos = UserSession.shared.arrSavedVideos
        if arrSavedVideos.count > 0 {
            customAlbumName =   arrSavedVideos[0].customAlbumName
            LogConfig.logD(message:"CUSTOM ALBUM USE EXISTING: \(String(describing: customAlbumName))", displayToThirdParty: true)
        }else{
            customAlbumName = "test_scan"
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy-HH-mm-ss"
            let date = dateFormatter.string(from: Date())
            customAlbumName = customAlbumName + "_" + date
            LogConfig.logD(message:"CUSTOM ALBUM: \(String(describing: customAlbumName))", displayToThirdParty: true)
        }
        return customAlbumName
    }
    
    
    @IBAction func logoutAction(_ sender: UIButton) {
        if sender.titleLabel?.text == "YES"{
            
            var isGuestUser = false
            if UserSession.shared.isUserTypeGuest() || UserSession.shared.getUserData() == nil {
                isGuestUser = true
            }
            if isGuestUser {
                if lblLogoutTitle.text == "Sign up" {
                    LogConfig.logD(message:"Sign Up - Yes Button Clicked", displayToThirdParty: true)
                    goToSignUpVC()
                }else{
                    AWSS3Manager.shared.cancelUploads(callback: {
                        UploadHelper.sharedInstance.timer.invalidate()
                    })
                    helperGetAppDeleate().allUploadScreen.stopEtagTimer()
                    LogConfig.logD(message:"Exit App - Yes Button Clicked", displayToThirdParty: true)
                    exit(0);
                }
            }else{
                LogConfig.logD(message:"Logout - Yes Button Clicked", displayToThirdParty: true)
                clearDataOnLogout()
                let loginScreen = LoginScreen()
                helperGetAppDeleate().navigation.setViewControllers([loginScreen], animated: false)
            }
            
        }else{
            LogConfig.logD(message:"Logout - No Button Clicked", displayToThirdParty: true)
            self.logoutView.removeFromSuperview()
        }
    }
    
    func clearDataOnLogout() {
        self.resetDefaults()
        helperGetAppDeleate().dbWrapper.dropTables()
        helperGetAppDeleate().allUploadScreen.stopEtagTimer()
        AWSS3Manager.shared.cancelUploads(callback: {
            UploadHelper.sharedInstance.timer.invalidate()
        })
        sections.removeAll()
        dismissAllFilter()
        deleteAllScanFiles()
        UserSession.shared.removeUserSelection()
        UserSession.shared.removeDontShowMeAgain()
        helperGetAppDeleate().allUploadScreen.firstLoad = true
    }
    
    func goToSignUpVC(){
        let signUpVC = SignUpController(nibName: "SignUpScreen", bundle: nil)
        helperGetAppDeleate().navigation.pushViewController(signUpVC, animated: true)
    }
    
    
    @IBAction func showActionSheet(sender: AnyObject) {
        self.sideMenuState(expanded: self.isExpanded ? false : true)
    }
    
    @IBAction func dismissView(_ sender: Any) {
        LogConfig.logD(message:"Dismiss Button Clicked", displayToThirdParty: true)
        self.logoutView.removeFromSuperview()
    }
    
    @IBAction func searchPressed(_ sender: UIButton) {
        LogConfig.logD(message:"Search Button Clicked", displayToThirdParty: true)
        //        partSearchBar.layer.addSublayer(helperGetAppDeleate().gradient)
        searchBar.frame = CGRect(x: 0 , y: 44, width: self.view.frame.width, height: 44)
        if #available(iOS 13.0, *) {
            searchBar.searchTextField.becomeFirstResponder()
        } else {
            // Fallback on earlier versions
        }
        self.view.addSubview(searchBar)
    }
    
    @IBAction func dismissFilter(_ sender: UIButton) {
        sender.isHidden = true
        if sender.tag == 100 {
            filterDate = nil
        }else if sender.tag == 101 {
            filterCategories = filterCategories.filter {$0 != .Measurements }
        }else {
            filterCategories = filterCategories.filter {$0 != .Model}
        }
        filterParts()
    }
    
    func dismissAllFilter() {
        isSearch = false
        searchBar.text = ""
        searchBar.removeFromSuperview()
        filterCategories.removeAll()
        filterDate = nil
        viewFilters.isHidden = true
        for btn in btnFilters {
            btn.isHidden = true
        }
        noResultsView.isHidden = true
        tblUploads.isHidden = false
        tblUploads.reloadData()
    }
    
    @IBAction func onClickScanButton(_ sender: Any) {
        self.chooseMeasurmentOr3DModel()
        //self.goToVideoShootScreen()
    }
}

extension AllUploadsViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        let textFld = searchBar.value(forKey: "searchField") as? UITextField
        textFld?.textColor = Color.themeGreyColor
        let tfButton = textFld?.value(forKey: "clearButton") as? UIButton
        tfButton?.setImage(UIImage(named: "Cancel"), for: .normal)
        //let partList = helperGetAppDeleate().dbWrapper.getScanInfoForParts()
        if searchText.isEmpty {
            LogConfig.logD(message:"Parts Screen - Search Text Empty", displayToThirdParty: true)
            //createDateSortedArray(arrayParts: partList)
            noResultsView.isHidden = true
            tblUploads.isHidden = false
        } else {
            //dismissAllFilter()
            isSearch = true
            LogConfig.logD(message:"Parts Screen - Search Text not Empty", displayToThirdParty: true)
            //            let filteredArray = partList.filter{($0[kPartName] as! String).lowercased().contains(searchText.lowercased())}
            //            if filteredArray.isEmpty {
            //                noResultsView.isHidden = false
            //                tblUploads.isHidden = true
            //            } else {
            //                noResultsView.isHidden = true
            //                tblUploads.isHidden = false
            //            }
            // createDateSortedArray(arrayParts: filteredArray)
        }
        setupScanDetails()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        LogConfig.logD(message:"Search Bar Cancel Button Clicked", displayToThirdParty: true)
        isSearch = false
        searchBar.text = nil
        searchBar.removeFromSuperview()
        setupScanDetails()
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.searchBar.resignFirstResponder()
    }
    
}

extension AllUploadsViewController: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[sortedSections[section]]!.count
    }
    
    //    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
    //        return sortedSections[section]
    //    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 40))
        headerView.backgroundColor = .white
        let button  = UIButton()
        button.frame = CGRect.init(x: (headerView.frame.width-40), y: 0, width: 40, height: 40)
        button.setImage(UIImage(named: "Filter-Icon"), for: .normal)
        button.addTarget(self, action: #selector(showFilters) , for: .touchUpInside)
        
        let label = UILabel()
        label.frame = CGRect.init(x: 0, y: 0, width: headerView.frame.width-50, height: headerView.frame.height)
        if sortedSections[section] == "Uploads" {
            label.text = "Uploads"
        }else{
            label.text = helperChangeDateFormatTo(dateString: sortedSections[section])
        }
        
        label.font = UIFont(name: "SFProText-Regular", size: 16)
        label.textColor = Color.themeGreyColor
        
        headerView.addSubview(label)
        if section == 0{
            headerView.addSubview(button)
        }
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "UploadCell") as? UploadCell{
            let tableSection = sections[sortedSections[indexPath.section]]
            let allDetails = tableSection![indexPath.row]
            //            let allDetails = filteredData[indexPath.row]
            cell.selectionStyle = .none
            cell.thumbnail.layer.masksToBounds = true
            cell.partDict = allDetails
            cell.viewPartDetails = { [self] in
                if let status = allDetails[kUnitStatus] as? String{
                    viewPartDetails(for: allDetails, status: status)}
            }
            cell.reloadTableOnRename = {
                self.setupScanDetails()
            }
            if helperGetAppDeleate().isOffline {
                cell.thumbnail.image = UIImage(named: "Placeholder")
            }else{
                if NetStatus.shared.isConnected{
                    if let picture = allDetails[kProfilePic] as? String, picture != ""{
                        cell.thumbnail.loadImage(at: picture)
                    }else{
                        cell.thumbnail.image = UIImage(named: "Placeholder")
                    }
                }
            }
            
            if let name = allDetails[kPartName] as? String{
                cell.lblName.text = name
            }
            cell.detailStackView.isHidden = true
            cell.progressBarStackView.isHidden = true
            if let description = allDetails[kPartDesc] as? String{
                if description.trimmingCharacters(in: .whitespacesAndNewlines) != ""{
                    cell.lblType.text = description
                    cell.detailStackView.isHidden = false
                }
                
            }
            
            let isUploaded = allDetails[kUploaded] as! Bool
            if isUploaded || allDetails[kAppSelectionType] as! String == "" {
                //                cell.imgStatus.image = UIImage(named: "Icon-upload-success")
                cell.lblStatus.text = "Uploaded"
                cell.btnOptions.isHidden = false
                cell.btnCross.isHidden = true
            }else{
                let status = allDetails[kUnitStatus] as! String
                debugPrint("Status======",status,uploadingProgressValue)
                if status == str_uploading || status == str_queued {
                    cell.btnCross.isHidden = false
                    cell.btnOptions.isHidden = true
                    if status == str_uploading {
                        let progressBarWidth = cell.progressBar.superview?.frame.width
                        if uploadingProgressValue == 0 {
                            cell.btnCross.isHidden = true
                            cell.detailStackView.isHidden = false
                            cell.progressBarStackView.isHidden = true
                            cell.lblType.text = "Finishing upload…"
                        }else{
                            cell.detailStackView.isHidden = true
                            cell.progressBarStackView.isHidden = false
                            let progressPercentage = (progressBarWidth ?? 0) * uploadingProgressValue;
                            cell.progressBarLeadingCons.constant =  progressPercentage
                            debugPrint(progressBarWidth ?? 0,"====",progressPercentage,"======",uploadingProgressValue)
                        }
                        
                    }else{
                        cell.lblType.text = status
                        cell.detailStackView.isHidden = false
                    }
                }else{
                    cell.detailStackView.isHidden = false
                    cell.btnCross.isHidden = true
                    cell.btnOptions.isHidden = false
                    cell.lblType.text = status
                }
                
                
                
                //                if allDetails[kAppDisplayStatus] != nil {
                //                    status = allDetails[kAppDisplayStatus] as! String
                //                }else{
                //                    status = allDetails[kUnitStatus] as! String
                //                }
                let imageName = getImageName(for: status)
                cell.imgStatus.image = UIImage(named: imageName)
                cell.lblStatus.text = status
            }
            return cell
        }else{
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let tableSection = sections[sortedSections[indexPath.section]]
        let allDetails = tableSection![indexPath.row]
        //        let allDetails = filteredData[indexPath.row]
        if let status = allDetails[kUnitStatus] as? String{
            if status == str_uploading{
                UploadHelper.sharedInstance.uploadScreen?.scanInfo = allDetails
                openUploadScreen()
            }else {
#if AVATAR
                showAvatar()
#elseif ARKIT
                let isUploaded = allDetails[kUploaded] as! Bool
                if isUploaded{
                    viewPartDetails(for: allDetails, status: status)
                }
#else
                let isUploaded = allDetails[kUploaded] as! Bool
                if isUploaded{
                    viewPartDetails(for: allDetails, status: status)
                }
#endif
            }
        }
    }
    
    @objc func showFilters(){
        let filterScreen = FilterViewController(nibName: "FilterScreen", bundle: nil)
        filterScreen.delegate = self
        filterScreen.filterCategories = self.filterCategories
        filterScreen.filterDate = self.filterDate
        self.navigationController?.present(filterScreen, animated: true, completion: nil)
    }
    
    func viewPartDetails(for part: [String: Any], status: String){
        var tinyUrlToShow  = ""
        if UserSession.shared.isUserTypeGuest() {
            if let tinyUrl = part[kTinyUrl] as? String{
                tinyUrlToShow = tinyUrl
            }
        }
        if tinyUrlToShow != "" {
            openUploadDetailsScreen(part: part, status: status, link: tinyUrlToShow, date: part[kLatestShootTime] as! String, desc: part[kPartDesc] as! String)
        }else if let linkURL = part[kVideoURLStr] as? String{
            openUploadDetailsScreen(part: part, status: status, link: linkURL, date: part[kLatestShootTime] as! String, desc: part[kPartDesc] as! String)
        }else{
            openUploadDetailsScreen(part: part, status: status, link: "", date: part[kLatestShootTime] as! String, desc: part[kPartDesc] as! String)
        }
    }
    
    func getImageName(for status: String?)->String{
        var imageName = "Icon-upload-success"
        if let status = status {
            if status == str_uploading{
                imageName = "Icon-uploading"
            }else if status == str_queued{
                imageName = "Icon-queued"
            }else if status == str_cancelled || status == str_retry_upload{
                imageName = "Icon-cancel"
            }
        }
        return imageName
    }
}

extension AllUploadsViewController: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for requestId - \(requestId), errorInfo - \(errorInfo)", displayToThirdParty: true)
        if requestId == RequestId.RID_GET_ALL_COMPANY_PARTS_WITH_ETAG{
            return
        }else{
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message )
        }
    }
    
    func allPartsRecieved(_ results: AllPartData) {
        LogConfig.logD(message:"allPartsRecieved - All Uploads", displayToThirdParty: true)
        debugPrint("allPartsRecieved - All Uploads",Date.init().description)
        self.firstLoad = false
        if results.etagId != nil {
            LogConfig.logD(message:"Parts Received - ETag not nil, ETAG:\(String(describing: results.etagId))", displayToThirdParty: true)
            UserDefaults.standard.set(results.etagId, forKey: kETag)
        }
        
        arrayUploads = results.partsData!
        if let parts = results.dictionary?[kPartsData] as? NSArray{
            //            arrayPartDict = parts as! [[String : Any]]
            if parts.count > 0 {
                UserDefaults.standard.set(true, forKey: kHasAllParts)
                UserDefaults.standard.set(false, forKey: kNoParts)
                let dbWrapper = helperGetAppDeleate().dbWrapper;
                DispatchQueue.global(qos: .userInitiated).async {
                    self.updateDBInBackground(parts: parts as! [[String : Any]],dBWrapper: dbWrapper)
                    UserSession.shared.setAllPartsRequestRunning(status: false)
                    DispatchQueue.main.async {
                        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                            self.setupScanDetails()
                            UploadHelper.sharedInstance.checkForJobsInQueue()
                        }
                        LogConfig.logD(message:"All parts inserted", displayToThirdParty: true)
                        debugPrint("allPartsRecieved - All parts inserted",Date.init().description)
                        
                    }
                }
            }else{
                UserDefaults.standard.set(true, forKey: kNoParts)
            }
        }
    }
    
    func updateDBInBackground(parts: [[String: Any]],dBWrapper:DatabaseWrapper) {
        dBWrapper.updatePart(partsData: parts,dBWrapper: dBWrapper,isInsertPart: true, callback: { scanlist in
            
        })
    }
}


extension AllUploadsViewController : ETagDelegate{
    func restartEtagTimer() {
        //        helperGetAppDeleate().showActivityView()
        etagTimer?.invalidate()
        getPartDetails()
        self.startEtagTimer()
    }
    
    func startEtagTimer() {
        etagTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(getPartDetails), userInfo: nil, repeats: true)
    }
    
    func stopEtagTimer() {
        
        if etagTimer != nil && etagTimer!.isValid {
            etagTimer!.invalidate()
        }
    }
    
    func getETagDelegate() -> ETagDelegate? {
        LogConfig.logD(message:"getEtagcalled in Parts", displayToThirdParty: true)
        return self
    }
    
    @objc func getPartDetails()
    {
        LogConfig.logD(message:"@@@@@@@@@@@@@ ETAG CALLED @@@@@@@@@@@@@", displayToThirdParty: true)
        let eTagId = UserDefaults.standard.value(forKey: kETag)
        if eTagId != nil {
            if !NetworkState.isConnected() {
                return
            } else {
                if UserSession.shared.getUserData() != nil{
                    DispatchQueue.main.async {
                        //                    LogConfig.logD(message:"ETAG to send:\(eTagId as! String)")
                        APIClient.etagDelegate = self
                        APIClient.getAllPartsWithEtag(etag: eTagId as! String)
                    }
                }
            }
        }else{
            LogConfig.logD(message:"########## NO ETAG STORED ##########", displayToThirdParty: true)
        }
    }
    
    func allPartsWithEtagRecieved(_ results: EtagResponse) {
        LogConfig.logD(message:"ETagDelegate - MY uploads screen", displayToThirdParty: true)
        UserDefaults.standard.set(results.etagId, forKey: kETag)
        
        if UploadHelper.sharedInstance.etagCalledForMergePart {
            UploadHelper.sharedInstance.etagCalledForMergePart = false
            helperGetAppDeleate().hideActivityView()
        }
        
        if UploadHelper.sharedInstance.etagCalledForInspectionJob {
            UploadHelper.sharedInstance.etagCalledForInspectionJob = false
            helperGetAppDeleate().hideActivityView()
        }
        if let parts = results.dictionary?[kPartsData] as? NSArray{
            if parts.count > 0 {
                LogConfig.logD(message:"########### PARTS DETAILS RECVD WITH ETAG ###########", displayToThirdParty: true)
                
                DispatchQueue.main.async {
                    helperGetAppDeleate().dbWrapper.updatePart(partsData: parts as! [[String : Any]], dBWrapper: helperGetAppDeleate().dbWrapper,isInsertPart: false,callback: { scanlist in
                        debugPrint("Part Added to DB=====")
                        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen  && !self.isUserInteractingWithMyUplodsPageFunctionalities {
                            debugPrint("Rename ETAG Screen Reloaded")
                            UploadHelper.sharedInstance.allScanScreen?.setupScanDetails()
                        }
                    })
                }
            }
        }
        
    }
    
    func showLogoutDialog() {
        self.lblLogoutTitle.text = "Log out"
        let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        let (_, queuedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsQueued()
        let (_, pausedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsPaused()
        var logoutStr: String = "Do you want to logout?"
        if uploadingJobs.count + queuedJobs.count + pausedJobs.count > 0 {
            logoutStr = "Jobs Status\n\nQueued: \(queuedJobs.count)\nPaused: \(pausedJobs.count)\nUploading: \(uploadingJobs.count)\n\nIf you logout, you will lose the data.\nDo you still want to logout?"
        }
        self.lblLogoutText.text = logoutStr
        logoutView.center = CGPoint(x: self.view.frame.size.width / 2,
                                    y: self.view.frame.size.height / 2)
        self.view.addSubview(logoutView)
    }
    
    func showExitAppDialog() {
        self.lblLogoutTitle.text = "Exit App"
        let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        let (_, queuedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsQueued()
        let (_, pausedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsPaused()
        var logoutStr: String = "Do you want to exit from Application?"
        if uploadingJobs.count + queuedJobs.count + pausedJobs.count > 0 {
            logoutStr = "Jobs Status\n\nQueued: \(queuedJobs.count)\nPaused: \(pausedJobs.count)\nUploading: \(uploadingJobs.count)\n\nDo you want to exit from Application?"
        }
        
        self.lblLogoutText.text = logoutStr
        logoutView.center = CGPoint(x: self.view.frame.size.width / 2,
                                    y: self.view.frame.size.height / 2)
        self.view.addSubview(logoutView)
    }
    
    func showConfirmAlertForSignUp() {
        self.lblLogoutTitle.text = "Sign up"
        let logoutStr: String = "Some jobs are in queue.\n\nIf you sign up, you will lose the data.\nDo you still want to sign up?"
        self.lblLogoutText.text = logoutStr
        logoutView.center = CGPoint(x: self.view.frame.size.width / 2,
                                    y: self.view.frame.size.height / 2)
        self.view.addSubview(logoutView)
    }
    
    func chooseMeasurmentOr3DModel() {
        let alert = UIAlertController(title: "", message: "Choose Option", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Measure an Object", style: .default , handler:{ (UIAlertAction)in
            UserSession.shared.set(userSelection: str_measurements)
            helperGetAppDeleate().isMeasurement = true
            self.goToVideoShootScreen()
        }))
        
        alert.addAction(UIAlertAction(title: "Create a 3D Model", style: .default , handler:{ (UIAlertAction)in
            UserSession.shared.set(userSelection: str_3d_model)
            helperGetAppDeleate().isMeasurement = false
            self.goToVideoShootScreen()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel , handler:{ (UIAlertAction)in
            print("User click Delete button")
        }))
        
        
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
    
    
}


extension AllUploadsViewController{
    
    func setupScanDetails(){
        LogConfig.logD(message:"SETUPSCAN DETAILS CALLED", displayToThirdParty: true)
        //        var tableList = [cellData]()
        filteredData = [[:]]
        if filterDate != nil || filterCategories.count > 0 {
            filterParts()
        }else{
            var allData = helperGetAppDeleate().dbWrapper.getScanInfoForParts()
            
            if isSearch {
                let searchBarText = searchBar.text ?? ""
                if searchBarText != "" {
                    allData = allData.filter{($0[kPartName] as! String).lowercased().contains(searchBarText.lowercased())}
                }
                
            }
            
            //job sort
            allData.sort { (data1, data2) -> Bool in
                let shootTime1 = data1[kLatestShootTime]
                let shootTime2 = data2[kLatestShootTime]
                return helperGetServerTimeInMillis(serverTime: shootTime1 as! String) > helperGetServerTimeInMillis(serverTime: shootTime2 as! String)
            }
            
            filteredData = allData
            
            createDateSortedArray(arrayParts: allData)
        }
        
        if !UserSession.shared.getIsAllPartsRequestRunning() {
            helperGetAppDeleate().hideActivityView()
        }
    }
    
    func createDateSortedArray(arrayParts: [Dictionary<String,Any>]){
        sections.removeAll()
        var jobsNotUploaded = helperGetAppDeleate().dbWrapper.getScanInfoForPartsNoUploaded()
        //job sort
        jobsNotUploaded.sort { (data1, data2) -> Bool in
            let shootTime1 = data1[kLatestShootTime]
            let shootTime2 = data2[kLatestShootTime]
            return helperGetServerTimeInMillis(serverTime: shootTime1 as! String) < helperGetServerTimeInMillis(serverTime: shootTime2 as! String)
        }
        let jobUploading = helperGetAppDeleate().dbWrapper.getScanInfoForPartsUploading()
        if jobUploading.count > 0{
            jobsNotUploaded.insert(jobUploading[0], at: 0)
        }
        
        if jobsNotUploaded.count > 0{
            self.sections["Uploads"] = jobsNotUploaded
        }
        
        for part in arrayParts{
            if let serverTime = part[kLatestShootTime] as? String{
                if serverTime.contains("T"){
                    let date = serverTime.components(separatedBy: "T").first!
                    if self.sections.index(forKey: date) == nil {
                        self.sections[date] = [part]
                    }else {
                        self.sections[date]!.append(part)
                    }
                }
            }
        }
        
        self.sortedSections = self.sections.keys.sorted{ $0 > $1 }
        if (tblUploads != nil) {
            if self.sortedSections.count == 0 {
                self.tblUploads.isHidden = true
                self.noShootsFoundView.isHidden = true
                self.noResultsView.isHidden = true
                self.btnHeaderPlus.isHidden = true
                self.actionButton.hideAndShowActionButton(hidden: true)
                if isSearch || filterCategories.count > 0 || filterDate != nil {
                    self.noResultsView.isHidden = false
                    if isSearch {
                        lblNoRecordsFoundDescription.text = str_no_record_found_while_search
                    }else{
                        lblNoRecordsFoundDescription.text = str_no_record_found_while_filter
                    }
                }else{
                    self.noShootsFoundView.isHidden = false
                }
            }else{
                if self.actionButton != nil {
                    self.actionButton.hideAndShowActionButton(hidden: false)
                }
                self.btnHeaderPlus.isHidden = false
                self.tblUploads.isHidden = false
                self.noResultsView.isHidden = true
                self.noShootsFoundView.isHidden = true
            }
            LogConfig.logD(message:"TABLE RELOADED", displayToThirdParty: true)
            self.tblUploads.reloadData()
            if !UserSession.shared.getIsAllPartsRequestRunning() {
                helperGetAppDeleate().hideActivityView()
            }
        }
    }
}

extension AllUploadsViewController: UploadStatusScreenProtocol{
    func notifyStatusChange() {
        tblUploads.reloadData()
    }
}

extension AllUploadsViewController: SideMenuViewControllerDelegate {
    func selectedCell(_ row: Int) {
        var isGuestUser = false
        if UserSession.shared.isUserTypeGuest() || UserSession.shared.getUserData() == nil {
            isGuestUser = true
        }
        
        switch row {
        case 1:
            if isGuestUser {
                let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
                let (_, queuedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsQueued()
                let (_, pausedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsPaused()
                if uploadingJobs.count > 0 {
                    helperGetAppDeleate().showAlert(titleStr: "Sign up", msg: "Job upload in progess. Please wait")
                }else if uploadingJobs.count + queuedJobs.count + pausedJobs.count > 0 {
                    showConfirmAlertForSignUp()
                }else{
                    goToSignUpVC()
                }
            }else{
                let profileView = ProfileViewController()
                helperGetAppDeleate().navigation.pushViewController(profileView, animated: true)
            }
            break
        case 2:
            let changePassword = ChangePasswordScreen()
            helperGetAppDeleate().navigation.pushViewController(changePassword, animated: true)
            break
        case 3:
            if let pdf = Bundle.main.url(forResource: "PhotoGAUGE_Target", withExtension: "pdf", subdirectory: nil, localization: nil)  {
                self.sharePdf(path: pdf)
            }
            break
        case 4:
            let tipsScreen = ScanTipsViewController()
            tipsScreen.isComeFromSideMenu = true
            helperGetAppDeleate().navigation.pushViewController(tipsScreen, animated: true)
            break
        case 5:
            shareLogFile()
            break
        case 6:
            let aboutScreen = AboutScreen()
            helperGetAppDeleate().navigation.pushViewController(aboutScreen, animated: true)
            break
        case 7:
            let settingsView = NewSettingsViewController(nibName: "NewSettingsScreen", bundle: nil)
            helperGetAppDeleate().navigation.pushViewController(settingsView, animated: true)
            break
        case 8:
            if isGuestUser {
                let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
                if uploadingJobs.count > 0 {
                    helperGetAppDeleate().showAlert(titleStr: "Exit app", msg: "Job upload in progess. Please wait")
                }else{
                    showExitAppDialog()
                }
            }else{
                if helperGetAppDeleate().isOffline {
                    helperGetAppDeleate().showAlert(titleStr: "Error", msg: "You are offline. Logout feature is only available online")
                }else if helperGetAppDeleate().dbWrapper.checkForJobsUpdating() {
                    helperGetAppDeleate().showAlert(titleStr: "", msg: "Scan Updating in Progress.")
                } else {
                    self.showLogoutDialog()
                }
            }
            
            break
        default:
            break
        }
        
        // Collapse side menu with animation
        DispatchQueue.main.async { self.sideMenuState(expanded: false) }
    }
    
    func shareLogFile() {
        let filePath = helperGetLogFile()
        var filesToShare = [Any]()
        filesToShare.append(filePath)
        let activityViewController = UIActivityViewController(activityItems: filesToShare, applicationActivities: nil)
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    func sharePdf(path:URL) {
        
        let fileManager = FileManager.default
        
        if fileManager.fileExists(atPath: path.path) {
            let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [path], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            self.present(activityViewController, animated: true, completion: nil)
        } else {
            LogConfig.logD(message:"document was not found", displayToThirdParty: true)
        }
    }
    
    func showViewController(viewController: UIViewController) -> () {
        // Remove the previous View
        for subview in view.subviews {
            if subview.tag == 99 {
                subview.removeFromSuperview()
            }
        }
        //        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //        let vc = storyboard.instantiateViewController(withIdentifier: storyboardId) as! T
        let vc = viewController
        vc.view.tag = 99
        view.insertSubview(vc.view, at: self.revealSideMenuOnTop ? 0 : 1)
        addChild(vc)
        if !self.revealSideMenuOnTop {
            if isExpanded {
                vc.view.frame.origin.x = self.sideMenuRevealWidth
            }
            if self.sideMenuShadowView != nil {
                vc.view.addSubview(self.sideMenuShadowView)
            }
        }
        vc.didMove(toParent: self)
    }
    
    func sideMenuState(expanded: Bool) {
        if expanded {
            self.animateSideMenu(targetPosition: self.revealSideMenuOnTop ? 0 : self.sideMenuRevealWidth) { _ in
                self.isExpanded = true
                
            }
            // Animate Shadow (Fade In)
            self.view.bringSubviewToFront(self.sideMenuShadowView)
            self.view.bringSubviewToFront(self.sideMenuViewController.view)
            UIView.animate(withDuration: 0.5) { self.sideMenuShadowView.alpha = 0.6 }
        }
        else {
            self.animateSideMenu(targetPosition: self.revealSideMenuOnTop ? (-self.sideMenuRevealWidth - self.paddingForRotation) : 0) { _ in
                self.isExpanded = false
            }
            // Animate Shadow (Fade Out)
            UIView.animate(withDuration: 0.5) { self.sideMenuShadowView.alpha = 0.0 }
        }
    }
    
    func animateSideMenu(targetPosition: CGFloat, completion: @escaping (Bool) -> ()) {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 0, options: .layoutSubviews, animations: {
            if self.revealSideMenuOnTop {
                self.sideMenuTrailingConstraint.constant = targetPosition
                self.view.layoutIfNeeded()
            }
            else {
                self.view.subviews[1].frame.origin.x = targetPosition
            }
        }, completion: completion)
    }
}


extension AllUploadsViewController: UIGestureRecognizerDelegate {
    @objc func TapGestureRecognizer(sender: UITapGestureRecognizer) {
        if sender.state == .ended {
            if self.isExpanded {
                self.sideMenuState(expanded: false)
            }
        }
    }
    
    // Close side menu when you tap on the shadow background view
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if (touch.view?.isDescendant(of: self.sideMenuViewController.view))! {
            return false
        }
        return true
    }
    
    // Dragging Side Menu
    @objc private func handlePanGesture(sender: UIPanGestureRecognizer) {
        
        guard gestureEnabled == true else { return }
        
        let position: CGFloat = sender.translation(in: self.view).x
        let velocity: CGFloat = sender.velocity(in: self.view).x
        
        switch sender.state {
        case .began:
            
            // If the user tries to expand the menu more than the reveal width, then cancel the pan gesture
            if velocity > 0, self.isExpanded {
                sender.state = .cancelled
            }
            
            // If the user swipes right but the side menu hasn't expanded yet, enable dragging
            if velocity > 0, !self.isExpanded {
                self.draggingIsEnabled = true
            }
            // If user swipes left and the side menu is already expanded, enable dragging
            else if velocity < 0, self.isExpanded {
                self.draggingIsEnabled = true
            }
            
            if self.draggingIsEnabled {
                // If swipe is fast, Expand/Collapse the side menu with animation instead of dragging
                let velocityThreshold: CGFloat = 550
                if abs(velocity) > velocityThreshold {
                    self.sideMenuState(expanded: self.isExpanded ? false : true)
                    self.draggingIsEnabled = false
                    return
                }
                
                if self.revealSideMenuOnTop {
                    self.panBaseLocation = 0.0
                    if self.isExpanded {
                        self.panBaseLocation = self.sideMenuRevealWidth
                    }
                }
            }
            
        case .changed:
            
            // Expand/Collapse side menu while dragging
            if self.draggingIsEnabled {
                if self.revealSideMenuOnTop {
                    // Show/Hide shadow background view while dragging
                    let xLocation: CGFloat = self.panBaseLocation + position
                    let percentage = (xLocation * 150 / self.sideMenuRevealWidth) / self.sideMenuRevealWidth
                    
                    let alpha = percentage >= 0.6 ? 0.6 : percentage
                    self.sideMenuShadowView.alpha = alpha
                    
                    // Move side menu while dragging
                    if xLocation <= self.sideMenuRevealWidth {
                        self.sideMenuTrailingConstraint.constant = xLocation - self.sideMenuRevealWidth
                    }
                }
                else {
                    if let recogView = sender.view?.subviews[1] {
                        // Show/Hide shadow background view while dragging
                        let percentage = (recogView.frame.origin.x * 150 / self.sideMenuRevealWidth) / self.sideMenuRevealWidth
                        
                        let alpha = percentage >= 0.6 ? 0.6 : percentage
                        self.sideMenuShadowView.alpha = alpha
                        
                        // Move side menu while dragging
                        if recogView.frame.origin.x <= self.sideMenuRevealWidth, recogView.frame.origin.x >= 0 {
                            recogView.frame.origin.x = recogView.frame.origin.x + position
                            sender.setTranslation(CGPoint.zero, in: view)
                        }
                    }
                }
            }
        case .ended:
            self.draggingIsEnabled = false
            // If the side menu is half Open/Close, then Expand/Collapse with animation
            if self.revealSideMenuOnTop {
                let movedMoreThanHalf = self.sideMenuTrailingConstraint.constant > -(self.sideMenuRevealWidth * 0.5)
                self.sideMenuState(expanded: movedMoreThanHalf)
            }
            else {
                if let recogView = sender.view?.subviews[1] {
                    let movedMoreThanHalf = recogView.frame.origin.x > self.sideMenuRevealWidth * 0.5
                    self.sideMenuState(expanded: movedMoreThanHalf)
                }
            }
        default:
            break
        }
    }
}

extension AllUploadsViewController: FilterData{
    func filterData(categories: [Category], date: Dates?) {
        searchBar.text = nil
        searchBar.removeFromSuperview()
        isSearch = false
        filterDate = date
        noResultsView.isHidden = true
        tblUploads.isHidden = false
        filterCategories = categories
        viewFilters.isHidden = false
        for btn in btnFilters {
            btn.isHidden = true
        }
        filterParts()
    }
    
    
    func filterParts() {
        var tempArray = [[String: Any]]()
        var partList = helperGetAppDeleate().dbWrapper.getScanInfoForParts()
        
        if isSearch {
            let searchBarText = searchBar.text ?? ""
            if searchBarText != "" {
                partList = partList.filter{($0[kPartName] as! String).lowercased().contains(searchBarText.lowercased())}
            }
            
        }
        
        partList.sort { (data1, data2) -> Bool in
            let shootTime1 = data1[kLatestShootTime]
            let shootTime2 = data2[kLatestShootTime]
            return helperGetServerTimeInMillis(serverTime: shootTime1 as! String) > helperGetServerTimeInMillis(serverTime: shootTime2 as! String)
        }
        
        
        guard filterDate != nil || filterCategories.count > 0 else {
            createDateSortedArray(arrayParts: partList)
            return
        }
        
        if filterCategories.count > 0 {
            for category in filterCategories {
                switch category {
                case .Measurements:
                    resetButtonConstraint(button: btnFilters[1], title: category.rawValue)
                case .CAD:
                    resetButtonConstraint(button: btnFilters[2], title: category.rawValue)
                case .Model:
                    resetButtonConstraint(button: btnFilters[3], title: category.rawValue)
                }
            }
        }
        
        if let date = filterDate {
            resetButtonConstraint(button: btnFilters[0], title: date.rawValue)
        }
        
        for part in partList {
            var doesnotFallInAnyCategory = true
            var doesnotFallInAnyDate = true
            if filterCategories.count > 0 {
                for category in filterCategories {
                    if let selectionType = part[kAppSelectionType] as? String {
                        if selectionType == category.rawValue {
                            doesnotFallInAnyCategory = false
                        }
                    }
                }
            }else {
                doesnotFallInAnyCategory = false
            }
            if let date = filterDate {
                if let serverTime = part[kLatestShootTime] as? String{
                    switch date {
                    case .today:
                        if helperIsDateToday(serverTime: serverTime) ?? false {
                            doesnotFallInAnyDate = false
                        }
                    case .yesterday:
                        if helperIsDateYesterday(serverTime: serverTime) ?? false {
                            doesnotFallInAnyDate = false
                        }
                    case .lastWeek:
                        if helperIsDate(serverTime: serverTime, in: 7) ?? false {
                            doesnotFallInAnyDate = false
                        }
                    case .lastMonth:
                        if helperIsDate(serverTime: serverTime, in: 30) ?? false {
                            doesnotFallInAnyDate = false
                        }
                    }
                }
            }else {
                doesnotFallInAnyDate = false
            }
            
            if !doesnotFallInAnyDate && !doesnotFallInAnyCategory {
                tempArray.append(part)
            }
            
        }
        
        createDateSortedArray(arrayParts: tempArray)
        
        //        if tempArray.count>0 {
        //            createDateSortedArray(arrayParts: tempArray)
        //        }else {
        //            noResultsView.isHidden = false
        //            tblUploads.isHidden = true
        //        }
    }
    
    func resetButtonConstraint(button: UIButton, title: String) {
        button.isHidden = false
        button.setTitle(title, for: .normal)
        for index in btnFilters.indices {
            let btn = btnFilters[index]
            if btn.tag == button.tag {
                button.buttonSize(iconName: "Icon cross", widthConstraints: btnFilterConstraints[index])
            }
        }
    }
}

extension AllUploadsViewController : UIScrollViewDelegate{
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        //debugPrint("====",scrollView.contentOffset.y)
        if actionButton.active {
            actionButton.toggleMenu()
        }
        if scrollView.contentOffset.y  > 50 {
            self.actionButton.updateHeight(width: 70, height: 70)
        }else{
            self.actionButton.updateHeight(width: 150, height: 70)
        }
    }
}

extension AllUploadsViewController :  QLPreviewControllerDataSource {
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { return 1 }
    
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        guard let path = Bundle.main.path(forResource: "testAvatar", ofType: "usdz") else { fatalError("Couldn't find the supported input file.") }
        let url = URL(fileURLWithPath: path)
        return url as QLPreviewItem
    }
    
    func showAvatar() {
        let previewController = QLPreviewController()
        previewController.dataSource = self
        present(previewController, animated: true, completion: nil)
        
    }
}
