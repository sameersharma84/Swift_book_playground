//
//  SideMenuViewController.swift
//  CustomSideMenuiOSExample
//
//  Created by John Codeos on 2/7/21.
//

import UIKit

protocol SideMenuViewControllerDelegate {
    func selectedCell(_ row: Int)
}

class SideMenuViewController: UIViewController {
    @IBOutlet var headerImageView: UIImageView!
    @IBOutlet var sideMenuTableView: UITableView!
    @IBOutlet var footerLabel: UILabel!
    var delegate: SideMenuViewControllerDelegate?
    var defaultHighlightedCell: Int = 0
    var menu: [SideMenuModel] = []
    var isGuestUser = -1
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"slide menu - view did load", displayToThirdParty: true)
        self.sideMenuTableView.delegate = self
        self.sideMenuTableView.dataSource = self
        self.sideMenuTableView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        self.sideMenuTableView.separatorStyle = .none
        
        // Set Highlighted Cell
        DispatchQueue.main.async {
            let defaultRow = IndexPath(row: self.defaultHighlightedCell, section: 0)
            self.sideMenuTableView.selectRow(at: defaultRow, animated: false, scrollPosition: .none)
        }
        
        self.sideMenuTableView.register(SideMenuCell.nib, forCellReuseIdentifier: SideMenuCell.identifier)
        
        loadSideMenu()
    }
    
    func loadSideMenu(){
        var isGuestUser = 0
        if UserSession.shared.isUserTypeGuest() || UserSession.shared.getUserData() == nil {
            isGuestUser = 1
        }
        
        if self.isGuestUser == isGuestUser {
            return
        }
        
        if isGuestUser == 1 {
            menu = [
                SideMenuModel(icon: UIImage(named: "Profile")!, title: "Sign up",sideMenuId: 1),
                SideMenuModel(icon: UIImage(named: "Download-1")!, title: "Download PhotoGAUGE Target",sideMenuId: 3),
                SideMenuModel(icon: UIImage(named: "side_menu_video_tips")!, title: "Video Shoot Tips",sideMenuId: 4),
                SideMenuModel(icon: UIImage(named: "Send debug info")!, title: "Send Debug Info",sideMenuId: 5),
                SideMenuModel(icon: UIImage(named: "About")!, title: "About",sideMenuId: 6),
                SideMenuModel(icon: UIImage(named: "Settings")!, title: "Settings",sideMenuId: 7),
            ]
        }else{
            menu = [
                SideMenuModel(icon: UIImage(named: "Profile")!, title: "Profile",sideMenuId: 1),
                SideMenuModel(icon: UIImage(named: "change password")!, title: "Change password",sideMenuId: 2),
                SideMenuModel(icon: UIImage(named: "Download-1")!, title: "Download PhotoGAUGE Target",sideMenuId: 3),
                SideMenuModel(icon: UIImage(named: "side_menu_video_tips")!, title: "Video Shoot Tips",sideMenuId: 4),
                SideMenuModel(icon: UIImage(named: "Send debug info")!, title: "Send Debug Info",sideMenuId: 5),
                SideMenuModel(icon: UIImage(named: "About")!, title: "About",sideMenuId: 6),
                SideMenuModel(icon: UIImage(named: "Settings")!, title: "Settings",sideMenuId: 7),
            ]
        }
        
        
        // Update TableView with the data
        sideMenuTableView.tableFooterView = UIView()
        self.sideMenuTableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
    }
}

// MARK: - UITableViewDelegate

extension SideMenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

// MARK: - UITableViewDataSource

extension SideMenuViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return self.menu.count
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SideMenuCell.identifier, for: indexPath) as? SideMenuCell else { fatalError("xib doesn't exist") }
        
        var isGuestUser = false
        if UserSession.shared.isUserTypeGuest() || UserSession.shared.getUserData() == nil {
            isGuestUser = true
        }
        
        if indexPath.section == 0{
            cell.iconImageView.image = self.menu[indexPath.row].icon
            cell.titleLabel.text = self.menu[indexPath.row].title
            cell.titleLabel.textColor =  .black
        }else{
            cell.iconImageView.image = UIImage(named: isGuestUser ? "exit_app" : "On-Off-Line")!
            cell.titleLabel.text = isGuestUser ? "Exit the app" : "Logout"
            cell.titleLabel.textColor =  isGuestUser ? #colorLiteral(red: 0.9449999928, green: 0.3959999979, blue: 0.1330000013, alpha: 1) : .black
        }
        // Highlighted color
        let myCustomSelectionColorView = UIView()
        myCustomSelectionColorView.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        cell.selectedBackgroundView = myCustomSelectionColorView
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == 0{
            let footerView =  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 1.0))
            footerView.backgroundColor = #colorLiteral(red: 0.4158889055, green: 0.4763973355, blue: 0.2559749363, alpha: 0.49)
            return footerView
        }else{
            return UIView()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.5
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0{
            self.delegate?.selectedCell(menu[indexPath.row].sideMenuId)
        }else{
            self.delegate?.selectedCell(8)
        }
       
    }
}
