//
//  ChangePasswordViewController.swift
//  PhotoGauge
//
//  Created by User on 8/22/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import UIKit

class ChangePasswordScreen: UIViewController {
    
    @IBOutlet weak var currentPassTF: UITextField!
    @IBOutlet weak var newPassTF: UITextField!
    @IBOutlet weak var confirmPassTF: UITextField!
//    @IBOutlet weak var scrollView: UIScrollView!
//    @IBOutlet weak var topContView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"ChangePasswordScreen - viewDidLoad", displayToThirdParty: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
        LogConfig.logD(message:"ChangePasswordScreen - viewWillAppear", displayToThirdParty: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        LogConfig.logD(message:"ChangePasswordScreen - viewWillDisappear", displayToThirdParty: true)
        AppUtility.lockOrientation(.all)
        NotificationCenter.default.removeObserver(self)
    }
    
    //MARK:- IBActions
    
    @IBAction func backPressed(_ sender: UIButton) {
        LogConfig.logD(message:"ChangePasswordScreen - Back Button Clicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func confirmPressed(_ sender: CustomButton) {
        LogConfig.logD(message:"Confirm Button Clicked", displayToThirdParty: true)
        helperDismissKeyboard(view: self.view)
        if helperGetTrimmedString(str: currentPassTF.text!) != "" && helperGetTrimmedString(str: newPassTF.text!) != "" && helperGetTrimmedString(str: confirmPassTF.text!) != "" {
            if helperGetTrimmedString(str: newPassTF.text!) == helperGetTrimmedString(str: confirmPassTF.text!) {
                let changePasswordInfo = PasswordRequest(newPassword: helperGetTrimmedString(str: newPassTF.text!), oldPassword: helperGetTrimmedString(str: currentPassTF.text!))
                if !NetworkState.isConnected() {
                    helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_no_network_connection)
                    return
                } else {
                    APIClient.delegate = self
                    helperGetAppDeleate().showActivityView()
                    APIClient.changePassword(request: changePasswordInfo)
                }
            }else {
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_newpass_confirmpass_should_be_same)
            }
        }else if helperGetTrimmedString(str: currentPassTF.text!) == "" {
            LogConfig.logE(message:str_please_enter_current_password, displayToThirdParty: true)
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_current_password)
        }else if helperGetTrimmedString(str: newPassTF.text!) == "" {
            LogConfig.logE(message:str_please_enter_new_password, displayToThirdParty: true)
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_new_password)
        }else {
            LogConfig.logE(message:str_please_enter_confirm_password, displayToThirdParty: true)
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_confirm_password)
        }
    }
    
    @IBAction func cancelPressed(_ sender: CustomButton) {
        LogConfig.logD(message:"Cancel Password Change Button Clicked", displayToThirdParty: true)
        helperDismissKeyboard(view: self.view)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func passwordEyeAction(_ sender: UIButton) {
        if sender.tag == 100 {
            if currentPassTF.isSecureTextEntry {
                currentPassTF.isSecureTextEntry = false
                sender.setImage(UIImage(named: "eye"), for: .normal)
            } else {
                currentPassTF.isSecureTextEntry = true
                sender.setImage(UIImage(named: "eye_hide"), for: .normal)
            }
        }else if sender.tag == 200 {
            if newPassTF.isSecureTextEntry {
                newPassTF.isSecureTextEntry = false
                sender.setImage(UIImage(named: "eye"), for: .normal)
            } else {
                newPassTF.isSecureTextEntry = true
                sender.setImage(UIImage(named: "eye_hide"), for: .normal)
            }
        }else if sender.tag == 300 {
            if confirmPassTF.isSecureTextEntry {
                confirmPassTF.isSecureTextEntry = false
                sender.setImage(UIImage(named: "eye"), for: .normal)
            } else {
                confirmPassTF.isSecureTextEntry = true
                sender.setImage(UIImage(named: "eye_hide"), for: .normal)
            }
        }
    }
}

extension ChangePasswordScreen: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for RequestID \(requestId), errorInfo \(errorInfo)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message)
    }
    
    func passwordChanged(_ results: PasswordResponse) {
        LogConfig.logD(message:"Password Changed - Server response received", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().navigation.popViewController(animated: true)
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: results.message)
    }
    
}

extension ChangePasswordScreen: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == currentPassTF {
            currentPassTF.resignFirstResponder()
            newPassTF.becomeFirstResponder()
        } else if textField == newPassTF {
            newPassTF.resignFirstResponder()
            confirmPassTF.becomeFirstResponder()
        }else {
            self.view.endEditing(true)
        }
        return false
    }
}
