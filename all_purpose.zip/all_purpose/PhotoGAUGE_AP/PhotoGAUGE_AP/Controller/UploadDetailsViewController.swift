//
//  ViewResultsViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 03/12/21.
//

import UIKit

class UploadDetailsViewController: UIViewController {
    @IBOutlet var btnLink: UIButton!
    @IBOutlet var viewLink: UIStackView!
    @IBOutlet var lblStatus: UILabel!
    @IBOutlet var imgStatus: UIImageView!
    @IBOutlet var lblPartName: UILabel!
    @IBOutlet var lblStatusDesc: UILabel!
    @IBOutlet var lblAdditionalDetails: UILabel!
    @IBOutlet var lblDate: UILabel!
    @IBOutlet weak var outputLbl: UILabel!
    
    @IBOutlet weak var downloadBtn: UIButton!
    var publicURL = ""
    var status = ""
    var uploadDate = ""
    var partName = ""
    var additionalDetails = "-"
    var outputType = ""
    var allDetails = [String : Any]()
    var fileDownloadKey : String = "";
    var fileDownloadingAlert : UIAlertController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if uploadDate.contains("T"){
            let dateText = uploadDate.components(separatedBy: "T")
            let changedFormat = helperChangeDateFormat(dateString: dateText[0])
            lblDate.text = changedFormat
        }
        
        if publicURL == "" {
            publicURL = "https://app.photoGAUGE.com"
        }
        
        lblAdditionalDetails.text = additionalDetails
        lblPartName.text = partName
        outputType = allDetails[kAppSelectionType] as! String
        outputLbl.text = outputType
        initialiseScreen(with: status)
        
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let _ = change, object != nil, keyPath == fileDownloadKey else { return }
        DispatchQueue.main.async {
            if !UserSession.shared.is3DModelObjectFileDownloading(allDetails: self.allDetails) {
                self.downloadBtn.alpha = 1.0
                self.downloadBtn.isEnabled = true
                UserDefaults.standard.removeObserver(self, forKeyPath: self.fileDownloadKey)
                self.fileDownloadKey = ""
                if self.fileDownloadingAlert != nil{
                    self.fileDownloadingAlert.dismiss(animated: true)
                }
            }
        }
    }
   
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
        if fileDownloadKey != ""{
            UserDefaults.standard.removeObserver(self, forKeyPath: fileDownloadKey)
            debugPrint("Un - Register for ",fileDownloadKey)
        }
    }
    
    func initailiseScreen(with serverStatus: ServerUploadStatus){
        switch serverStatus {
        case .Fail:
            lblStatus.text = "Construction Failed"
            lblStatusDesc.text = ""
            btnLink.isHidden = true
        case .Success:
            lblStatus.text = "View Results"
            lblStatusDesc.text = "For a better experience view results on web"
            if publicURL != ""{
                btnLink.setTitle(publicURL, for: .normal)
            }else{
                btnLink.isHidden = true
            }
        case .inProgress:
            lblStatus.text = "Processing Results.."
            lblStatusDesc.text = "Please wait, results will appear after the processing is complete"
            btnLink.isHidden = true
        }
    }
    
    func initialiseScreen(with serverStatus: String){
        imgStatus.isHidden = false
        lblStatus.isHidden = false
        lblStatusDesc.isHidden = false
        if serverStatus == "Success" {
            if outputType == str_3d_model {
                imgStatus.image = UIImage(named: "Ready to measure")
                lblStatus.text = "3D Model is ready to download"
                lblStatus.textColor = Color.themeAquaColor
                lblStatusDesc.text = ""
                viewLink.isHidden = true
                downloadBtn.isHidden = false
                if UserSession.shared.is3DModelObjectFileDownloading(allDetails: allDetails) {
                    showFileDownloadingAlert()
                }
                
            }else if outputType == str_measurements {
                imgStatus.image = UIImage(named: "Ready to measure")
                lblStatus.text = "Ready to Measure"
                lblStatus.textColor = Color.themeAquaColor
                lblStatusDesc.text = "Due to the small screen size, we do not support our editor on mobile devices. Visit the below link from a desktop"
                viewLink.isHidden = false
                downloadBtn.isHidden = true
                btnLink.setTitle(publicURL, for: .normal)
            }else{
                viewLink.isHidden = true
                downloadBtn.isHidden = true
                imgStatus.isHidden = true
                lblStatus.isHidden = true
                lblStatusDesc.isHidden = true
            }
        }else if status.contains("pending") || status.contains("progress"){
            imgStatus.image = UIImage(named: "Processing")
            lblStatus.text = "Processing.."
            lblStatus.textColor = Color.themeBlueColor
            lblStatusDesc.text = "You can access the measurements after the processing is complete"
            viewLink.isHidden = true
            downloadBtn.isHidden = true
        }else{
            imgStatus.image = UIImage(named: "Failed")
            lblStatus.text = "Processing Failed"
            lblStatus.textColor = Color.themeErrorColor
            if outputType == str_3d_model {
                lblStatusDesc.text = "Please make sure you record a 4K video."
            }else{
                lblStatusDesc.text = "Please make sure you record a 4K video with PhotoGAUGE Target placed"
            }
            viewLink.isHidden = true
            downloadBtn.isHidden = true
        }
    }
    
    
    //MARK: Actions
    @IBAction func btnLinkClicked(_ sender: UIButton){
        if let url = URL(string: publicURL) {
            UIApplication.shared.open(url)
        }
    }
    
    @IBAction func btnShareLink(_ sender: UIButton){
        if let link = NSURL(string: publicURL)
        {
            let objectsToShare = [link]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            self.present(activityVC, animated: true, completion: nil)
        }
    }

    @IBAction func dismissView(){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func downloadClicked(_ sender: UIButton) {
        if !UserSession.shared.is3DModelObjectFileDownloading(allDetails: allDetails) {
            showFileDownloadingAlert()
            DownloadHelper.sharedInstance.download3DModelObjectFile(allDetails: allDetails)
        }else{
            debugPrint("Video already downloading")
        }
    }
    
    func showFileDownloadingAlert() {
        if fileDownloadingAlert != nil{
            fileDownloadingAlert.dismiss(animated: true)
        }
        
        fileDownloadKey = allDetails[kPartId] as! String;
        fileDownloadKey = "3dmodel_object_\(fileDownloadKey)";
        UserDefaults.standard.addObserver(self, forKeyPath: fileDownloadKey, options: [.new], context: nil)
        debugPrint("Register for ",fileDownloadKey)
        fileDownloadingAlert = UIAlertController(title: "", message: "Please wait while the file download is complete.", preferredStyle: UIAlertController.Style.alert)
        fileDownloadingAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {_ in
            self.fileDownloadingAlert.dismiss(animated: true)
        }))
        helperGetAppDeleate().navigation.present(fileDownloadingAlert, animated: true, completion: nil)
        downloadBtn.alpha = 0.5
        downloadBtn.isEnabled = false
    }
    
}

enum ServerUploadStatus: String{
    case Fail = "Fail"
    case Success = "Success"
    case inProgress = "Pending"
}
