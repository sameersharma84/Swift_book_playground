//
//  CameraScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 02/12/21.
//

import UIKit
import CameraManager
import Photos

protocol VideoCompletion {
    func saveVideoAfterPreview()
    func retryShoot()
}

class CameraScreen: UIViewController {
    
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var optionsView: UIView!
    @IBOutlet weak var videoBtn: UIButton!
    @IBOutlet weak var videoBtnLandscape: UIButton!
    @IBOutlet weak var videoTimeLabel: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var flashBtn: UIButton!
    @IBOutlet weak var cancelBtnLandscape: UIButton!
    @IBOutlet weak var btnWideAngle: UIButton!
    @IBOutlet weak var btnWideAngleLandscape: UIButton!
    
    let cameraManager = CameraManager()
    var customAlbumName : String!
    var timer = Timer()
    var startTime: Double = 0
    var shootTimeStr = String()
    var time: Double = 0
    var fromDownloadScreen = Bool()
    
    var isVideoRecording: Bool = false
    var videoTimer = Timer()
    var videoTimeElapased = Int()
    var videoURLForErrorCompletion: URL?
    var videoFileSizeForErrorCompletion: Int64?
    var timeStampToSave : String = ""
    var dateStrToSave : String = ""
    var timeStampArr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeViews()
        setUpCameraScreen()
        UserSession.shared.setDontShowScanTipsScreen(isSet: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(appMovedToBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(appCameToForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
        LogConfig.logD(message:"Camera screen - view will appear", displayToThirdParty: true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        let deviceOrientation = UIDevice.current.orientation.rawValue
        switch(deviceOrientation) {
        case 1:
            print("DID APPEAR: Portrait")
            UIDevice.current.setValue(1, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
            break
        case 4:
            print("DID APPEAR: LandRight")
            UIDevice.current.setValue(4, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
            break
        case 3:
            print("DID APPEAR: LandLeft")
            UIDevice.current.setValue(3, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
            break
        default:
            print("DID APPEAR: Default")
            UIDevice.current.setValue(1, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
            break
        }
        cameraManager.resetPreviewLayer(self.cameraView, isInitial: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        UIApplication.shared.isIdleTimerDisabled = false
        AppUtility.lockOrientation(.all)
        NotificationCenter.default.removeObserver(self, name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
        LogConfig.logD(message:"view will disappear", displayToThirdParty: true)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        print("viewWillTransition")
        if let videoPreviewLayerConnection = cameraManager.returnPreviewLayer().connection{
            let deviceOrientation = UIDevice.current.orientation
            guard let newVideoOrientation = AVCaptureVideoOrientation(rawValue: deviceOrientation.rawValue),
                deviceOrientation.isPortrait || deviceOrientation.isLandscape else {
                    return
            }
            videoPreviewLayerConnection.videoOrientation = newVideoOrientation
            cameraManager.resetPreviewLayer(self.cameraView, isInitial: false)
        }
    }
    
    //MARK:- Other Functions
    
    func initializeViews() {
        self.cameraManager.cameraOutputMode = .videoOnly
        let session = UserSession.shared
//        if session.isFirstTime() ?? true{
//            cancelBtn.isHidden = true
//            cancelBtnLandscape.isHidden = true
//        }else{
//            if (session.getUserData() != nil){
//                cancelBtn.isHidden = false
//                cancelBtnLandscape.isHidden = false
//            }
//        }
        
        if (session.getUserData() != nil){
            cancelBtn.isHidden = false
            cancelBtnLandscape.isHidden = false
        }
    
        cameraManager.addPreviewLayerToView(self.cameraView)
        self.customAlbumName = nil
    }
    
    func setUpCameraScreen() {
        startTime = Date().timeIntervalSinceReferenceDate
        timer = Timer.scheduledTimer(timeInterval: 0.001,
                                     target: self,
                                     selector: #selector(advanceTimer(timer:)),
                                     userInfo: nil,
                                     repeats: true)
        self.openCamera() {
            self.startCamera()
        }
    }
    
    @objc func advanceTimer(timer: Timer) {
        time = Date().timeIntervalSinceReferenceDate - startTime
        shootTimeStr = String(Int(floor(time)))
    }
    
    @objc private func handleDismiss() {
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @objc func videoTimeElapsed(timer: Timer) {
        videoTimeElapased += 1
        let min = videoTimeElapased / 60
        let sec = videoTimeElapased % 60
        let string = helperGetFormattedVideoTime(timeMin: min , timeSec: sec)
        self.videoTimeLabel.text = String(string)
    }
    
    private func openCamera(completionHandler: @escaping()->()) {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: // the user has already authorized to access the camera.
//            self.setupCaptureSession()
//            cameraManager.addPreviewLayerToView(self.cameraView)
            completionHandler()
            
        case .notDetermined: // the user has not yet asked for camera access.
            AVCaptureDevice.requestAccess(for: .video) { (granted) in
                if granted { // if user has granted to access the camera.
                    LogConfig.logD(message:"the user has granted to access the camera", displayToThirdParty: true)
                    
                    DispatchQueue.main.async {
                        completionHandler()
////                        self.setupCaptureSession()
//                        self.cameraManager.addPreviewLayerToView(self.cameraView)
                    }
                } else {
                    LogConfig.logD(message:"the user has not granted to access the camera", displayToThirdParty: true)
                    DispatchQueue.main.async {
                        helperGetAppDeleate().navigation.popViewController(animated: true)
                        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Camera permissions not granted. Please allow Camera permissions in Settings")
                    }
                    self.handleDismiss()
                }
            }
            
        case .denied:
            LogConfig.logD(message:"the user has denied previously to access the camera.", displayToThirdParty: true)
            DispatchQueue.main.async {
                helperGetAppDeleate().navigation.popViewController(animated: true)
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Camera permissions denied. Please allow Camera permissions in Settings")
            }
            self.handleDismiss()
            
        case .restricted:
            DispatchQueue.main.async {
                helperGetAppDeleate().navigation.popViewController(animated: true)
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Camera permissions restricted. Please allow Camera permissions in Settings")
            }
            LogConfig.logD(message:"the user can't give camera access due to some restriction.", displayToThirdParty: true)
            
            self.handleDismiss()
            
        default:
            DispatchQueue.main.async {
                LogConfig.logD(message:"something has wrong due to we can't access the camera.", displayToThirdParty: true)
                helperGetAppDeleate().navigation.popViewController(animated: true)
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Something went wrong")
            }
            self.handleDismiss()
        }
    }
    func startCamera() {
        var status = PHPhotoLibrary.authorizationStatus()
        //let cameraStatus = self.cameraManager.currentCameraStatus()
        /*if cameraStatus != .ready {
         helperGetAppDeleate().navigation.popViewController(animated: true)
         helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Camera permission is disabled. Please enable Camera permissions in Settings")
         return
         }*/
        
       
            if #available(iOS 14, *) {
                status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
                
                if (status == .limited) {
                    
                    DispatchQueue.main.async {
                        helperGetAppDeleate().navigation.popViewController(animated: true)
                        helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Photos permission is limited. Please select \'Allow Access to All Photos\' permission in Settings")
                    }
                    self.handleDismiss()
                    return
                }
            }
            
            if (status == PHAuthorizationStatus.authorized) {
                DispatchQueue.main.async {
                    let cameraStatus = self.cameraManager.currentCameraStatus()
                    if cameraStatus != .ready {
                        helperGetAppDeleate().navigation.popViewController(animated: true)
                        helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Camera permission is disabled. Please enable Camera permissions in Settings")
                        return
                    }
                    self.startAction()
                }
                
            } else if (status == PHAuthorizationStatus.denied) {
                
                DispatchQueue.main.async {
                    helperGetAppDeleate().navigation.popViewController(animated: true)
                    helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Photos permission is denied. Please select \'Allow Access to All Photos\' permission in Settings")
                }
                self.handleDismiss()
                
            } else if (status == PHAuthorizationStatus.notDetermined) {
                
                print("Not Determined")
                // Access has not been determined.
                PHPhotoLibrary.requestAuthorization({ (newStatus) in
                    
                    var statusWithAccess = newStatus
                    if #available(iOS 14, *) {
                        statusWithAccess = PHPhotoLibrary.authorizationStatus(for: .readWrite)
                        if (statusWithAccess == .limited) {
                            
                            DispatchQueue.main.async {
                                helperGetAppDeleate().navigation.popViewController(animated: true)
                                helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Photos permission is limited. Please select \'Allow Access to All Photos\' permission in Settings")
                            }
                            self.handleDismiss()
                            return
                        }
                    }
                    
                    if (statusWithAccess == PHAuthorizationStatus.authorized) {
                        DispatchQueue.main.async {
                            //                        self.showLEDCalBarAlert()
                            self.startAction()
                        }
                    } else {
                        DispatchQueue.main.async {
                            helperGetAppDeleate().navigation.popViewController(animated: true)
                            helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Photos permission is denied. Please select \'Allow Access to All Photos\' permission in Settings")
                        }
                        self.handleDismiss()
                    }
                })
            } else if (status == PHAuthorizationStatus.restricted) {
                DispatchQueue.main.async {
                    helperGetAppDeleate().navigation.popViewController(animated: true)
                    helperGetAppDeleate().showSettingsAlert(titleStr: helperGetAppName(), msg: "Photos permission is Restricted. Please select \'Allow Access to All Photos\' permission in Settings")
                }
                self.handleDismiss()
            }
        
    }
    
    func startAction() {
        self.cameraManager.attachFocusAtCenter()
        self.cameraManager.cameraOutputMode = .videoOnly
    }
    
    func captureVideo() {
        if (!self.videoBtn.isSelected || !self.videoBtnLandscape.isSelected) {
            self.flashBtn.isHidden = true
            if UIDevice.current.orientation.isPortrait {
                AppUtility.lockOrientation(.portrait)
            }else{
                AppUtility.lockOrientation(.landscape)
            }
            
            cancelBtn.isHidden = true
            cancelBtnLandscape.isHidden = true
            
            UIApplication.shared.isIdleTimerDisabled = true
            cameraManager.startRecordingVideo()
            cameraManager.delegateVar = self
            self.isVideoRecording = true
            self.btnWideAngle.isHidden = true
            self.btnWideAngleLandscape.isHidden = true
            if self.flashBtn.isSelected {
                if self.cameraManager.hasFlash {
                    self.cameraManager.flashMode = .on
                }
            }else{
                self.cameraManager.flashMode = .off
            }
            DispatchQueue.main.async {
                self.videoBtn.isSelected = true
                self.videoBtnLandscape.isSelected = true
                self.videoTimer = Timer.scheduledTimer(timeInterval: 1,
                                                       target: self,
                                                       selector: #selector(self.videoTimeElapsed(timer:)),
                                                       userInfo: nil,
                                                       repeats: true)
            }
        } else {
            UIApplication.shared.isIdleTimerDisabled = false
            AppUtility.lockOrientation(.all)
            cancelBtn.isHidden = false
            cancelBtnLandscape.isHidden = false
            
            cameraManager.delegateVar = nil
            self.isVideoRecording = false
            cameraManager.flashMode = .off
            self.flashBtn.isHidden = false
            cameraManager.stopVideoRecording { [self] (videoURL , error, fileSize) -> Void in
                self.btnWideAngle.isHidden = false
                self.btnWideAngleLandscape.isHidden = false
                if error != nil {
                    self.cameraManager.showErrorBlock("Error occurred", "Cannot save video.")
                }else{
                    self.saveVideo(videoURL: videoURL!, videoSize: fileSize!)
                }
               
                DispatchQueue.main.async {
                    self.videoBtn.isUserInteractionEnabled = false
                    self.videoBtnLandscape.isUserInteractionEnabled = false
                    self.videoTimer.invalidate()
                    self.videoBtn.isSelected = false
                    self.videoBtnLandscape.isSelected = false
                    self.timeStampToSave = helperGetCurrentTimeStamp()
                }
            }
        }
    }
    
    @objc func appMovedToBackground() {
        print("app enters background")
    }

    @objc func appCameToForeground() {
        print("app enters foreground")
        if self.isVideoRecording {
            if self.videoURLForErrorCompletion != nil {
                DispatchQueue.main.async {
                    self.videoBtn.isUserInteractionEnabled = true
                    self.videoBtnLandscape.isUserInteractionEnabled = true
                    self.videoTimer.invalidate()
                    self.videoBtn.isSelected = false
                    self.videoBtnLandscape.isSelected = false
                    let alert = UIAlertController(title: "", message: "The video shoot was interrupted. Please select an option to proceed.", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Reshoot", style: .default, handler: { _ in
                        LogConfig.logD(message:"Reshoot Video Option Selected", displayToThirdParty: true)
                        let string = helperGetFormattedVideoTime(timeMin: 0 , timeSec: 0)
                        self.videoTimeLabel.text = String(string)
                        self.videoTimeElapased = 0
                        self.cameraManager.resumeCaptureSession()
                        self.videoURLForErrorCompletion = nil
                        self.videoFileSizeForErrorCompletion = nil
                    }))
                    alert.addAction(UIAlertAction(title: "Upload", style: .default, handler: {_ in
                        LogConfig.logD(message:"Upload Video Option Selected", displayToThirdParty: true)
                        self.saveVideo(videoURL: self.videoURLForErrorCompletion!, videoSize: self.videoFileSizeForErrorCompletion!)
                    }))
                    helperGetAppDeleate().navigation.present(alert, animated: true, completion: nil)
                }
            }
        } else {
            self.cameraManager.resumeCaptureSession()
        }
    }
    
    func saveVideo(videoURL: URL, videoSize: Int64) {
        LogConfig.logD(message:"Video url: \(videoURL)", displayToThirdParty: true)
        DispatchQueue.global().async {
            _ = self.createCustomAlbumName()
            self.dateStrToSave = helperGetDateStrForLocal()
            self.timeStampArr.append(self.timeStampToSave)
            
            let fileManager = FileManager.default
            let filename = (self.customAlbumName + "_" + "video.mp4")
            
            let documentDirectoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let directoryURL = documentDirectoryURL.appendingPathComponent(self.customAlbumName, isDirectory: true)
            
            do {
                try fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true, attributes: nil)
                let newFileURL = directoryURL.appendingPathComponent(filename)
                let isFileCopied = fileManager.copyFile(at: videoURL, to: newFileURL)
                if isFileCopied {
                    LogConfig.logD(message:"Video Saved", displayToThirdParty: true)
                    do {
                        if fileManager.fileExists(atPath: videoURL.path) {
                            try fileManager.removeItem(at: videoURL)
                            LogConfig.logD(message:"VIDEO FILE DELETED!!", displayToThirdParty: true)
                        }
                    }catch let error as NSError {
                        LogConfig.logD(message:"An error took place while deleting copied video file: \(error)", displayToThirdParty: true)
                    }
                    
                    DispatchQueue.main.async {
                        let previewScreen = VideoPreviewScreen()
                        previewScreen.fromCameraScreen = true
                        previewScreen.videoURLString = newFileURL.absoluteString
                        previewScreen.delegateVar = self
                        previewScreen.customAlbumName = self.customAlbumName
                        previewScreen.timeStampArr = self.timeStampArr
                        previewScreen.videoTimeElapased = self.videoTimeElapased
                        previewScreen.dateStrToSave = self.dateStrToSave
                        previewScreen.newFileURLStr = newFileURL.absoluteString
                        previewScreen.videoSize = videoSize
                        previewScreen.fileName = filename
                        previewScreen.orientation = self.cameraManager.returnPreviewLayer().connection?.videoOrientation.rawValue ?? 0
                        helperGetAppDeleate().navigation.pushViewController(previewScreen, animated: true)
                    }
                }else{
                    LogConfig.logD(message:"Video File Not Copied", displayToThirdParty: true)
                }
            } catch {
                LogConfig.logE(message:"Error in video saving", displayToThirdParty: true)
                LogConfig.logE(message:error.localizedDescription, displayToThirdParty: true)
            }
            
        }
    }
    
    func createCustomAlbumName() -> String {
        //        let trimmedPartName = "".replacingOccurrences(of: " ", with: "_")
        self.customAlbumName = "test_scan"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy-HH-mm-ss"
        let date = dateFormatter.string(from: Date())
        self.customAlbumName = self.customAlbumName + "_" + date
        
        LogConfig.logD(message:"CUSTOM ALBUM: \(String(describing: self.customAlbumName))", displayToThirdParty: true)
        return self.customAlbumName
    }
    
    func retryAction() {
        self.videoBtn.isUserInteractionEnabled = true
        self.videoBtnLandscape.isUserInteractionEnabled = true
        self.videoTimer.invalidate()
        self.videoBtn.isSelected = false
        self.videoBtnLandscape.isSelected = false
        let string = helperGetFormattedVideoTime(timeMin: 0 , timeSec: 0)
        self.videoTimeLabel.text = String(string)
        self.videoTimeElapased = 0
        self.cameraManager.resumeCaptureSession()
        self.videoURLForErrorCompletion = nil
        self.videoFileSizeForErrorCompletion = nil
    }
    
    
    
    //MARK:- IBActions
    
    @IBAction func btnChangeAngleClicked(_ sender: UIButton) {
        if cameraManager.cameraDevice == CameraDevice.back {
            btnWideAngle.setImage(UIImage(named: "0.5"), for: .normal)
            btnWideAngleLandscape.setImage(UIImage(named: "0.5"), for: .normal)
        }else{
            btnWideAngle.setImage(UIImage(named: "1x"), for: .normal)
            btnWideAngleLandscape.setImage(UIImage(named: "1x"), for: .normal)
        }
        cameraManager.cameraDevice = cameraManager.cameraDevice == CameraDevice.back ? CameraDevice.uWide : CameraDevice.back
    }
    
    
    @IBAction func videoBtnPressed(_ sender: UIButton) {
        captureVideo()
    }
    
    @IBAction func flashClicked(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    
//    @IBAction func cancelCameraPressed(_ sender: UIButton) {
    @IBAction func cancelCameraPressed(_ sender: Any) {
        if self.videoTimer.isValid {
            self.videoTimer.invalidate()
        }
        
        if helperGetAppDeleate().navigation.contains(helperGetAppDeleate().allUploadScreen){
            helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().allUploadScreen, animated: false)
        }else{
            helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
        }
    }
}


extension CameraScreen: CameraManagerDelegate {
    func executeVideoCompletionWithError(_ url: URL?, error: NSError?, fileSize: Int64?) {
        print("URL Received")
        self.videoURLForErrorCompletion = url
        self.videoFileSizeForErrorCompletion = fileSize
    }
}

extension CameraScreen: VideoCompletion {
    func retryShoot() {
        self.retryAction()
    }
    
    func saveVideoAfterPreview() {
        DispatchQueue.main.async {
            //            self.donePressed()
        }
    }
}

extension FileManager {
    
    open func copyFile(at srcURL: URL, to dstURL: URL) -> Bool {
        do {
            if FileManager.default.fileExists(atPath: dstURL.path) {
                try FileManager.default.removeItem(at: dstURL)
            }
            try FileManager.default.copyItem(at: srcURL, to: dstURL)
        } catch (let error) {
            print("Cannot copy item at \(srcURL) to \(dstURL): \(error)")
            return false
        }
        return true
    }
    
}
