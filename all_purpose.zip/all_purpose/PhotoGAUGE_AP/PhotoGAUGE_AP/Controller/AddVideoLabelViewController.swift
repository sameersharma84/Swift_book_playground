//
//  AddVideoLabelViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 01/12/21.
//

import UIKit
import iOSDropDown
import AVKit
class AddVideoLabelViewController: UIViewController {
    
    @IBOutlet var txtName: UITextField!
    @IBOutlet var lblVideoTime: UILabel!
    @IBOutlet var txtAdditionalDetails: UITextField!
    @IBOutlet var txtShootType: DropDown!
    @IBOutlet var imgVideoThumbnail: UIImageView!
    @IBOutlet var noNetworkView: UIView!
    @IBOutlet var noInternetkView: UIView!
    @IBOutlet weak var screenTitle: UILabel!
    @IBOutlet weak var btnUpload: UIButton!
    
    var arrayVideoType = [str_measurements, str_3d_model]
    var videoLink: String = ""
    var shootInfo = [String : Any]()
    var customAlbumName : String!
    var timeStampArr = [String]()
    var videoTimeElapased = Int()
    var dateStrToSave : String = ""
    var videoSize = Int64()
    var newFileURLStr = String()
    var fileName = String()
    var isDummyPartCalled = false
    let ACCEPTABLE_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_ "
    let ACCEPTABLE_CHARACTERS_DESCRIPTION = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_@.-"
    
    // We will use this for temporty save data
    var partName : String = "";
    var partDescription : String = "";
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        LogConfig.logD(message:"Add label - viewwillappear", displayToThirdParty: true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.addLabelSceen
        self.txtName.text = ""
        self.txtAdditionalDetails.text = ""
        self.txtName.delegate = self
        self.txtAdditionalDetails.delegate = self
        btnUpload.isEnabled = true
        initialiseDropdown()
        handleNetworkChange()
        
        #if ARKIT
            lblVideoTime.isHidden = true
        #endif
        
        if videoLink == ""{
            if let urlPath = Bundle.main.url(forResource: "sample", withExtension: "MOV"){
                let videoDetails =  createVideoThumbnail(from: urlPath)
                if let thumbnail = videoDetails.0{
                    imgVideoThumbnail.image = thumbnail
                }
                lblVideoTime.text = videoDetails.1
            }
        }else{
            if let urlPath = URL(string: videoLink){
                let videoDetails =  createVideoThumbnail(from: urlPath)
                if let thumbnail = videoDetails.0{
                    imgVideoThumbnail.image = thumbnail
                }
                lblVideoTime.text = videoDetails.1
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.portrait)
        LogConfig.logD(message:"Add label - disappear", displayToThirdParty: true)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.none
    }
    
    func initialiseDropdown(){
        txtShootType.optionArray = arrayVideoType
        txtShootType.delegate = self
        txtShootType.borderColor = .lightGray
        txtShootType.selectedIndex = -1
        txtShootType.hideOptionsWhenSelect = true
        txtShootType.selectedRowColor = .lightGray
        txtShootType.checkMarkEnabled = false
        txtShootType.rowHeight = 45
        
        let type = UserSession.shared.getUserSelection()
        if type == str_3d_model {
            txtShootType.text = str_3d_model
            self.screenTitle.text = "Enter the name of your \(str_3d_model)"
        }else{
            txtShootType.text = str_measurements
            self.screenTitle.text = "Enter the name of this \(str_measurements)"
        }
    }
    
    func validateTextfields()-> Bool{
        guard let name = txtName.text, name.count>0 else{
            showAlert(withMessage: str_please_enter_video_name, txtFeild: txtName)
            btnUpload.isEnabled = true
            return false
        }
        
//        guard let videoType = txtVideoType.text, videoType.count>0 else{
//            showAlert(withMessage: str_please_enter_video_description, txtFeild: txtVideoType)
//            return false
//        }
        return true
    }
    
    func showAlert(withMessage: String, txtFeild: UITextField){
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: withMessage)
    }
    
    func callAddPartApi(with partName: String, description: String){
        if UserSession.shared.getUserData() == nil{
            LogConfig.logD(message:"Guest Login - AddVideoLabel", displayToThirdParty: true)
            let deviceUUID = UserSession.shared.getDeviceUUID()
            let loginRequest = LoginRequest(loginId: "ios_guest_user@photogauge.com", timezone: "333.0", password: "123456",deviceUUID: deviceUUID)
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
            LogConfig.logD(message:"LoginId - ios_guest_user@photogauge.com, timeZone: 333.0 , deviceUUID - \(deviceUUID)", displayToThirdParty: true)
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)

            helperGetAppDeleate().showActivityView()
            APIClient.delegate = self
            APIClient.loginByUUID(request: loginRequest)
            self.partName = partName
            self.partDescription = description
        }else{
            let addPartRequest = AddPartRequest(partName: partName, zipCode: "", partCustomer: "", address: "", localPartTimeCreation: helperGetFormattedTime(), partDescription: description)
            helperGetAppDeleate().showActivityView()
            APIClient.delegate = self
            APIClient.addPart(request: addPartRequest)
        }
        
    }
    
    func openUploadScreen(){
        if helperGetAppDeleate().navigation.viewControllers.contains(UploadHelper.sharedInstance.uploadScreen!){
            helperGetAppDeleate().navigation.popToViewController(UploadHelper.sharedInstance.uploadScreen!, animated: false)
        }else{
            helperGetAppDeleate().navigation.pushViewController(UploadHelper.sharedInstance.uploadScreen!, animated: false)
        }
    }
    
    func offlineFlow(){
        if validateTextfields(){
            LogConfig.logD(message:"Network Connected - add part Offline flow", displayToThirdParty: true)
            helperGetAppDeleate().isOffline = true
            //create a project with dummy id if the user is in offline mode
            let dummyPartId = "dummy_\(helperGetCurrentTimeStamp())" //"dummy_1613378345532"
            let (utcTime, _, dateForDB) : (String, String, String) = helperGetFormattedLocalShootTime()
            let newPartInfo : [String: Any] = [kPartName : txtName.text!.trimmingCharacters(in: .whitespacesAndNewlines),
                                                 kPartId : dummyPartId,
                                            kPartCustomer: "",
                                                 kAddress: "",
                                                 kZipCode: "",
                                               kPartDesc : txtAdditionalDetails!.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? " ",
                                  kLocalPartTimeCreation : utcTime,
                                        kLatestShootTime : dateForDB]
            
            helperGetAppDeleate().dbWrapper.insertSinglePart(partDetails: newPartInfo, callback: {
                var partInfo = [String : Any]()
                //partInfo = helperGetAppDeleate().dbWrapper.getPartFromTable(withPartName: txtName.text!.trimmingCharacters(in: .whitespacesAndNewlines))
                partInfo = helperGetAppDeleate().dbWrapper.getPartFromTable(withPartId: dummyPartId)
                DispatchQueue.main.async {
                    self.donePressed(partDetails: partInfo)
                }
            })
        }
    }
    
    //MARK: Actions
    @IBAction func btnUploadClicked(_ sender: UIButton){
        if !btnUpload.isEnabled {
            return
        }
        btnUpload.isEnabled = false
        if NetStatus.shared.isConnected {
            LogConfig.logD(message:"Network Connected - Call Add part API", displayToThirdParty: true)
            if txtShootType.text == str_3d_model {
                UserSession.shared.set(userSelection: str_3d_model)
            }else{
                UserSession.shared.set(userSelection: str_measurements)
            }
            isDummyPartCalled = false
            if validateTextfields(){
                isDummyPartCalled = true
                if txtAdditionalDetails.text == "" {
                    callAddPartApi(with: txtName.text!, description: " ")
                }else{
                    callAddPartApi(with: txtName.text!, description: txtAdditionalDetails.text!)
                }
            }
        }else{
            offlineFlow()
        }
    }
    
    @IBAction func btnCameraClicked(_ sender: UIButton){
        if helperGetAppDeleate().isMeasurement {
            if UserSession.shared.isDontShowTargetScreenSet(){
                let cameraStartScreen = CameraScreen()
                cameraStartScreen.fromDownloadScreen = false
                helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
            }else{
                if helperGetAppDeleate().navigation.viewControllers.contains(helperGetAppDeleate().targetScreen){
                    helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().targetScreen, animated: false)
                }else{
                    helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().targetScreen, animated: true)
                }
            }
        }else{
            let cameraStartScreen = CameraScreen()
            cameraStartScreen.fromDownloadScreen = false
            helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
        }
        helperGetAppDeleate().hideActivityView()
    }
    
    @IBAction func dismissView(){
        self.navigationController?.popViewController(animated: true)
    }
    
    func donePressed(partDetails: [String:Any]) {
        LogConfig.logD(message:"Add label - Done pressed", displayToThirdParty: true)
        
        let fileManager = FileManager.default
        let documentDirectoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let directoryURL = documentDirectoryURL.appendingPathComponent(customAlbumName, isDirectory: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("logFile.txt")
        if fileManager.fileExists(atPath: fileURL.path) {
            do {
                LogConfig.logD(message:"Moving Log File from Main Directory to Scan Directory and Deleting this Log file from Main Directory", displayToThirdParty: true)
                try fileManager.moveItem(at: fileURL, to: directoryURL.appendingPathComponent("logFile.txt"))
                Logger.checkIfFileExists(logStr: "************* PHOTOGAUGE APP LOGS *************")
            } catch {
                LogConfig.logE(message:"Error while moving and deleting Log File", displayToThirdParty: true)
            }
        }
    
        UserSession.shared.saveAllVideoInfoByScanName(scanName: self.customAlbumName, arrSavedVideo: UserSession.shared.arrSavedVideos)
        UploadHelper.sharedInstance.isVideoUpload = true
        let (utcTime, timeString, dateForDB) : (String, String, String) = helperGetFormattedLocalShootTime()
        shootInfo[kPicCount] = 1
        shootInfo[kPartDetails] = partDetails
        shootInfo[kScanDetails] = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: partDetails[kPartId] as! String)
        shootInfo[kScanName] = self.customAlbumName
        shootInfo[kUnitId] = self.customAlbumName
        shootInfo[kUnitName] = self.customAlbumName
        shootInfo[kDisplayName] = partDetails[kPartName] as! String + "_scan"
        shootInfo[kTimeStamps] = self.timeStampArr
        shootInfo[kShootTime] = String(Int(self.videoTimeElapased) * 1000)
        shootInfo[kVideoShootTime] = Int(self.videoTimeElapased) * 1000
        shootInfo[kLocalShootTime] = utcTime
        shootInfo[kLocalShootTimeStr] = timeString
        shootInfo[kDateForDB] = dateForDB
        shootInfo[kVideo] = true
        shootInfo[kUploaded] = false
        shootInfo[kUnitCreatedOnLocal] = self.dateStrToSave
        let type = UserSession.shared.getUserSelection()
        if type == str_3d_model {
            shootInfo[kAppSelectionType] = str_3d_model
        }else{
            shootInfo[kAppSelectionType] = str_measurements
        }
        shootInfo[kJobIds] = ""
        shootInfo[kJobName] = ""
        shootInfo[kJobStatus] = ""
    #if ARKIT
        self.shootInfo[kVideoLocalPath] = self.customAlbumName
    #else
        self.shootInfo[kVideoLocalPath] = "/\(String(describing: self.customAlbumName!))/\(fileName)"
    #endif
        
        self.shootInfo[kVideoSize] = videoSize
        self.shootInfo[kVideoURLStr] = newFileURLStr
        UserDefaults.standard.set(shootInfo, forKey: self.customAlbumName)
    
        if helperGetAppDeleate().isOffline {
            if UploadHelper.sharedInstance.scanType == str_new_scan {
                helperGetAppDeleate().dbWrapper.insertScansLocally(shootInfo: shootInfo, action: str_new_scan, unitStatus: str_waiting_for_upload, isVideo: true)
            }else if UploadHelper.sharedInstance.scanType == str_re_scan {
                helperGetAppDeleate().dbWrapper.insertScansLocally(shootInfo: shootInfo, action: str_re_scan, unitStatus: str_queued, isVideo: true)
            }
        }else{
            var unitStatusStr =  String()
            unitStatusStr = str_waiting_for_upload
            if UploadHelper.sharedInstance.scanType == str_new_scan {
                helperGetAppDeleate().dbWrapper.insertScansLocally(shootInfo: shootInfo, action: str_new_scan, unitStatus: unitStatusStr, isVideo: true)
            }else if UploadHelper.sharedInstance.scanType == str_re_scan {
                helperGetAppDeleate().dbWrapper.insertScansLocally(shootInfo: shootInfo, action: str_re_scan, unitStatus: unitStatusStr, isVideo:true)
            }else if UploadHelper.sharedInstance.scanType == str_update_scan {
                helperGetAppDeleate().dbWrapper.insertScansLocally(shootInfo: shootInfo, action: str_update_scan, unitStatus: unitStatusStr, isVideo: true)
            }
            
            UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = true
        }
        
        let scanData = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: partDetails[kPartId] as! String)
        
        helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scanData[0], unitStatus: str_queued, callback: {
            if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                helperGetAppDeleate().allUploadScreen.setupScanDetails()
            }
            UploadHelper.sharedInstance.checkForJobsInQueue()
//            if NetStatus.shared.isConnected {
//                openUploadScreen()
//            }else{
//                openAllUploadsScreen()
//            }
            openAllUploadsScreen()
            
        })
    }
    
    ///AllScansScreen specific Network changes handling
     func handleNetworkChange() {
         LogConfig.logD(message:"Network Changed - Handle Network change called", displayToThirdParty: true)
         if !NetStatus.shared.isConnected {
             noNetworkView.isHidden = false
             LogConfig.logD(message:"NO INTERNET", displayToThirdParty: true)
             UploadHelper.sharedInstance.timer.invalidate()
         }else{
             LogConfig.logD(message:"NETWORK CONNECTED", displayToThirdParty: true)
             if !NetStatus.shared.isInternetAvailable{
                 noInternetkView.isHidden = false
             }else{
                 noNetworkView.isHidden = true
                 noInternetkView.isHidden = true
                 if !helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                     if !helperGetAppDeleate().isOffline {
                         UploadHelper.sharedInstance.videoFileName = ""
                         UploadHelper.sharedInstance.changeFromRetryToQueued()
                     }
                 }
             }
         }
         //         if NetStatus.shared.isConnected {
         //             DispatchQueue.main.async {
         //                 LogConfig.logD(message:"Network Connected")
//                 self.noInternetView.isHidden = true
//                 if self.selectedDatesDisplayView.isHidden == true {
//                     self.setupScanDetails()
//                     if self.filteredData.count == 0 {
//                         self.noScansView.isHidden = false
//                         self.allScanTableView.isHidden = true
//                         self.uploadProjectView.isHidden = true
//                         self.totalWindowsLbl.isHidden = true
//                         self.viewAllProjBtn.isHidden = true
//                     }else{
//                         self.noScansView.isHidden = true
//                         self.allScanTableView.isHidden = false
//                         self.uploadProjectView.isHidden = false
//                         self.totalWindowsLbl.isHidden = false
//                         self.viewAllProjBtn.isHidden = false
//                     }
//                 }
//                 self.isRetryScreenDisplayed = false
//                 self.handleRedSnackBar()
//             }
//         } else {
//             DispatchQueue.main.async {
//                 if !helperGetAppDeleate().isOffline {
//                     LogConfig.logD(message:"Network Disconnected")
//                     //Show Retry screen when App is in online mode but Network is disconnected
//                     //User cannot click back in retry screen and view the scan list
//                     if !self.isRetryScreenDisplayed && !helperGetAppDeleate().isOffline {
//                         if !(NetStatus.shared.isConnected) {
//                             helperGetAppDeleate().navigation.dismiss(animated: true, completion: nil)
//                             self.isRetryScreenDisplayed = true
//                             let retryScreen = helperGetAppDeleate().retryScreen
//                             retryScreen.fromPartsScreen = false
//                             retryScreen.fromScanScreen = true
//                             retryScreen.fromUploadScreen = false
//                             retryScreen.fromUpdateScreen = false
//                             if !(helperGetAppDeleate().navigation.viewControllers.contains(retryScreen)){
//                                 helperGetAppDeleate().navigation.pushViewController(retryScreen, animated: true)
//                             }
//                         } else {
//                             self.handleRedSnackBar()
//                         }
//
//                     } else {
//                         self.handleRedSnackBar()
//                     }
//
//                     self.noInternetView.isHidden = false
//                     self.noScansView.isHidden = true
//                     self.allScanTableView.isHidden = true
//                     self.uploadProjectView.isHidden = true
//                     self.totalWindowsLbl.isHidden = true
//                     self.viewAllProjBtn.isHidden = true
//                 } else {
//                     //When network is disconnected and app is in offline mode -
//                     //Hide the retry screen and allow the user to work in offline mode
//                     self.noInternetView.isHidden = true
//                     if self.selectedDatesDisplayView.isHidden == true {
//                         self.setupScanDetails()
//                         if self.filteredData.count == 0 {
//                             self.noScansView.isHidden = false
//                             self.allScanTableView.isHidden = true
//                             self.uploadProjectView.isHidden = true
//                             self.totalWindowsLbl.isHidden = true
//                             self.viewAllProjBtn.isHidden = true
//                         }else{
//                             self.noScansView.isHidden = true
//                             self.allScanTableView.isHidden = false
//                             self.uploadProjectView.isHidden = false
//                             self.totalWindowsLbl.isHidden = false
//                             self.viewAllProjBtn.isHidden = false
//                         }
//                     }
//                 }
//                 let subviews = helperGetAppDeleate().window?.subviews
//                 if subviews!.contains(helperGetAppDeleate().snackBarView) {
//                     helperGetAppDeleate().snackBarView.removeFromSuperview()
//                 }
//             }
//         }
     }
    
    func openAllUploadsScreen() {
        helperGetAppDeleate().allUploadScreen.isFromUploadScreen = true
        helperGetAppDeleate().allUploadScreen.isFromAddLabelScreen = true
        helperGetAppDeleate().allUploadScreen.uploadingProgressValue = 0.005
        if helperGetAppDeleate().navigation.contains(helperGetAppDeleate().allUploadScreen){
            helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().allUploadScreen, animated: false)
        }else{
            helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
        }
    }
}

extension AddVideoLabelViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtName {
            txtAdditionalDetails.becomeFirstResponder()
        }else{
            self.view.endEditing(true)
        }
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == txtShootType{
            return false
        }
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtName {
            let cs = NSCharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
            let filtered = string.components(separatedBy: cs).joined(separator: "")

            if (string == filtered) {
                guard let textFieldText = textField.text,
                    let rangeOfTextToReplace = Range(range, in: textFieldText) else {
                        return false
                }
                let substringToReplace = textFieldText[rangeOfTextToReplace]
                let count = textFieldText.count - substringToReplace.count + string.count
                if count <= 20 {
                    return true
                } else {
                    return false
                }
            } else {
                return false
            }
        }else{
            guard let textFieldText = textField.text,
                let rangeOfTextToReplace = Range(range, in: textFieldText) else {
                    return false
            }
            let substringToReplace = textFieldText[rangeOfTextToReplace]
            let count = textFieldText.count - substringToReplace.count + string.count
            if count <= 255 {
                return true
            } else {
                return false
            }
        }
        
    }
}

extension AddVideoLabelViewController{
    private func createVideoThumbnail(from url: URL) -> (UIImage?, String) {
        let asset = AVAsset(url: url)
        let duration : CMTime = asset.duration
        let durationString = duration.durationText
        let assetImgGenerate = AVAssetImageGenerator(asset: asset)
        assetImgGenerate.appliesPreferredTrackTransform = true
        assetImgGenerate.maximumSize = CGSize(width: 100, height: 100)
        
        let time = CMTimeMakeWithSeconds(0.0, preferredTimescale: 600)
        do {
            let img = try assetImgGenerate.copyCGImage(at: time, actualTime: nil)
            let thumbnail = UIImage(cgImage: img)
            return (thumbnail, durationString)
        }
        catch {
            LogConfig.logE(message: error.localizedDescription, displayToThirdParty: true)
            return (nil, durationString)
        }
    }
}

extension AddVideoLabelViewController: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for requestId - \(requestId), errorInfo - \(errorInfo)", displayToThirdParty: true)
        if errorInfo.code == 1009{
            if !isDummyPartCalled{
                isDummyPartCalled = true
                offlineFlow()
            }
        }else{
            helperGetAppDeleate().hideActivityView()
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message )
            
        }
        btnUpload.isEnabled = true
    }
    
    func loggedIn(_ results: LoginResponse) {
        LogConfig.logD(message:"Results \(results)", displayToThirdParty: true)
        UserSession.shared.setUserData(data: results)
        UserSession.shared.setGuestUserData(data: results)
        UserSession.shared.setUserTypeAsGuest()
        callAddPartApi(with: self.partName, description: self.partDescription)
    }
    
    func newPartAdded(_ results: AddPartResponse) {
        
        let newPartInfo : [String: Any] = [kPartName : results.partName ?? "",
                                             kPartId : results.id ?? "",
                                        kPartCustomer: results.partCustomer ?? "",
                                             kAddress: results.address ?? "",
                                             kZipCode: results.zipCode ?? "",
                                           kPartDesc : results.partDescription ?? " ",
                              kLocalPartTimeCreation : results.localPartTimeCreation ?? "",
                                    kLatestShootTime : results.localPartTimeCreation ?? ""]
        helperGetAppDeleate().dbWrapper.insertSinglePart(partDetails: newPartInfo, callback: {
            self.donePressed(partDetails: newPartInfo)
        })
        LogConfig.logD(message:"NEW Part Info AT Add Video Screen: \(newPartInfo)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
    }
}
 
