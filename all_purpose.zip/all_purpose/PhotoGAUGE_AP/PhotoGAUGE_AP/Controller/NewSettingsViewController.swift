//
//  NewSettingsViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 18/01/22.
//

import UIKit

class NewSettingsViewController: UIViewController {

    @IBOutlet weak var btnSwitch: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"Settings - view did load", displayToThirdParty: true)
        UserSession.shared.isDontShowTargetScreenSet() ? (btnSwitch.isOn = false) : (btnSwitch.isOn = true)
        if btnSwitch.isOn{
            btnSwitch.thumbTintColor = Color.themeBlueColor
        }else{
            btnSwitch.thumbTintColor = Color.themeGreyColor
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
    }
    
    @IBAction func backButtonPressed(_ sender: UIButton) {
        LogConfig.logD(message:"Settings - Back Button Clicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }

    @IBAction func dontshowmeagain(_ sender: UISwitch) {
        LogConfig.logD(message:"Settings - don't show me again clicked", displayToThirdParty: true)
        if sender.isOn{
            sender.thumbTintColor = Color.themeBlueColor
        }else{
            sender.thumbTintColor = Color.themeGreyColor
        }
      UserSession.shared.setDontShowTargetScreen(isSet: !sender.isOn)
    }
}
