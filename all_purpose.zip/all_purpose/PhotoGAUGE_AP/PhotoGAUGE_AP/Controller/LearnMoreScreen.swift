//
//  LearnMoreScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 07/06/22.
//

import UIKit

class LearnMoreScreen: UIViewController {

    @IBOutlet weak var infoTableView: UITableView!
    
    var tableContents: [LearnMoreModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.infoTableView.register(LearnMoreCell.nib, forCellReuseIdentifier: LearnMoreCell.identifier)
        
        tableContents = [
            LearnMoreModel(icon: UIImage(named: "Measurements png")!, title: str_measurements, content: "The objects are too far away to approach, measure in a smarter way!\n\nJust record a video and get as many measurements as you want", outputImage: UIImage(named: "Measurements Sample Output")!),
            LearnMoreModel(icon: UIImage(named: "3D")!, title: str_3d_model, content: "Looking for a quick 3D model of a real-time object?\n\nJust record a video and get a 3D model ready to use or share it across marketplaces", outputImage: UIImage(named: "3D output")!),
        ]
        self.infoTableView.reloadData()
    }
    
    @IBAction func closeClicked(_ sender: UIButton) {
        helperGetAppDeleate().navigation.dismiss(animated: true)
    }
    
}
// MARK: - UITableViewDelegate

extension LearnMoreScreen: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 380
    }
}


// MARK: - UITableViewDataSource

extension LearnMoreScreen: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return self.tableContents.count
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: LearnMoreCell.identifier, for: indexPath) as? LearnMoreCell else { fatalError("xib doesn't exist") }
                
        cell.iconImageView.image = self.tableContents[indexPath.row].icon
        cell.titleLabel.text = self.tableContents[indexPath.row].title
        cell.body.text = self.tableContents[indexPath.row].content
        cell.outputImgView.image = self.tableContents[indexPath.row].outputImage
        cell.selectionStyle = .none
        return cell
    }
}
