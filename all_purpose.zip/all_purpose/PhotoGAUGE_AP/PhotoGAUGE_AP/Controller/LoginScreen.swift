//
//  LoginScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 17/12/21.
//

import UIKit
import AuthenticationServices
import GoogleSignIn

class LoginScreen: UIViewController, UITextFieldDelegate{
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var passwordView: UIView!
    
    @IBOutlet var environmentView: UIView!
    @IBOutlet weak var envtSubView: UIView!
    @IBOutlet weak var envDevBtn: UIButton!
    @IBOutlet weak var envQABtn: UIButton!
    @IBOutlet weak var envProdBtn: UIButton!
    @IBOutlet weak var signUpTxtView: UITextView!
    
    @IBOutlet weak var btnContinueAsGuest: UIButton!
    var emailId : String?
    var password : String?
    var loginRequest : LoginRequest!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"Login - viewDidLoad", displayToThirdParty: true)
        setUpScreen()
        //self.emailTF.setLeftPaddingPoints(6)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        LogConfig.logD(message:"viewwillappear", displayToThirdParty: true)
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        
        let lastLoggedInDetail = UserSession.shared.getUserLoginDetail()
        if lastLoggedInDetail != nil {
            if let userEmail = lastLoggedInDetail?.loginId {
                loginRequest = lastLoggedInDetail
                btnContinueAsGuest.setTitle("Continue as \(userEmail)", for: .normal)
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        LogConfig.logD(message:"viewwilldisappear", displayToThirdParty: true)
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.portrait)
    }
    
    @IBAction func backPressed(_ sender: Any) {
        LogConfig.logD(message:"EmailLogin - BackButtonClicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func login(_ sender: Any) {
        LogConfig.logD(message:"Login Clicked", displayToThirdParty: true)
        helperDismissKeyboard(view: self.view)
        emailId = helperGetTrimmedString(str: emailTF.text!)
        password = helperGetTrimmedString(str: passwordTF.text!)
        
        let isValidEmail = validateEmail(email: emailId!)
        
        //        var loginInfo = [String: Any]()
        //        loginInfo[kLoginId] = "ios_construct@photogauge.com"
        //        loginInfo[kPassword] = "123456"
        //        loginInfo[kTimezone] = "330.0"
        //
        //        if !NetworkState.isConnected() {
        //                helperGetAppDeleate().showAlert(titleStr: "", msg: str_no_network_connection)
        //                return
        //        }
        //        helperGetAppDeleate().backend.delegate = self
        //        helperGetAppDeleate().showActivityView()
        //        helperGetAppDeleate().backend.emailLogin(loginInfo)
        
        if emailId == "" {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_email)
        } else if password == "" {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_password)
        } else if isValidEmail && (password != nil) {
            var loginInfo = [String: Any]()
            loginInfo[kLoginId] = emailId
            loginInfo[kPassword] = password
            loginInfo[kTimezone] = "330.0"
            
            if !NetworkState.isConnected() {
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_no_network_connection)
                return
            } else {
                LogConfig.logD(message:"Login: Email - \(String(describing: self.emailId))", displayToThirdParty: true)
                
                loginRequest = LoginRequest(loginId: emailId!, timezone: "0", password: password!)
                helperGetAppDeleate().showActivityView()
                APIClient.delegate = self
                APIClient.login(request: loginRequest)
            }
        } else if isValidEmail == false {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_invalid_email)
        }
    }
    
    @IBAction func btnForgotPasswordClicked(_ sender: UIButton) {
        let vc = ForgotPasswordController(nibName: "ForgotPasswordScreen", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func passwordEyeAction(_ sender: UIButton) {
        if passwordTF.isSecureTextEntry {
            passwordTF.isSecureTextEntry = false
            sender.setImage(UIImage(named: "eye"), for: .normal)
        } else {
            passwordTF.isSecureTextEntry = true
            sender.setImage(UIImage(named: "eye_hide"), for: .normal)
        }
    }
    
    @IBAction func dismissEnvView(_ sender: UIButton) {
        LogConfig.logD(message:"", displayToThirdParty: true)
        self.environmentView.removeFromSuperview()
    }
    
    @IBAction func environmentSelected(_ sender: UIButton) {
        LogConfig.logD(message:"", displayToThirdParty: true)
        switch sender.tag {
        case 1:
            LogConfig.logD(message:"Env - DEV", displayToThirdParty: true)
            helperSetEnvironment(env: ENVIRONMENT.ENVIRONMENT_DEV)
            envDevBtn.isSelected = true
            envQABtn.isSelected = false
            envProdBtn.isSelected = false
            self.environmentView.removeFromSuperview()
            break
        case 2:
            LogConfig.logD(message:"Env - QA", displayToThirdParty: true)
            helperSetEnvironment(env: ENVIRONMENT.ENVIRONMENT_QA)
            envDevBtn.isSelected = false
            envQABtn.isSelected = true
            envProdBtn.isSelected = false
            self.environmentView.removeFromSuperview()
            break
        case 3:
            LogConfig.logD(message:"Env - PROD", displayToThirdParty: true)
            helperSetEnvironment(env: ENVIRONMENT.ENVIRONMENT_PRODUCTION)
            envDevBtn.isSelected = false
            envQABtn.isSelected = false
            envProdBtn.isSelected = true
            self.environmentView.removeFromSuperview()
            break
        default:
            break
        }
        self.environmentView.removeFromSuperview()
    }
    
    @IBAction func threeTapDummyAction(_ sender: UIButton) {
        LogConfig.logD(message:"threeTapDummyAction!!", displayToThirdParty: true)
        self.handleTap()
    }
    
    @IBAction func signupWithGoogle(_ sender: UIButton) {
        let signInConfig = GIDConfiguration.init(clientID: "YOUR_IOS_CLIENT_ID")
        GIDSignIn.sharedInstance.signIn(with: signInConfig, presenting: self){ user, error in
            guard error == nil else { return }

        }
    }
    
    @IBAction func signupWithApple(_ sender: UIButton) {
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.fullName, .email]
        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.delegate = self
        authorizationController.performRequests()
    }
    
    //MARK:-  Other Functions
    
    @objc func handleTap(){
        //        self.envtSubView.layer.cornerRadius = 10.0
        environmentView.center = CGPoint(x: self.view.frame.size.width / 2,
                                         y: self.view.frame.size.height / 2)
        self.view.addSubview(environmentView)
    }
    
    func setUpScreen() {
        makeCreateAccountLink()
        LogConfig.logD(message:"", displayToThirdParty: true)
//        emailTF.setTFCornerRadius()
//        passwordView.setViewCornerRadius()
        addThreeFingerTapGesture()
        
        let env = helperGetEnvironment()
        envQABtn.isSelected = false
        envDevBtn.isSelected = false
        envProdBtn.isSelected = false
        if env == .ENVIRONMENT_QA {
            envQABtn.isSelected = true
        }else if env == .ENVIRONMENT_DEV {
            envDevBtn.isSelected = true
        }else{
            envProdBtn.isSelected = true
        }
    }
    
    func makeCreateAccountLink(){
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = .center
        let attributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.init(name: "SFProText-Regular", size: 16) ?? UIFont.systemFont(ofSize: 16),
            .paragraphStyle: paragraph
        ]
        let attributedString = NSMutableAttributedString(string: "Don't have an account? Sign Up!",attributes: attributes)
        
        attributedString.addAttribute(.link, value: "signup://createaccount", range: (attributedString.string as NSString).range(of: "Sign Up!"))
        signUpTxtView.attributedText = attributedString
        signUpTxtView.isEditable = false
        signUpTxtView.linkTextAttributes = [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0.00800000038, green: 0.5329999924, blue: 0.7289999723, alpha: 1)]
    }
    
    func addThreeFingerTapGesture() {
        let gesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap))
        gesture.numberOfTouchesRequired = 3
        self.view.addGestureRecognizer(gesture)
    }
    
    //MARK:- UITextField Delegates
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag + 1
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        
        if nextResponder != nil {
            nextResponder?.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        
        return false
    }
    
    @IBAction func continueAsGuest(_ sender: Any) {
        if loginRequest != nil {
            if !NetworkState.isConnected() {
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_no_network_connection)
                return
            } else {
                helperGetAppDeleate().showActivityView()
                APIClient.delegate = self
                APIClient.login(request: loginRequest)
            }
        }else{
            if let guestSessionData = UserSession.shared.getGuestUserData(){
                UserSession.shared.setUserData(data:guestSessionData)
                UserSession.shared.setUserTypeAsGuest()
            }
            helperGetAppDeleate().dbWrapper.createPartsTable()
            helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().selectionScreen)
        }
    }
    
}

extension LoginScreen: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for requestId - \(requestId), errorInfo - \(errorInfo)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message )
    }
    
    func loggedIn(_ results: LoginResponse) {
        LogConfig.logD(message:"Results \(results)", displayToThirdParty: true)
        UserSession.shared.setPartsCountOfUser(partsCount: results.partCount)
        helperGetAppDeleate().hideActivityView()
        if UserSession.shared.isUserTypeGuest() {
            helperGetAppDeleate().allUploadScreen.clearDataOnLogout()
            UserSession.shared.setUserTypeAsNormal()
        }
        if loginRequest != nil {
            UserSession.shared.setUserLoginDetail(data: loginRequest)
        }
        UserSession.shared.setUserData(data: results)
        helperGetAppDeleate().dbWrapper.createPartsTable()
        helperGetAppDeleate().screenRouter()
    }
}

extension LoginScreen: ASAuthorizationControllerDelegate{
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as?  ASAuthorizationAppleIDCredential {
            let userIdentifier = appleIDCredential.user
            let fullName = appleIDCredential.fullName
            let email = appleIDCredential.email
            print("User id is \(userIdentifier) \n Full Name is \(String(describing: fullName)) \n Email id is \(String(describing: email))") }
    }
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
    }
    
}

extension LoginScreen : UITextViewDelegate{
   func textView(_ textView: UITextView, shouldInteractWith url: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool{
       let signUpVC = SignUpController(nibName: "SignUpScreen", bundle: nil)
       helperGetAppDeleate().navigation.pushViewController(signUpVC, animated: true)
       return false
   }

}
