//
//  ForgotPasswordController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 08/01/22.
//

import UIKit

class ForgotPasswordController: UIViewController {
    
    @IBOutlet weak var emailTF: UITextField!
    //    @IBOutlet weak var scrollView: UIScrollView!
    var emailId : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"ForgotPassword - viewDidLoad", displayToThirdParty: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        LogConfig.logD(message:"ForgotPassword - viewWillAppear", displayToThirdParty: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        LogConfig.logD(message:"ForgotPassword - viewWillDisappear", displayToThirdParty: true)
        AppUtility.lockOrientation(.portrait)
    }
    
    
    //MARK:-  IBActions
    
    @IBAction func backPressed(_ sender: Any) {
        LogConfig.logD(message:"ForgotPassword - Back Button Clicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func sendPressed(_ sender: Any) {
        LogConfig.logD(message:"Send Clicked", displayToThirdParty: true)
        helperDismissKeyboard(view: self.view)
        emailId = helperGetTrimmedString(str: emailTF.text!)
        
        let isValidEmail = validateEmail(email: emailId!)
        
        if emailId == "" {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_email)
        }else if isValidEmail == false {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_invalid_email)
        } else {
            if !NetworkState.isConnected() {
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_no_network_connection)
                return
            } else {
                APIClient.delegate = self
                helperGetAppDeleate().showActivityView()
                APIClient.forgotPassword(for: emailId!)
            }
        }
    }
    
    //MARK:-  ServerWrapper
    
    func passwordRecovered(_ results: [String : Any]) {
        LogConfig.logD(message:"Password Recovered", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().navigation.popToRootViewController(animated: true )
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: results[kMessage] as! String)
    }
    
    
}

extension ForgotPasswordController: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for RequestID \(requestId), errorInfo \(errorInfo)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message)
    }
    
    func passwordRecovered(_ results: PasswordResponse) {
        LogConfig.logD(message:"Password Recovered", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().navigation.popToRootViewController(animated: true )
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: results.message)
    }
}

extension ForgotPasswordController: UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
