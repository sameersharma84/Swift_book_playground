//
//  UploadViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 30/11/21.
//

import UIKit
import AWSS3


class UploadViewController: UIViewController {
    @IBOutlet var viewUploading: UIView!
    @IBOutlet var viewRetryUpload: UIView!
    @IBOutlet var viewNoUploads: UIView!
    @IBOutlet var viewNoInternet: UIView!
    @IBOutlet var viewLoader: UIView!
    @IBOutlet var lblVideoName: UILabel!
    @IBOutlet var lblUploading: UILabel!
    @IBOutlet var lblVideoAdditionalDetails: UILabel!
    @IBOutlet weak var lblErrorMsg1: UILabel!
    @IBOutlet weak var lblErrorMsg2: UILabel!
    @IBOutlet weak var viewNoNetwork: UIView!
    var videoLink: String = ""
    var videoData = VideoData(name: "", additionalDescription: "")
    var uploadInProgress = Bool()
    var isScreenLoaded: Bool = false
    var toastMessage = String()
    private var uploadedVideoUrl = ""
    private var progressRing: CircularProgressBar!
    var tempUpload: Uploads?
    var progress: Float = 0.0
    var isUploadCompleted: Bool = false
    var showNetworkDisconnection: Bool = false
    var unitNameForFailedUpload = ""
    var scanInfo :  [String:Any]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblVideoName.text = videoData.name
        lblVideoAdditionalDetails.text = videoData.additionalDescription
        initialiseLoader()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.uploadScreen
        self.handleNetworkChange()
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
        self.isScreenLoaded = true
        self.viewNoNetwork.isHidden = true
        self.viewNoInternet.isHidden = true
        self.viewRetryUpload.isHidden = true
        let session = UserSession.shared
        if (session.getUserData() != nil){
            if session.isFirstTime() ?? true{
                session.setFirstTimeUserLogin()
            }
        }
        LogConfig.logD(message:"view will appear UploadScreen - upload in progress \(uploadInProgress)", displayToThirdParty: true)
        if !(viewLoader.layer.sublayers?.contains(progressRing) ?? false){
            viewLoader.layer.addSublayer(progressRing)
        }
        
        
        
//        if !uploadInProgress {
//            if NetStatus.shared.isConnected{
//                viewNoUploads.isHidden = false
//            }else{
//                self.noInternetView.isHidden = false
//            }
//        }else{
            viewNoUploads.isHidden = true
            updateUI()
//        }
        
        // This function will call when video is already uploaded and mergePartUnit or addInspectionJob is Pending and user click on all uploads cell
        handleVideoAlreadyUploaded()
        
    }
    
    func handleVideoAlreadyUploaded(){
        if scanInfo != nil {
           let uploadStatus = scanInfo[kUploadStatus] as! String
            if uploadStatus ==   UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue  {
                let partId = scanInfo[kPartId] as! String
                let partDetails = helperGetAppDeleate().dbWrapper.getSinglePartFromTable(partId: partId)
                let partInfo: [String : Any] = partDetails[0]
                let isVideoUpload = scanInfo[kVideo] as! Bool
                
                self.textInfoUpdated(projectName: (partInfo[kPartName] as! String), windowName: (scanInfo[kUnitDisplayName] as? String) ?? "", uploadCount: 1, totalUploadsCount: 1, progress: 1, location: (scanInfo[kRoomType] as? String) ?? "", isVideo: isVideoUpload,partDesc: partInfo[kPartDesc] as? String ?? "")
                
                if let shootTime = scanInfo[kShootTime] as? Int {
                    var sec = shootTime / 1000
                    let min = sec / 60
                    sec = sec - (min * 60)
                    let nwSpeedValue = helperGetFormattedShootTime(timeMin: min, timeSec: sec)
                    
                    //let uploadTime = Int(UploadHelper.sharedInstance.uploadTimeStr ?? "1")
                    //let (min1,sec1) = ((uploadTime! % 3600) / 60, (uploadTime! % 3600) % 60)
                    //let uploadTimeValue = "\(min1) min \(sec1) secs"
                    self.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: "", isVideo: true)
                }else{
                    self.uploadSuccessUIUpdate(nwSpeedValue: "", uploadTimeValue: "", isVideo: true)
                }
            }
            scanInfo = nil
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        LogConfig.logD(message:"DISAPPEAR", displayToThirdParty: true)
        AppUtility.lockOrientation(.all)
        helperGetAppDeleate().allUploadScreen.currentScreen = Screens.none
    }
    
    func initialiseLoader(){
        let xPosition = viewLoader.center.x - 106
        let yPosition = viewLoader.center.y
        let position = CGPoint(x: xPosition, y: yPosition)
        
        
        progressRing = CircularProgressBar(radius: 80, position: position, innerTrackColor: Color.themeAquaColor, outerTrackColor: .clear, lineWidth: 5)
        let helper = UploadHelper.sharedInstance
        helper.uploadUpdateDelegate = self
    }
    
    func updateErrorMsg() {
        if (self.isScreenLoaded) {
//            if (UploadHelper.sharedInstance.showSSLError) {
//                lblErrorMsg1.text = "You are not logged in to your network"
//                lblErrorMsg2.text = "Please login to your network and "
//            } else {
//                lblErrorMsg1.text = "Network is not available"
//                lblErrorMsg2.text = "Check your connection and "
//            }
        }
    }
    
    func updateUI() {
       
        if self.lblVideoName.text == "" {
            self.fetchUploadingScanInfo()
            if (self.showNetworkDisconnection) {
                self.updateErrorMsg()
                self.viewNoNetwork.isHidden = false
                self.viewNoInternet.isHidden = true
                self.progressRing.removeFromSuperlayer()
            }
            
        } else {
            self.viewRetryUpload.isHidden = true
            if Int(self.progress * 100) == 100 {
                if (self.isUploadCompleted) {
                    self.lblUploading.text = "Upload Complete"
                }else{
                    self.lblUploading.text = "Finishing upload..."
                }
            }else {
                let newProgress = self.progress
                self.progressRing.progress = CGFloat(Int(newProgress*100))
                if !(self.viewLoader.layer.sublayers?.contains(self.progressRing) ?? false){
                    self.viewLoader.layer.addSublayer(self.progressRing)
                }
                self.lblUploading.text = "Uploading..."
            }
        }
    }
    
    func fetchUploadingScanInfo() {
        let partName: String = UserDefaults.standard.string(forKey: "uploadingPartName") ?? ""
        self.progress = UserDefaults.standard.float(forKey: "uploadProgress")
        self.lblVideoName.text = partName
        self.lblVideoAdditionalDetails.text = UserDefaults.standard.string(forKey: "uploadingPartDesc") ?? ""
//        updateUI()
    }
    
    func showNetworkDisconnectionScreen() {
        if (self.isScreenLoaded) {
            self.updateErrorMsg()
            self.viewNoNetwork.isHidden = false
            self.viewNoInternet.isHidden = true
            self.progressRing.removeFromSuperlayer()
            if helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                UploadHelper.sharedInstance.queueUpload()
            }
//            let subviews = helperGetAppDeleate().window?.subviews
//            if subviews!.contains(helperGetAppDeleate().snackBarView) {
//                helperGetAppDeleate().snackBarView.removeFromSuperview()
//            }
        }
    }
    
    func hideNetworkDisconnectionScreen() {
        if (self.isScreenLoaded) {
            self.showNetworkDisconnection = false
            self.viewNoNetwork.isHidden = true
            self.viewNoInternet.isHidden = true
            if !(self.viewLoader.layer.sublayers?.contains(self.progressRing) ?? false){
                self.viewLoader.layer.addSublayer(self.progressRing)
            }
            let newProgress = Int(self.progress * 100)
            self.progressRing.progress = CGFloat(newProgress)
            self.updateUI()
        }
    }
    
    func handleUploadCompletion(response:Any?, error: Error?){
        self.viewUploading.isHidden = true
        if let publicURL = response as? String{
            uploadedVideoUrl = publicURL
        }
    }
    
    //MARK: Actions
    @IBAction func btnViewResultsClicked(_ sender: UIButton){
//        let vc = ViewResultsViewController(nibName: "ViewResultsView", bundle: nil)
//        vc.publicURL = uploadedVideoUrl
//        self.navigationController?.navigationBar.isHidden = true
//        self.navigationController?.pushViewController(vc, animated: true)
        
//        let vc = AllUploadsViewController(nibName: "AllUploadsView", bundle: nil)
//        if let uploadData = tempUpload{
//            vc.arrayUploads = [uploadData]
//        }
//        self.navigationController?.navigationBar.isHidden = true
//        self.navigationController?.pushViewController(vc, animated: true)
        
        helperGetAppDeleate().allUploadScreen.isFromUploadScreen = true
        if helperGetAppDeleate().navigation.contains(helperGetAppDeleate().allUploadScreen){
            helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().allUploadScreen, animated: false)
        }else{
            helperGetAppDeleate().makeRootController(controller: helperGetAppDeleate().allUploadScreen)
        }
    }
    
    @IBAction func btnCameraClicked(_ sender: UIButton){
        if helperGetAppDeleate().isMeasurement {
            if UserSession.shared.isDontShowTargetScreenSet(){
                let cameraStartScreen = CameraScreen()
                cameraStartScreen.fromDownloadScreen = false
                helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
            }else{
                if  helperGetAppDeleate().navigation.viewControllers.contains(helperGetAppDeleate().targetScreen){
                    helperGetAppDeleate().navigation.popToViewController(helperGetAppDeleate().targetScreen, animated: false)
                    
                }else{
                    helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().targetScreen, animated: true)
                }
            }
        }else{
            let cameraStartScreen = CameraScreen()
            cameraStartScreen.fromDownloadScreen = false
            helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
        }
        helperGetAppDeleate().hideActivityView()
    }
    
    @IBAction func dismissView(){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnRetryForNetworkClicked(_ sender: Any) {
        LogConfig.logD(message:"UploadScreen - Retry Connection Clicked", displayToThirdParty: true)
        if !NetStatus.shared.isConnected {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Internet is unavailable please check your network and try again")
        } else {
            if !helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                if !helperGetAppDeleate().isOffline {
                    self.showNetworkDisconnection = false
                    UploadHelper.sharedInstance.videoFileName = ""
                    UploadHelper.sharedInstance.changeFromRetryToQueued()
                    self.hideNetworkDisconnectionScreen()
                    if uploadInProgress{
                        viewNoUploads.isHidden = true
                    }
                }
            }
        }
    }
    
    @IBAction func btnRetryForServerErrorClicked(_ sender: Any) {
        LogConfig.logD(message:"UploadScreen - Retry upload due to server error clicked", displayToThirdParty: true)
        if !NetStatus.shared.isConnected {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Internet is unavailable please check your network and try again")
        } else {
            if unitNameForFailedUpload != ""{
                UploadHelper.sharedInstance.retryUpload(unitName: unitNameForFailedUpload, callback: {
                    
                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                        //this
                        debugPrint("THIS IS WHERE")
                        helperGetAppDeleate().allUploadScreen.setupScanDetails()
                    }
                })
                LogConfig.logD(message:"Retry Upload clicked", displayToThirdParty: true)
            }
        }
    }
    
    ///UploadScreen specific Network changes handling
     func handleNetworkChange() {
         LogConfig.logD(message:"Network Changed - Handle Network change called", displayToThirdParty: true)
         
         if NetStatus.shared.isConnected {
             LogConfig.logD(message:"Network Connected BACK", displayToThirdParty: true)
             DispatchQueue.main.async {
                 if !(self.isUploadCompleted) {
                     UploadHelper.sharedInstance.showSSLError = false
                     self.viewNoNetwork.isHidden = true
                     self.viewNoInternet.isHidden = true
                     if !(self.viewLoader.layer.sublayers?.contains(self.progressRing) ?? false){
                         self.viewLoader.layer.addSublayer(self.progressRing)
                     }
                     let newProgress = Int(self.progress * 100)
                     self.progressRing.progress = CGFloat(newProgress)
                     
                     if !helperGetAppDeleate().dbWrapper.checkForJobsUploading() {
                         if !helperGetAppDeleate().isOffline {
                             if helperGetAppDeleate().allUploadScreen.currentScreen == .uploadScreen {
                                UploadHelper.sharedInstance.videoFileName = ""
                                 UploadHelper.sharedInstance.changeFromRetryToQueued()
                                 if self.uploadInProgress{
                                     self.viewNoUploads.isHidden = true
                                 }
                             }
                         }
                     }
                 }
             }
         } else {
             LogConfig.logD(message:"Network Disconnected", displayToThirdParty: true)
             DispatchQueue.main.async {
                 
                 UploadHelper.sharedInstance.showSSLError = false
                 self.updateErrorMsg()
                 self.viewNoNetwork.isHidden = false
                 self.viewNoInternet.isHidden = true
                 self.progressRing.removeFromSuperlayer()
                 
//                 if (self.isUploadCompleted || Int(self.progress * 100) == 100) {
//                     //If network is disconnected and upload was completed, don't change the view
//                     return
//                 } else {
//                     //If network is disconnected and upload was not completed,
//                     //show the error message and No Internet view
//                     if !(self.isUploadCompleted) {
//                         UploadHelper.sharedInstance.showSSLError = false
//                         self.updateErrorMsg()
//                         self.viewNoNetwork.isHidden = false
//                         self.viewNoInternet.isHidden = true
//                         self.progressRing.removeFromSuperlayer()
////                         let subviews = helperGetAppDeleate().window?.subviews
////                         if subviews!.contains(helperGetAppDeleate().snackBarView) {
////                             helperGetAppDeleate().snackBarView.removeFromSuperview()
////                         }
//                     }else {
//                         //Show retry screen for the first time when upload is interrupted
////
//                     }
//                 }
             }
         }
     }
}

extension UploadViewController: UploadUpdateDelegate {
    func textInfoUpdated(projectName: String, windowName: String, uploadCount: Int, totalUploadsCount: Int, progress: Float, location: String, isVideo: Bool,partDesc:String) {
        LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
        LogConfig.logD(message:"Part Name - \(projectName), Scan Name - \(windowName), Uploaded Image Count - \(uploadCount), Total Image Count - \(totalUploadsCount), Progress - \(progress), Video Duration - \(location), isVideo - \(isVideo)", displayToThirdParty: true)
        LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
        
        self.isUploadCompleted = false
        self.progress = progress
       
//        if projectName.contains("-"){
//            let projectName = projectName.components(separatedBy: "-")
//            self.lblVideoName.text = projectName[0]
//        }
        DispatchQueue.main.async {
            if (self.isScreenLoaded) {
                self.lblVideoName.text = projectName
                self.lblVideoAdditionalDetails.text = partDesc
                self.updateUI()
                self.hideNetworkDisconnectionScreen()
            }
        }
        
    }
    
    func uploadStartTimeUpdated(time: String, isVideo: Bool) {
        DispatchQueue.main.async {
            if (self.isScreenLoaded) {
                self.updateUI()
                self.hideNetworkDisconnectionScreen()
            }
        }
        
        LogConfig.logD(message:"Upload Started: \(time)", displayToThirdParty: true)
    }
    
    func uploadSuccessUIUpdate(nwSpeedValue: String, uploadTimeValue: String, isVideo: Bool) {
        LogConfig.logD(message:"Upload Completed", displayToThirdParty: true)
        DispatchQueue.main.async {
            self.isUploadCompleted = true
            if (self.isScreenLoaded) {
                self.updateUI()
                self.hideNetworkDisconnectionScreen()
            }
        }
    }
    
    func updateNetworkSpeed(speed: String) {
        
    }
    
    func percentageUpdated(uploadedImgCount: Int, totalImgCount: Int, progress: Float, isVideo: Bool) {
        let newProgress = progress
//        self.progressRing.progress = CGFloat(Int(newProgress*100))
        LogConfig.logD(message:"Got new progress \(newProgress)", displayToThirdParty: true)
        
        
        DispatchQueue.main.async {
            if (self.isScreenLoaded) {
                self.progress = newProgress
                self.updateUI()
                if !self.viewNoNetwork.isHidden || !self.viewNoInternet.isHidden {
                    self.hideNetworkDisconnectionScreen()
                }
            }
        }
    }
    
    func uploadFailed(for scanID: String, isInternetAvailable: Bool) {
        if self.isScreenLoaded{
            unitNameForFailedUpload = scanID
            if isInternetAvailable{
                viewRetryUpload.isHidden = false
            }else{
                viewNoInternet.isHidden = false
            }
            
        }
    }
}


