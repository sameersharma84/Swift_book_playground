//
//  DownloadPDFScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 08/01/22.
//

import UIKit

class DownloadPDFScreen: UIViewController {
    
    @IBOutlet var btnNext: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        enableBtnNext(isTrue: false)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
    }
    
    func enableBtnNext(isTrue: Bool){
        btnNext.alpha = isTrue ? 1 : 0.44
        btnNext.isEnabled = isTrue
    }
    
    @IBAction func downloadPressed(_ sender: UIButton) {
        
        if let pdf = Bundle.main.url(forResource: "PhotoGAUGE_Target", withExtension: "pdf", subdirectory: nil, localization: nil)  {
            enableBtnNext(isTrue: true)
            self.sharePdf(path: pdf)
        }
    }
    
    @IBAction func nextPressed(_ sender: UIButton) {
        let cameraStartScreen = CameraScreen()
        cameraStartScreen.fromDownloadScreen = true
        helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
    }
    
    func sharePdf(path:URL) {

        let fileManager = FileManager.default

        if fileManager.fileExists(atPath: path.path) {
            let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [path], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            self.present(activityViewController, animated: true, completion: nil)
        } else {
            print("document was not found")
//            let alertController = UIAlertController(title: "Error", message: "Document was not found!", preferredStyle: .alert)
//            let defaultAction = UIAlertAction.init(title: "ok", style: UIAlertAction.Style.default, handler: nil)
//            alertController.addAction(defaultAction)
//            UIViewController.hk_currentViewController()?.present(alertController, animated: true, completion: nil)
        }
    }
}
