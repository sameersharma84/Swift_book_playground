//
//  ScanTipsViewController.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 30/05/22.
//

import UIKit
import AVFoundation
import AVKit

class ScanTipsViewController: UIViewController {

    @IBOutlet weak var collectionPagerView: UICollectionView!
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var btnDontShowMeAgain: UIButton!
    @IBOutlet weak var pagerControl: UIPageControl!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var splashView: UIView!
    @IBOutlet weak var animationImgView: UIImageView!
    @IBOutlet weak var playerSeekBar: UISlider!
    @IBOutlet weak var lblVideoTimer: UILabel!
    @IBOutlet weak var playerControls: UIView!
    @IBOutlet weak var playPauseImage:UIImageView!
    
    
    var scanTipsData : [[ScanTips]] = [];
    var playerViewController : AVPlayerViewController!
    var player : AVPlayer!
    var playerLayer : AVPlayerLayer!
    var videoURLString = String()
    var isVideoPlaying = false {
        didSet{
            debugPrint(oldValue,"===",isVideoPlaying)
            if oldValue !=  isVideoPlaying{
                playAndStop()
            }
            
        }
    }
    var imgCntForAnimation = 0
    var animationTimer : Timer!
    var isScreenLive = false
    var isComeFromSideMenu : Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"Scan Tips - View Did Load", displayToThirdParty: true)
        loadData()
        self.pagerControl.currentPage = 0
        collectionPagerView.register(UINib.init(nibName: "ScanTipsScreenPagerCell", bundle: nil), forCellWithReuseIdentifier: "ScanTipsScreenPagerCell")
        collectionPagerView.delegate = self
        collectionPagerView.dataSource = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(videoDidEnd), name:
        NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: nil)
        
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.onClickOnPlayer))
        playerView.addGestureRecognizer(tap)
        
        if isComeFromSideMenu {
            btnDontShowMeAgain.isHidden = true
        }
        
        // Do any additional setup after loading the view.
    }
    
    func downloadOrStartVideo(){
        if UserSession.shared.getUserData() == nil {
            loadPlayer()
        }else{
            if UserSession.shared.getVideoTipsUrlByMeasurement() == ""{
                if UserSession.shared.isVideoTipsDownloading(){
                    showLoadingScreenWithAnimation()
                }else{
                    callGetVideoTipsApi()
                }
            }else{
                loadPlayer()
            }
        }
    }
    
    @objc func onClickOnPlayer(){
        playerControls.isHidden = !playerControls.isHidden
    }
    
    @IBAction func seekBarValueChange(_ sender: Any) {
        let seconds : Int64 = Int64(playerSeekBar.value)
        let targetTime:CMTime = CMTimeMake(value: seconds, timescale: 1)
        player.seek(to: targetTime)
        if player.rate == 0{
            player.play()
        }
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        UserDefaults.standard.addObserver(self, forKeyPath: "isVideoTipsDownloading", options: [.new], context: nil)
        debugPrint("add observer for video tips downloading")
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
        isScreenLive = true
        if player == nil {
            downloadOrStartVideo()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if keyPath == "currentItem.loadedTimeRanges" {
            if playerView.isHidden {
                let seconds = 0.5
                DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                    self.isVideoPlaying = true
                    self.splashView.isHidden = true
                    self.playerView.isHidden = false
                    if let duration = self.player.currentItem?.duration {
                        let seconds = CMTimeGetSeconds(duration)
                        self.playerSeekBar.minimumValue = 0
                        self.playerSeekBar.maximumValue = Float(seconds)
                    
                        let secondsText = Int(seconds) % 60
                        let minutesText = String(format: "%02d", Int(seconds) / 60)
                        self.lblVideoTimer.text = "\(minutesText):\(secondsText)"
                    }
                }
                
            }
        }else{
            guard let _ = change, object != nil, keyPath == "isVideoTipsDownloading" else { return }
            DispatchQueue.main.async {
                if !UserSession.shared.isVideoTipsDownloading()  && self.isScreenLive {
                    self.loadPlayer()
                }
            }
        }
        
        
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        UserDefaults.standard.removeObserver(self, forKeyPath: "isVideoTipsDownloading")
        debugPrint("remove observer for video tips downloading")
        AppUtility.lockOrientation(.all)
        stopAnimation()
        isVideoPlaying = false
        isScreenLive = false
    }
    
    @IBAction func onClickFullScreen(_ sender: Any) {
        if isVideoPlaying {
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
        
    }
    
    override func viewDidLayoutSubviews() {
        if playerLayer != nil {
            playerLayer.frame = playerView.bounds
        }
    }
    
    func loadData() {
        scanTipsData.append([
            ScanTips.init(image: "setup_environment", title: "Set up the environment", descritpion: "Place the object or the person you want to scan to stand somewhere where you can walk around."),
            ScanTips.init(image: "proper_lightening", title: "Proper lightening", descritpion: "Either it is indoors or outdoors, it is recommended that you use bright light that spreads equally around the object")
        ])
        scanTipsData.append([
            ScanTips.init(image: "adjust_your_position", title: "Adjust your position", descritpion: "Make sure your object fits the mobile screen, try to keep an equal distance when you scan around the object."),
            ScanTips.init(image: "record_4k_video", title: "Record a 4K video", descritpion: "Adjust your camera settings to 4K mode for a better video quality\nHow to switch to 4K mode")
        ])
    }

    @IBAction func onClickClose(_ sender: Any) {
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func onClickDontShowMeAgain(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        UserSession.shared.setDontShowScanTipsScreen(isSet: sender.isSelected)
        
    }
    
    @IBAction func onClickPageControl(_ sender: Any) {
        var goToPage = 0
        if pagerControl.currentPage < scanTipsData.count - 1{
            goToPage = 1
        }
        collectionPagerView.scrollToItem(at: IndexPath.init(item: goToPage, section: 0), at: .right, animated:true)
    }
    
    @IBAction func onClickNext(_ sender: Any) {
        if pagerControl.currentPage < scanTipsData.count - 1{
            collectionPagerView.scrollToItem(at: IndexPath.init(item: pagerControl.currentPage + 1, section: 0), at: .right, animated:true)
            return
        }else{
            if isComeFromSideMenu {
                collectionPagerView.scrollToItem(at: IndexPath.init(item: pagerControl.currentPage - 1, section: 0), at: .right, animated:true)
                return
            }
        }
        if helperGetAppDeleate().isMeasurement {
            if UserSession.shared.isDontShowTargetScreenSet() {
                let cameraStartScreen = CameraScreen()
                cameraStartScreen.fromDownloadScreen = false
                helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
            }else{
                helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().targetScreen, animated: true)
            }
        }else{
            let cameraStartScreen = CameraScreen()
            cameraStartScreen.fromDownloadScreen = false
            helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
        }
        
    }
    
    func playAndStop(){
        debugPrint("Play and Pause====")
        if isVideoPlaying {
            player.play()
            playPauseImage.image = #imageLiteral(resourceName: "video_pause")
        }else{
            player.pause()
            playPauseImage.image = #imageLiteral(resourceName: "video_play")
        }
    }
    
    @objc func videoDidEnd(notification: NSNotification) {
        print("video ended")
        isVideoPlaying = false
        loadPlayer()
    }
    
    func loadPlayer() {
        if playerLayer != nil {
            self.playerLayer.removeFromSuperlayer()
        }
        
        let strVideoUrl = UserSession.shared.getVideoTipsUrlByMeasurement()
        var videoUrl: URL!
        if strVideoUrl != "" {
            do {
                let documentsURL = try
                    FileManager.default.url(for: .documentDirectory,
                                            in: .userDomainMask,
                                            appropriateFor: nil,
                                            create: false)
                videoUrl = documentsURL.appendingPathComponent(strVideoUrl)
                
                if !FileManager.default.fileExists(atPath: videoUrl.path){
                    callGetVideoTipsApi()
                    return
                }
            }catch{}
        }
        
        if videoUrl == nil {
            if let strFinalUrl = Bundle.main.path(forResource: "video-tips-sample", ofType: "mp4"){
                videoUrl = URL.init(fileURLWithPath: strFinalUrl)
            }
        }
        
        if let url = videoUrl {

            let playerItem:AVPlayerItem = AVPlayerItem(url: url)
            player = AVPlayer(playerItem: playerItem)
            playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = playerView.bounds
            playerLayer.videoGravity = .resizeAspectFill
            playerView.layer.addSublayer(playerLayer)
            player.seek(to: CMTime.zero)
           
            
            player.addPeriodicTimeObserver(forInterval: CMTimeMakeWithSeconds(1, preferredTimescale: 1), queue: nil, using: {
                (CMTime) -> Void in
                
                if self.player.currentItem?.status == .readyToPlay {
                    let currentTimeSeconds  = CMTimeGetSeconds(self.player.currentTime());
                    let currentTimeSecondsIntVal      = Int(currentTimeSeconds) % 60
                    let currentTimeMinutesText = String(format: "%02d", Int(currentTimeSecondsIntVal) / 60)
                    
                    
                    self.playerSeekBar.value = Float(currentTimeSeconds);
                    
                    
                    let durationSeconds            = CMTimeGetSeconds(playerItem.asset.duration);
                    let durationSecondsIntVal      = Int(durationSeconds) % 60
                    let durationMinutesText = String(format: "%02d", Int(durationSecondsIntVal) / 60)
                    self.lblVideoTimer.text = "\(currentTimeMinutesText):\(String(format: "%02d", currentTimeSecondsIntVal)) / \(durationMinutesText):\(String(format: "%02d", durationSecondsIntVal))"
                }
                
            })

            
            player.addObserver(self, forKeyPath: "currentItem.loadedTimeRanges", options: .new, context: nil)

        }
    }
    
    @IBAction func onClickPlayAndPause(_ sender: Any) {
        isVideoPlaying = !isVideoPlaying
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ScanTipsViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ScanTipsScreenPagerCell", for: indexPath as IndexPath) as! ScanTipsScreenPagerCell
        
        cell.setupCellWtihData(arrData:scanTipsData[indexPath.item])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        self.pagerControl.currentPage = indexPath.item
        
        if indexPath.item == scanTipsData.count - 1 {
            if isComeFromSideMenu {
                btnNext.setTitle("Previous", for: .normal)
            }else{
                btnNext.setTitle("Scan", for: .normal)
            }
        }else{
            btnNext.setTitle("Next", for: .normal)
        }
    }
   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: self.view.frame.width, height: 240)
    }
}

// Loading Screen
extension ScanTipsViewController{
    
    func showLoadingScreenWithAnimation(){
        splashView.isHidden = false
        updateAnimationImage()
        animationTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateAnimationImage), userInfo: nil, repeats: true)
    }
    
    @objc func updateAnimationImage() {
        if imgCntForAnimation == 4{
            imgCntForAnimation = 0
        }
        imgCntForAnimation = imgCntForAnimation + 1
        animationImgView.image = UIImage.init(named: "download_img_anim_\(imgCntForAnimation)")
    }
    
    func stopAnimation(){
        splashView.isHidden = true
        if animationTimer != nil {
            animationTimer.invalidate()
            animationTimer = nil
        }
    }
}

extension ScanTipsViewController: ServerWrapperDelegate{
    func callGetVideoTipsApi(){
        showLoadingScreenWithAnimation()
        APIClient.delegate = self
        APIClient.videoTipsByMeasurement(for: UserSession.shared.getMeasurementTypeForServerUse())
    }
    
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for requestId - \(requestId), errorInfo - \(errorInfo)", displayToThirdParty: true)
        stopAnimation()
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message )
        loadPlayer()
    }
    
    func videoTipsUrlReceive(_ results: VideoTipsByMeasurement) {
        print("Video Tips Url",results.tipsURL)
        DownloadHelper.sharedInstance.downloadVideo(strVideoUrl: results.tipsURL)
    }
    
}

