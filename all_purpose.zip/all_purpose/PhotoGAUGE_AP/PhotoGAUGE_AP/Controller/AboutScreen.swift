//
//  AboutViewController.swift
//  PhotoGauge
//
//  Created by User on 8/20/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import UIKit

class AboutScreen: UIViewController {

    @IBOutlet weak var versionLbl: UILabel!
    @IBOutlet weak var releaseDateLbl: UILabel!
//    @IBOutlet weak var topContView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"AboutScreen - viewDidLoad", displayToThirdParty: true)
        setupScreen()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
    }
    
    func setupScreen() {
        let version = helperGetAppVersion()
        versionLbl.text = "v\(version)"
        releaseDateLbl.text = helperGetCurrentDate()
    }

    @IBAction func backPressed(_ sender: UIButton) {
        LogConfig.logD(message:"AboutScreen - Back Button Clicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
}
