//
//  ProfileViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 18/01/22.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var profileNameLbl: UILabel!
    @IBOutlet weak var profileEmailLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"Profile - view did load", displayToThirdParty: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        let loginInfo = UserSession.shared.getUserData()
        self.profileNameLbl.text = (loginInfo?.accountName)
        self.profileEmailLbl.text = (loginInfo?.accountEmail)
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
    }
   
    @IBAction func changePassword(){
        let changePassword = ChangePasswordScreen()
        helperGetAppDeleate().navigation.pushViewController(changePassword, animated: true)
    }
  
    @IBAction func backButtonPressed(_ sender: UIButton) {
        LogConfig.logD(message:"Profile - Back Button Clicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }

}
