//
//  SettingsViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 30/12/21.
//

import UIKit
import GoogleSignIn

class SettingsViewController: UIViewController {

    @IBOutlet weak var profileNameLbl: UILabel!
    @IBOutlet weak var profileEmailLbl: UILabel!
    @IBOutlet weak var settingsTableView: UITableView!
    @IBOutlet var logoutView: UIView!
    @IBOutlet weak var logoutDialogView: UIView!
    @IBOutlet weak var lblLogoutText: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"Settings - viewDidLoad", displayToThirdParty: true)
        let nib = UINib.init(nibName: "SettingTableViewCell", bundle: nil)
        settingsTableView.register(nib, forCellReuseIdentifier: "SettingTableViewCell")
        settingsTableView.delegate = self
        settingsTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
        let loginInfo = UserSession.shared.getUserData()
        self.profileNameLbl.text = (loginInfo?.accountName)
        self.profileEmailLbl.text = (loginInfo?.accountEmail)
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
        LogConfig.logD(message:"VIEW WILL DIS APPEAR", displayToThirdParty: true)
    }
    
    //MARK: Actions
    @IBAction func backButtonPressed(_ sender: UIButton) {
        LogConfig.logD(message:"Settings - Back Button Clicked", displayToThirdParty: true)
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func logoutAction(_ sender: UIButton) {
        if sender.titleLabel?.text == "YES"{
            LogConfig.logD(message:"Logout - Yes Button Clicked", displayToThirdParty: true)
            self.resetDefaults()
            helperGetAppDeleate().dbWrapper.dropTables()
            helperGetAppDeleate().allUploadScreen.stopEtagTimer()
            AWSS3Manager.shared.cancelUploads(callback: {
                UploadHelper.sharedInstance.timer.invalidate()
            })
            deleteAllScanFiles()
            GIDSignIn.sharedInstance.signOut()
            UserSession.shared.removeUserSelection()
            UserSession.shared.removeDontShowMeAgain()
            helperGetAppDeleate().allUploadScreen.firstLoad = true
            let loginScreen = LoginScreen()
            helperGetAppDeleate().navigation.setViewControllers([loginScreen], animated: false)
        }else{
            LogConfig.logD(message:"Logout - No Button Clicked", displayToThirdParty: true)
            self.logoutView.removeFromSuperview()
        }
    }
    
    @IBAction func dismissView(_ sender: UIButton) {
        LogConfig.logD(message:"Dismiss Button Clicked", displayToThirdParty: true)
        self.logoutView.removeFromSuperview()
    }
    
    func showLogoutDialog() {
        let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        let (_, queuedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsQueued()
        let (_, pausedJobs) = helperGetAppDeleate().dbWrapper.checkForJobsPaused()
        var logoutStr: String = "Do you want to logout?"
        if uploadingJobs.count + queuedJobs.count + pausedJobs.count > 0 {
            logoutStr = "Jobs Status\n\nQueued: \(queuedJobs.count)\nPaused: \(pausedJobs.count)\nUploading: \(uploadingJobs.count)\n\nIf you logout, you will lose the data.\nDo you still want to logout?"
        }
        self.lblLogoutText.text = logoutStr
        logoutView.center = CGPoint(x: self.view.frame.size.width / 2,
                                         y: self.view.frame.size.height / 2)
        self.view.addSubview(logoutView)
    }
    
    func deleteAllScanFiles() {
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            for eachUrl in fileURLs{
                let urlString = eachUrl.absoluteString
                let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
                let documentsDirectory = paths[0] as String
                
                let fileName = urlString.components(separatedBy: documentsDirectory)
                if fileName[1] != "/parts.sqlite3" && fileName[1] != "/logFile.txt"{
                    if fileManager.fileExists(atPath: eachUrl.path) {
                        try? fileManager.removeItem(at: eachUrl)
                        LogConfig.logD(message:"Removed SCANs FOLDER from Local Directory", displayToThirdParty: true)
                    }
                }
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
        }
    }
    
    
    func resetDefaults() {
        let environment = UserDefaults.standard.value(forKey: kEnvironment)
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()
        dictionary.keys.forEach { key in
            defaults.removeObject(forKey: key)
        }
        UserDefaults.standard.set(false, forKey: kLoggedIn)
        UserDefaults.standard.set(false, forKey: kHasAllParts)
        UserDefaults.standard.setValue(environment, forKey: kEnvironment)
        UserDefaults.standard.removeObject(forKey: kNoParts)
    }
    
    func checkForUpdates(){
        _ = try? isUpdateAvailable { (update, error) in
            if let error = error {
                print(error)
            } else if let update = update {
                print(update)
            }
        }
    }
    
    func isUpdateAvailable(completion: @escaping (Bool?, Error?) -> Void) throws -> URLSessionDataTask {
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
      
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            do {
                if let error = error { throw error }
                guard let data = data else { throw VersionError.invalidResponse }
                let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any]
                guard let result = (json?["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String else {
                    throw VersionError.invalidResponse
                }
                completion(version != currentVersion, nil)
            } catch {
                completion(nil, error)
            }
        }
        task.resume()
        return task
    }

}

extension SettingsViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        LogConfig.logD(message:"Table DataSource Method called", displayToThirdParty: true)
        return 6
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "SettingTableViewCell") as? SettingTableViewCell {
            switch indexPath.row {
            case 0:
                cell.settingLbl.text = str_change_password
                cell.imgView.image = UIImage(named: "lock")
                break
            case 1:
                cell.settingLbl.text = str_check_updates
                cell.imgView.image = UIImage(named: "Check for updates")
                break
            case 2:
                cell.settingLbl.text = str_send_debug_info
                cell.imgView.image = UIImage(named: "mailIcon")
                break
            case 3:
                cell.settingLbl.text = str_download_pdf
                cell.imgView.image = UIImage(named: "PDF-settings")
                break
            case 4:
                cell.settingLbl.text = str_about
                cell.imgView.image = UIImage(named: "info")
                break
            case 5:
                cell.settingLbl.text = str_logout
                cell.imgView.image = UIImage(named: "Logout")
                break
            default:
                break
            }
            cell.selectionStyle = .none
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        LogConfig.logD(message:"Row \(indexPath.row) selected", displayToThirdParty: true)
        switch indexPath.row {
        case 0:
            let changePassword = ChangePasswordScreen()
            helperGetAppDeleate().navigation.pushViewController(changePassword, animated: true)
            break
        case 1:
            checkForUpdates()
            break
        case 2:
            shareLogFile()
            break
        case 3:
            if let pdf = Bundle.main.url(forResource: "PhotoGAUGE_Target", withExtension: "pdf", subdirectory: nil, localization: nil)  {
                self.sharePdf(path: pdf)
            }
            break
        case 4:
            let aboutScreen = AboutScreen()
            helperGetAppDeleate().navigation.pushViewController(aboutScreen, animated: true)
            break
        case 5:
            if helperGetAppDeleate().isOffline {
                helperGetAppDeleate().showAlert(titleStr: "Error", msg: "You are offline. Logout feature is only available online")
            }else if helperGetAppDeleate().dbWrapper.checkForJobsUpdating() {
                helperGetAppDeleate().showAlert(titleStr: "", msg: "Scan Updating in Progress.")
            } else {
                self.showLogoutDialog()
            }
            break
        default:
            break
        }
        
    }
    
    func shareLogFile() {
        let filePath = helperGetLogFile()
        var filesToShare = [Any]()
        filesToShare.append(filePath)
        let activityViewController = UIActivityViewController(activityItems: filesToShare, applicationActivities: nil)
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    func sharePdf(path:URL) {

        let fileManager = FileManager.default

        if fileManager.fileExists(atPath: path.path) {
            let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [path], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            self.present(activityViewController, animated: true, completion: nil)
        } else {
            print("document was not found")
//            let alertController = UIAlertController(title: "Error", message: "Document was not found!", preferredStyle: .alert)
//            let defaultAction = UIAlertAction.init(title: "ok", style: UIAlertAction.Style.default, handler: nil)
//            alertController.addAction(defaultAction)
//            UIViewController.hk_currentViewController()?.present(alertController, animated: true, completion: nil)
        }
    }
    
    
}

enum VersionError: Error {
    case invalidResponse, invalidBundleInfo
}
