//
//  SelectionViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 10/01/22.
//

import UIKit

class SelectionViewController: UIViewController {
    @IBOutlet var selectionButtons: [ButtonWithShadow]!
    @IBOutlet var btnNext: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
       
    
    }

    override func viewWillAppear(_ animated: Bool) {
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        for button in selectionButtons{
            button.borderColor = Color.themeSelectionGreyColor
            button.isSelected = false
        }
        enableBtnNext(isTrue: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.portrait)
    }
    
    func enableBtnNext(isTrue: Bool){
        btnNext.alpha = isTrue ? 1 : 0.44
        btnNext.isEnabled = isTrue
    }
    
    
    @IBAction func btnSelectClicked(_ sender: ButtonWithShadow){
        for button in selectionButtons{
            button.borderColor = Color.themeSelectionGreyColor
            button.isSelected = false
        }
        sender.isSelected = true
        sender.borderColor = Color.themeSelectionBlueColor
        enableBtnNext(isTrue: true)
        
        if sender.tag == 100 {
            //measurements
            helperGetAppDeleate().isMeasurement = true
        }else {
            //digital twin
            helperGetAppDeleate().isMeasurement = false
        }
    }
    
    @IBAction func btnNextClicked(_ sender: UIButton){
        for btn in selectionButtons{
            if btn.isSelected{
                if btn.titleLabel?.text == str_3d_model {
                    UserSession.shared.set(userSelection: str_3d_model)
                }else{
                    UserSession.shared.set(userSelection: str_measurements)
                }
                break;
            }
        }
        
        helperGetAppDeleate().navigation.pushViewController(helperGetAppDeleate().homeScreen, animated: true)
    }
    
    @IBAction func learnMoreClicked(_ sender: UIButton) {
        let learnMoreScreen = LearnMoreScreen()
        helperGetAppDeleate().navigation.present(learnMoreScreen, animated: true)
    }
    
}
