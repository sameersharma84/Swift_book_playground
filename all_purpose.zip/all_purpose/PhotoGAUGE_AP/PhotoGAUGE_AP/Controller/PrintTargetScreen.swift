//
//  PrintTargetScreen.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 08/01/22.
//

import UIKit

class PrintTargetScreen: UIViewController {

    @IBOutlet weak var alreadyHaveOneBtn: UIButton!
    @IBOutlet weak var dontHaveOneBtn: UIButton!
    @IBOutlet weak var dontShowAgainBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        self.alreadyHaveOneBtn.isSelected = true
        self.dontHaveOneBtn.isSelected = false
        self.dontShowAgainBtn.isSelected = false
//        let isDontShowMeSet = UserSession.shared.isDontShowTargetScreenSet()
        if let countOfDontSHowMeAgain = UserSession.shared.getDontShowMeAgain(), countOfDontSHowMeAgain > 0{
            dontShowAgainBtn.isHidden = false
        }else{
            dontShowAgainBtn.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.all)
    }

    @IBAction func nextPressed(_ sender: UIButton) {
        if alreadyHaveOneBtn.isSelected {
            launchCameraScreen()
        }else{
            launchDownloadScreen()
        }
    }
    
    @IBAction func radioButtonsPressed(_ sender: UIButton) {
        switch sender.tag {
        case 100:
            self.alreadyHaveOneBtn.isSelected = true
            self.dontHaveOneBtn.isSelected = false
            break
        case 101:
            self.alreadyHaveOneBtn.isSelected = false
            self.dontHaveOneBtn.isSelected = true
            break
        default:
            self.alreadyHaveOneBtn.isSelected = true
            self.dontHaveOneBtn.isSelected = false
            break
        }
    }
    
    @IBAction func dontshowmeagain(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        UserSession.shared.setDontShowTargetScreen(isSet: sender.isSelected)
    }
    
    func launchCameraScreen() {
        UserSession.shared.setDontShowTargetCount()
        let cameraStartScreen = CameraScreen()
        cameraStartScreen.fromDownloadScreen = false
        helperGetAppDeleate().navigation.pushViewController(cameraStartScreen, animated: true)
    }
    
    func launchDownloadScreen() {
        UserSession.shared.setDontShowTargetCount()
        let downloadPDF = DownloadPDFScreen()
        helperGetAppDeleate().navigation.pushViewController(downloadPDF, animated: true)
    }
}
