//
//  LoginViewController.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
