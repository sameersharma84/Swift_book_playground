//
//  SignUpController.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 17/05/22.
//

import UIKit

class SignUpController: UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var confirmPasswordTF: UITextField!
    @IBOutlet weak var loginTxtView: UITextView!
    @IBOutlet weak var viewBack: UIView!
    var loginRequest : LoginRequest!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogConfig.logD(message:"SignUp - viewDidLoad", displayToThirdParty: true)
        setUpScreen()
        
        if UserSession.shared.isUserTypeGuest(){
            loginTxtView.isHidden = true
        }else{
            viewBack.isHidden = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        LogConfig.logD(message:"viewwillappear", displayToThirdParty: true)
        super.viewWillAppear(true)
        AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)
        helperCheckAuthTokenExpiry()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        LogConfig.logD(message:"viewwilldisappear", displayToThirdParty: true)
        super.viewWillDisappear(true)
        AppUtility.lockOrientation(.portrait)
    }
    
    func makeLoginLink(){
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = .center
        let attributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.init(name: "SFProText-Regular", size: 16) ?? UIFont.systemFont(ofSize: 16),
            .paragraphStyle: paragraph
        ]
        let attributedString = NSMutableAttributedString(string: "Already have an account? Login!",attributes: attributes)
        
        attributedString.addAttribute(.link, value: "login://alreadyHaveAccount", range: (attributedString.string as NSString).range(of: "Login!"))
        loginTxtView.attributedText = attributedString
        loginTxtView.isEditable = false
        loginTxtView.linkTextAttributes = [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0.00800000038, green: 0.5329999924, blue: 0.7289999723, alpha: 1)]
    }
    
    func setUpScreen(){
        makeLoginLink()
    }
    
    @IBAction func passwordEyeAction(_ sender: UIButton) {
        if passwordTF.isSecureTextEntry {
            passwordTF.isSecureTextEntry = false
            sender.setImage(UIImage(named: "eye"), for: .normal)
        } else {
            passwordTF.isSecureTextEntry = true
            sender.setImage(UIImage(named: "eye_hide"), for: .normal)
        }
    }
    
    @IBAction func confirmPasswordEyeAction(_ sender: UIButton) {
        if confirmPasswordTF.isSecureTextEntry {
            confirmPasswordTF.isSecureTextEntry = false
            sender.setImage(UIImage(named: "eye"), for: .normal)
        } else {
            confirmPasswordTF.isSecureTextEntry = true
            sender.setImage(UIImage(named: "eye_hide"), for: .normal)
        }
    }
    
    func validateSignUpRequest() -> SignUpRequest? {
        let emailId = helperGetTrimmedString(str: emailTF.text!)
        let password = helperGetTrimmedString(str: passwordTF.text!)
        let confirmPassword = helperGetTrimmedString(str: confirmPasswordTF.text!)
        let isValidEmail = validateEmail(email: emailId)
        
        if emailId == "" {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_email)
        }else if password == "" {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_enter_password)
        }else if confirmPassword == "" {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_please_confirm_enter_password)
        }else if confirmPassword != password {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_password_confirm_password_not_match)
        }else if !isValidEmail {
            helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_invalid_email)
        }else{
            loginRequest = LoginRequest(loginId: emailId, timezone: "0", password: password)
            return SignUpRequest.init(loginId: emailId, timezone: "330.0", password: password, deviceUUID: UserSession.shared.getDeviceUUID())
        }
        
        return nil
    }
    
    @IBAction func onClickCancel(_ sender: Any) {
        helperGetAppDeleate().navigation.popViewController(animated: true)
    }
    
    @IBAction func createAccountAction(_ sender: UIButton) {
        LogConfig.logD(message:"SignUp Clicked", displayToThirdParty: true)
        helperDismissKeyboard(view: self.view)
        ;
        if let signUpRequest = validateSignUpRequest() {
            if !NetworkState.isConnected() {
                helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_no_network_connection)
                return
            } else {
                LogConfig.logD(message:"SignUp: Email - \(signUpRequest.loginId)", displayToThirdParty: true)
                
                helperGetAppDeleate().showActivityView()
                APIClient.delegate = self
                
                var isGuestUser = false
                if UserSession.shared.isUserTypeGuest(){
                    isGuestUser = true
                }
                if isGuestUser{
                    APIClient.updateCredentialsByUUID(request:signUpRequest)
                }else{
                    APIClient.signUp(request: signUpRequest)
                }
                
            }
        }
        
    }

}

extension SignUpController : UITextViewDelegate{
   func textView(_ textView: UITextView, shouldInteractWith url: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool{
       let loginScreen = LoginScreen()
       helperGetAppDeleate().navigation.pushViewController(loginScreen, animated: true)
       return false
   }

}

extension SignUpController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTF {
            emailTF.resignFirstResponder()
            passwordTF.becomeFirstResponder()
        } else if textField == passwordTF {
            passwordTF.resignFirstResponder()
            confirmPasswordTF.becomeFirstResponder()
        }else {
            self.view.endEditing(true)
        }
        return false
    }
}


extension SignUpController: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed for requestId - \(requestId), errorInfo - \(errorInfo)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message )
    }
    
    func signUpSuccess(_ results: SignUpResponse) {
        LogConfig.logD(message:"Results \(results)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        let loginScreen = LoginScreen()
        helperGetAppDeleate().navigation.pushViewController(loginScreen, animated: true)
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: str_signup_sucess)
        if loginRequest != nil {
            UserSession.shared.setUserLoginDetail(data: loginRequest)
        }
    }
}
