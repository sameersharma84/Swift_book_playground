//
//  AppDelegate.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 26/11/21.
//


import Alamofire
import AWSCore
import AWSCognito
import Firebase
import IQKeyboardManagerSwift
import CoreData
import GoogleSignIn
import BugfenderSDK
import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    @IBOutlet weak var appWindow: UIWindow!
    @IBOutlet weak var activityView: UIView!
    @IBOutlet var activityIndicatorView: UIActivityIndicatorView?
    @IBOutlet var snackBarView: UIView!
    @IBOutlet weak var goOnlineBtn: UIButton!
    @IBOutlet weak var reminderBtn: UIButton!
    @IBOutlet var reminderContainerView: UIView!
    @IBOutlet weak var oneHrBtn: UIButton!
    @IBOutlet weak var twoHrBtn: UIButton!
    @IBOutlet weak var thirtyMinBtn: UIButton!
    @IBOutlet weak var redSnackBar: UIView!
    
    var dbWrapper: DatabaseWrapper = DatabaseWrapper()
    var activityIndicatorTimer: Timer?
    var isOffline = false
    var isVideo = Bool()
    var uploadScreen = UploadViewController()
    var navigation: UINavigationController = UINavigationController()
    var homeScreen = HomeViewController()
    var selectionScreen = SelectionViewController(nibName: "SelectionScreen", bundle: nil)
    var allUploadScreen = AllUploadsViewController()
    var loginScreen = LoginScreen()
    var labelScreen = AddVideoLabelViewController()
    let notificationCenter = UNUserNotificationCenter.current()
    var targetScreen = PrintTargetScreen()
    var orientationLock = UIInterfaceOrientationMask.all
    var isMeasurement : Bool = true
    
//entry
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Logger.checkIfFileExists(logStr: "************* PHOTOGAUGE APP LOGS *************")
        LogConfig.logD(message:"************* didFinishLaunchingWithOptions *************", displayToThirdParty: true)
        self.initialization()
        self.screenRouter()
        initBugFender()
        self.checkForLogFileDate()
        setupAWS()
        
        UserSession.shared.resetDownloadingSession()
        
        UIApplication.shared.isIdleTimerDisabled = false
        if #available(iOS 13.0, *) {
            appWindow?.overrideUserInterfaceStyle = .light
        }
        return true
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        UIApplication.shared.applicationIconBadgeNumber = 0
    }
    
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
            return self.orientationLock
    }
    
    func showAlert(titleStr: String, msg: String) {
        let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: str_ok, style: UIAlertAction.Style.default, handler: nil))
        alert.view.tintColor = Color.themeBlueColor
        self.appWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func hideActivityView() {
        self.appWindow?.rootViewController?.view.isUserInteractionEnabled = true
        self.activityView?.removeFromSuperview()
        if (activityIndicatorTimer != nil) {
            activityIndicatorTimer?.invalidate()
        }
    }

    func initBugFender(){
        Bugfender.activateLogger("ApZsAtzY1ItgaSXG6DsdgwLVG3oVY7TQ")
        Bugfender.enableUIEventLogging()
        Bugfender.enableCrashReporting()
    }
    
    func refreshAppToken() {
        if !NetworkState.isConnected() {
            return
        } else {
            APIClient.getNewToken()
        }
    }
    
    func setupAWS(){
        let credentialsProvider = AWSStaticCredentialsProvider(accessKey: "AKIAYUCY5WUQ7UPJ64OL", secretKey: "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")
        let configuration = AWSServiceConfiguration.init(region: AWSRegionType.USEast1, credentialsProvider: credentialsProvider)
        AWSServiceManager.default().defaultServiceConfiguration = configuration
        
//        let credentialsProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, identityPoolId: "us-east-1:48c18197-88de-4c47-beca-3f7b49c26e2a")
//        let configuration = AWSServiceConfiguration(region: .USEast1, credentialsProvider: credentialsProvider)
//        AWSServiceManager.default()?.defaultServiceConfiguration = configuration
    }
    
    func showSettingsAlert(titleStr: String, msg: String) {
        let alert = UIAlertController(title: "", message: msg, preferredStyle: UIAlertController.Style.alert)
        let settingsAction = UIAlertAction(title: "Open Settings", style: .default) { _ in
            LogConfig.logD(message:"Settings pressed", displayToThirdParty: true)
            let url = URL(string:UIApplication.openSettingsURLString)
            if UIApplication.shared.canOpenURL(url!){
                UIApplication.shared.open(url!, options: [:], completionHandler: nil)
            }
        }
        alert.addAction(settingsAction)
        self.appWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func initialization() -> Void {
        notificationCenter.delegate = self
        let options: UNAuthorizationOptions = [.alert, .sound, .badge]
        notificationCenter.requestAuthorization(options: options) {
            (didAllow, error) in
            if !didAllow {
                LogConfig.logD(message:"User has declined notifications", displayToThirdParty: true)
            }else{
                LogConfig.logD(message:"User has allowed notifications", displayToThirdParty: true)
            }
        }
        isVideo = true
        let env = UserDefaults.standard.integer(forKey: kEnvironment)
        if env == 0 {
            helperSetEnvironment(env: ENVIRONMENT.ENVIRONMENT_PRODUCTION)
        }
        IQKeyboardManager.shared.enable = true
        
        //configure Firebase
        FirebaseApp.configure()
        
        //Start monitioring network
        NetStatus.shared.startMonitoring()
        UploadHelper.sharedInstance.uploadScreen = uploadScreen
        UploadHelper.sharedInstance.allScanScreen = allUploadScreen
//        UploadHelper.sharedInstance.partsScreen = partScreen
//        UploadHelper.sharedInstance.addNewPartScreen = addNewPartScreen
        
        dbWrapper.updateUnitStatusToInQueueIfStatusIs(forStatus: str_uploading)
        UserSession.shared.setAllPartsRequestRunning(status: false)
        UserDefaults.standard.setValue("", forKey: kVideoUploadingEnd)
        UserDefaults.standard.setValue("", forKey: kVideoUploadingStart)

        self.dbWrapper.checkAndUpdateDatabase()
    }
    
    func screenRouter() -> Void {
        navigation.navigationBar.isHidden = true
        let sessionData = UserSession.shared
        if (sessionData.getUserData() != nil){
            helperGetAppDeleate().dbWrapper.createPartsTable()
//            if sessionData.isFirstTime() ?? true{
//                if sessionData.getUserSelection() == nil{
//                    makeRootController(controller: selectionScreen)
//                }else{
//                    makeRootController(controller: homeScreen)
//                }
//            }else{
//                makeRootController(controller: allUploadScreen)
//            }
            
            if sessionData.getUserSelection() == nil{
                makeRootController(controller: selectionScreen)
            }else{
                makeRootController(controller: allUploadScreen)
            }
                
        }else{
            makeRootController(controller: loginScreen)
        }
    }
    
    func makeRootController(controller: UIViewController){
        navigation.setViewControllers([controller], animated: false)
        navigation.interactivePopGestureRecognizer?.isEnabled = false
        self.appWindow?.frame = UIScreen.main.bounds
        self.appWindow?.rootViewController = navigation
        self.appWindow?.makeKeyAndVisible()
    }
    
    func checkForLogFileDate() {
        if UserDefaults.standard.value(forKey: "logFileTime") as? Date == nil {
            UserDefaults.standard.setValue(Date(), forKey: "logFileTime")
            return
        }
        let logFileDate: Date = UserDefaults.standard.value(forKey: "logFileTime") as! Date
        let today = Date() //Jun 21, 2017, 7:18 PM
        let tempDate = Calendar.current.date(byAdding: .day, value: -2, to: today)!
        let twoNHalfDaysBeforeToday = Calendar.current.date(byAdding: .hour, value: -12, to: tempDate)!
        if (logFileDate < twoNHalfDaysBeforeToday) {
            let fileManager = FileManager.default
            let documentDirectoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = documentDirectoryURL.appendingPathComponent("logFile.txt")
            if fileManager.fileExists(atPath: fileURL.path) {
                do {
                    LogConfig.logD(message:"Removing Log File after 2.5 days", displayToThirdParty: true)
                    try fileManager.removeItem(at: fileURL)
                    Logger.checkIfFileExists(logStr: "************* PHOTOGAUGE APP LOGS *************")
                } catch {
                    LogConfig.logE(message:"Error while moving and deleting Log File", displayToThirdParty: true)
                }
            }
        }
    }
    
    func showActivityView() {
        if let controller = self.appWindow?.rootViewController {
            if ((controller as? UINavigationController) != nil) {
                let navigationController: UINavigationController = controller as! UINavigationController;
                if (navigationController.visibleViewController as? CameraScreen == nil) {
                    self.activityView!.center = CGPoint(x: self.appWindow!.frame.size.width  / 2,
                                                        y: self.appWindow!.frame.size.height / 2);
                    self.appWindow?.rootViewController?.view.isUserInteractionEnabled = false
                    self.appWindow?.addSubview(self.activityView!)
                    
                    if activityIndicatorTimer == nil || !activityIndicatorTimer!.isValid {
                        startActivityIndicatorTimer()
                    }
                } else {
                    self.hideActivityView()
                }
            }
        }
    }
    
    func startActivityIndicatorTimer() {
        Timer.scheduledTimer(withTimeInterval: TimeInterval(60), repeats: false, block: { timer in
            timer.invalidate()
            self.hideActivityView()
        })
    }
    
    func application(
        _ app: UIApplication,
        open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]
    ) -> Bool {
        var handled: Bool
        handled = GIDSignIn.sharedInstance.handle(url)
        if handled {
            return true
        }
    return false
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        debugPrint("App Goint to be terminate====")
        AWSS3Manager.shared.cancelUploads(callback: {
            UploadHelper.sharedInstance.timer.invalidate()
        })
    }
    
}

extension AppDelegate: UNUserNotificationCenterDelegate {
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        completionHandler([.alert, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        
        if response.notification.request.identifier == "Local Notification" {
            LogConfig.logD(message:"Handling notifications with the Local Notification Identifier", displayToThirdParty: true)
        }
        
        completionHandler()
    }
    
    func scheduleNotification(msg: String) {
        
        let content = UNMutableNotificationContent() // Содержимое уведомления
        let categoryIdentifire = "Delete Notification Type"
        
        content.title = "PhotoGAUGE"
        content.body = msg
        content.sound = UNNotificationSound.default
        content.badge = 1
        content.categoryIdentifier = categoryIdentifire
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let identifier = "Local Notification"
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        
        notificationCenter.add(request) { (error) in
            if let error = error {
                LogConfig.logE(message:"Error in schedule notification\(error.localizedDescription)", displayToThirdParty: true)
            }
        }
        
        let snoozeAction = UNNotificationAction(identifier: "Snooze", title: "Snooze", options: [])
        let deleteAction = UNNotificationAction(identifier: "DeleteAction", title: "Delete", options: [.destructive])
        let category = UNNotificationCategory(identifier: categoryIdentifire,
                                              actions: [snoozeAction, deleteAction],
                                              intentIdentifiers: [],
                                              options: [])
        
        notificationCenter.setNotificationCategories([category])
    }
    

    
    func customizeGMSViewController() {
        /*let barColor: UIColor =  _ColorLiteralType(red: 0.5843137503, green: 0.8235294223, blue: 0.4196078479, alpha: 1)
        
          UINavigationBar.appearance().barTintColor = barColor
          UINavigationBar.appearance().tintColor = UIColor.white*/
        
        let textColor: UIColor =  _ColorLiteralType(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        let searchBarTextAttributes = [NSAttributedString.Key.foregroundColor: textColor, NSAttributedString.Key.font: UIFont(name: "SFProText-Regular", size: 15)]
        UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).defaultTextAttributes = searchBarTextAttributes as [NSAttributedString.Key : Any]
        
        let backgroundColor: UIColor =  _ColorLiteralType(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        let placeholderAttributes = [NSAttributedString.Key.foregroundColor: backgroundColor, NSAttributedString.Key.font: UIFont(name: "SFProText-Regular", size: 15)]
        let attributedPlaceholder = NSAttributedString(string: "Search", attributes: placeholderAttributes as [NSAttributedString.Key : Any])
        UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).attributedPlaceholder = attributedPlaceholder
    }
    
    
}
