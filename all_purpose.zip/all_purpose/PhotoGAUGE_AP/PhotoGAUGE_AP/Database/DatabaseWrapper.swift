//
//  DatabaseWrapper.swift
//  PhotoGauge
//
//  Created by apple on 04/08/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import SQLite

extension Connection {
    public func exists(column: String, in table: String) throws -> Bool {
        let stmt = try prepare("PRAGMA table_info(\(table))")
        
        let columnNames = stmt.makeIterator().map { (row) -> String in
            return row[1] as? String ?? ""
        }
        
        return columnNames.contains(where: { dbColumn -> Bool in
            return dbColumn.caseInsensitiveCompare(column) == ComparisonResult.orderedSame
        })
    }
}


class DatabaseWrapper {
    
    // MARK: Member variables
    var pgDatabase: Connection!
    
    let allPartsTable = Table(kAllPartsTable)
    let scansTable = Table(kScansTable)
    
    let id = Expression<Int>(kId)
    let locationLat = Expression<Int>(kLocationLat)
    let locationLng = Expression<Int>(kLocationLng)
    let localPartTimeCreation = Expression<String?>(kLocalPartTimeCreation)
    let partCreatedOn = Expression<String>(kPartCreatedOn)
    let partId = Expression<String>(kPartId)
    let partName = Expression<String>(kPartName)
    let partDesc = Expression<String?>(kPartDesc)
    let photosCount = Expression<Int>(kPhotosCount)
    let profilePic = Expression<String?> (kProfilePic)
    let scanCount = Expression<Int>(kScanCount)
    let unitCount = Expression<Int>(kUnitCount)
    let latestShootTime = Expression<String>(kLatestShootTime)
    let address = Expression<String?>(kAddress)
    let zipCode = Expression<String?>(kZipCode)
    let partCustomer = Expression<String?>(kPartCustomer)
    
    let parentScanId = Expression<String>(kParentScanId)
    let action = Expression<String>(kAction)
    let deviceType = Expression<String>(kDeviceType)
    let localShootTime = Expression<String>(kLocalShootTime)
    let localShootTimeStr = Expression<String>(kLocalShootTimeStr)
    let unitCreatedOn = Expression<String>(kUnitCreatedOn)
    let unitDisplayName = Expression<String>(kUnitDisplayName)
    let unitId = Expression<String>(kUnitId)
    let unitName = Expression<String>(kUnitName)
    let unitStatus = Expression<String>(kUnitStatus)
    let isUploaded = Expression<Bool>(kUploaded)
    let isUploadingInProgress = Expression<Bool>(kUploading)
    let uploadStatus = Expression<String>(kUploadStatus)
    let uploadRunningStatus = Expression<String>(kUploadRunningStatus)
    let scanIsVideo = Expression<Bool>(kVideo)
    let videoShootTime = Expression<Int>(kShootTime)
    let jobIDsCount = Expression<Int>(kJobIds)
    let jobID = Expression<String?>(kJobId)
    let jobName = Expression<String?>(kJobName)
    let jobStatus = Expression<String?>(kJobStatus)
    let mergePartDone = Expression<Bool>(kMergePartDone)
    let objectType = Expression<String>(kObjectType)
    let objectTypeName = Expression<String>(kObjectTypeName)
    let roomType = Expression<String>(kRoomType)
    let videoURLStr = Expression<String>(kVideoURLStr)
    let unitNotes = Expression<String>(kUnitNotes)
    let unitSold = Expression<Int>(kUnitSold)
    let isUnitSelected = Expression<Bool>(kIsUnitSelected)
    let appSelectionType = Expression<String?>(kAppSelectionType)
    let tinUrl = Expression<String?>(kTinyUrl)
    let requestId = Expression<String?>(kRequestId)
    
    // MARK: Constructor
    
    init() {
        do {
            let documentDir = try FileManager.default.url(for: .documentDirectory,
                                                          in: .userDomainMask,
                                                          appropriateFor: nil,
                                                          create: true)
            let fileUrl = documentDir.appendingPathComponent(str_parts).appendingPathExtension("sqlite3")
            let database = try Connection(fileUrl.path)
            pgDatabase = database
//            print(database)
        } catch {
            LogConfig.logE(message:"Error while creating Database: \(error)", displayToThirdParty: true)
        }
    }
    
    // Update database
    func checkAndUpdateDatabase() {
        let lastAppUpdateVersion = helperCheckAppUpdateVersion()
        LogConfig.logD(message:"Check and update database \(lastAppUpdateVersion)  ==== \(helperGetAppVersion())", displayToThirdParty: true)
        debugPrint("Check and update database \(lastAppUpdateVersion)  ==== \(helperGetAppVersion())=====")
        if lastAppUpdateVersion == "" || lastAppUpdateVersion != helperGetAppVersion() {
            do {
                let tableExists = try self.pgDatabase.scalar(scansTable.exists)
                if tableExists {
                    debugPrint("Check and update database Table Exists=======")
                    let isExists = try self.pgDatabase.exists(column: kRequestId, in: kScansTable)
                    if !isExists {
                        debugPrint("Check and update database Column not Exists==========")
                        try self.pgDatabase.run(scansTable.addColumn(requestId, defaultValue: ""))
                    }
                }
            } catch{
                LogConfig.logE(message:"Error Check and update database \(error)", displayToThirdParty: true)
                print(error.localizedDescription)
            }
            helperSetAppUpdateVersion()
        }
    }
    
    
    // MARK: Database function
    func createPartsTable() {
        let createTable = self.allPartsTable.create(temporary: false, ifNotExists: true, withoutRowid: false) { (table) in
            table.column(self.id, primaryKey: true)
            table.column(self.locationLat)
            table.column(self.locationLng)
            table.column(self.localPartTimeCreation)
            table.column(self.partCreatedOn)
            table.column(self.partId, unique: true)
            table.column(self.partName)
            table.column(self.partDesc)
            table.column(self.photosCount)
            table.column(self.profilePic)
            table.column(self.scanCount)
            table.column(self.unitCount)
            table.column(self.latestShootTime)
            table.column(self.address)
            table.column(self.zipCode)
            table.column(self.partCustomer)
        }
        
        do {
            try pgDatabase.run(createTable)
            LogConfig.logD(message:"All parts Table created", displayToThirdParty: true)
            createScansTable()
        }catch{
            LogConfig.logE(message:"Error while creating all parts table: \(error)", displayToThirdParty: true)
        }
    }
    
    func createScansTable() {
        let createTable = self.scansTable.create(temporary: false, ifNotExists: true, withoutRowid: false) { (table) in
            table.column(self.id, primaryKey: true)
            table.column(self.partId)
            table.column(self.action)
            table.column(self.deviceType)
            table.column(self.localShootTime)
            table.column(self.localShootTimeStr)
            table.column(self.parentScanId)
            table.column(self.photosCount)
            table.column(self.locationLat)
            table.column(self.locationLng)
            table.column(self.unitCreatedOn)
            table.column(self.unitDisplayName)
            table.column(self.unitId)
            table.column(self.unitName)
            table.column(self.unitStatus)
            table.column(self.isUploaded)
            table.column(self.isUploadingInProgress)
            table.column(self.uploadStatus)
            table.column(self.uploadRunningStatus)
            table.column(self.scanIsVideo)
            table.column(self.videoShootTime)
            table.column(self.jobIDsCount)
            table.column(self.mergePartDone)
            table.column(self.objectType)
            table.column(self.objectTypeName)
            table.column(self.roomType)
            table.column(self.videoURLStr)
            table.column(self.unitNotes)
            table.column(self.unitSold)
            table.column(self.isUnitSelected)
            table.column(self.appSelectionType)
            table.column(self.jobID)
            table.column(self.jobName)
            table.column(self.jobStatus)
            table.column(self.tinUrl)
            table.column(self.requestId,defaultValue: "")
        }
        
        do {
            try pgDatabase.run(createTable)
            LogConfig.logD(message:"Scans Table created", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error while creating Scans table: \(error)", displayToThirdParty: true)
        }
    }
    
    func insertParts(partsData: [[String: Any]], callback: (([Dictionary<String, Any>]) -> ())){
        var duplicate = false
        for partDetails in partsData {
            do {
                let parts = try pgDatabase.prepare(self.allPartsTable)
                for part in parts{
                    if (part[self.partId] == partDetails[kPartId] as! String) {
                        duplicate = true
                        let filteredPart = allPartsTable.filter(self.partId == partDetails[kPartId] as! String)
                        let updatepart = filteredPart.update(self.localPartTimeCreation <- partDetails[kLocalPartTimeCreation] as? String,
                                                                   self.partName <- partDetails[kPartName] as! String,
                                                                   self.partDesc <- partDetails[kPartDesc] as? String,
                                                                   self.photosCount <- partDetails[kPhotosCount] as! Int,
                                                                   self.profilePic <- partDetails[kProfilePic] as? String,
                                                                   self.scanCount <- partDetails[kScanCount] as! Int,
                                                                   self.unitCount <- partDetails[kUnitCount] as! Int,
                                                                   self.latestShootTime <- latestShootTime)
                        do {
                            try pgDatabase.run(updatepart)
                        }catch{
                            LogConfig.logE(message:"Error in part updation - Insertparts \(error)", displayToThirdParty: true)
                        }
                        break
                    }else{
                        duplicate = false
                    }
                }
            }catch{
                LogConfig.logE(message:"Error in listing Parts", displayToThirdParty: true)
            }
            
            //before inserting data to DB, sort the jobs to get Latest shoot time for all the parts
            var latestShootTime = String()
            var biggestTime = String()
            let unitsData = partDetails[kUnitsData] as! [[String: Any]]
            if unitsData.count > 0 {
                for units in unitsData {
                    var subUnit = units[kSubUnits] as! [[String: Any]]
                    subUnit.sort { (first: [String : Any], second: [String : Any]) -> Bool in
                        var firstTime = String()
                        var secondTime = String()
                        if first[kLocalShootTime] != nil {
                            firstTime = first[kLocalShootTime] as! String
                        }else if first[kUnitCreatedOn] != nil{
                            firstTime = first[kUnitCreatedOn] as! String
                        }
                        
                        if second[kLocalShootTime] != nil {
                            secondTime = second[kLocalShootTime] as! String
                        }else if first[kUnitCreatedOn] != nil{
                            secondTime = second[kUnitCreatedOn] as! String
                        }
                        
                        return helperGetServerTimeInMillis(serverTime: firstTime) > helperGetServerTimeInMillis(serverTime: secondTime)
                    }
                    if subUnit[0][kLocalShootTime] != nil {
                        if helperGetServerTimeInMillis(serverTime: biggestTime) < helperGetServerTimeInMillis(serverTime: subUnit[0][kLocalShootTime] as! String) {
                            biggestTime = subUnit[0][kLocalShootTime] as! String
                        }
                    }else if subUnit[0][kUnitCreatedOn] != nil{
                        if helperGetServerTimeInMillis(serverTime: biggestTime) < helperGetServerTimeInMillis(serverTime: subUnit[0][kUnitCreatedOn]  as! String) {
                            biggestTime = subUnit[0][kUnitCreatedOn] as! String
                        }
                    }
                }
                latestShootTime = biggestTime
            }else{
                if partDetails[kLocalPartTimeCreation] != nil{
                    latestShootTime = partDetails[kLocalPartTimeCreation] as! String
                }else if partDetails[kPartCreatedOn] != nil{
                    latestShootTime = partDetails[kPartCreatedOn] as! String
                }
            }
            
            if !duplicate {
                let insertPart = self.allPartsTable.insert(self.locationLat <- partDetails[kLocationLat] as! Int,
                                                           self.locationLng <- partDetails[kLocationLng] as! Int,
                                                           self.partCreatedOn <- partDetails[kPartCreatedOn] as! String,
                                                           self.localPartTimeCreation <- partDetails[kLocalPartTimeCreation] as? String,
                                                           self.partId <- partDetails[kPartId] as! String,
                                                           self.partName <- partDetails[kPartName] as! String,
                                                           self.partDesc <- partDetails[kPartDesc] as? String,
                                                           self.photosCount <- partDetails[kPhotosCount] as! Int,
                                                           self.profilePic <- partDetails[kProfilePic] as? String,
                                                           self.scanCount <- partDetails[kScanCount] as! Int,
                                                           self.unitCount <- partDetails[kUnitCount] as! Int,
                                                           self.latestShootTime <- latestShootTime,
                                                           self.address <- partDetails[kAddress] as? String,
                                                           self.zipCode <- partDetails[kZipCode] as? String,
                                                           self.partCustomer <- partDetails[kPartCustomer] as? String)
                
                do {
                    try pgDatabase.run(insertPart)
                }catch{
                    LogConfig.logE(message:"Error in part insertion - Insertparts \(error)", displayToThirdParty: true)
                }
            }
            
            for units in unitsData {
                var insertScan : Insert
                let subUnit = units[kSubUnits] as! [[String: Any]]
                for job in subUnit{
                    let isVideo = job[kVideo] as? Bool ?? false
                    let jobRoomDict = job[kRoomType] as? [String: Any] ?? [:]
                    let jobWindowDict = job[kObjectType] as? [String: Any] ?? [:]
                    let jobIdArray = job[kJobIds] as? [String?] ?? []
                    var firstJobId = ""
                    if jobIdArray.count > 0{
                        firstJobId = jobIdArray[0]!
                    }
                    let jobNamesArray = job[kJobName] as? [String?] ?? []
                    var firstJobName = ""
                    if jobNamesArray.count > 0{
                        firstJobName = jobNamesArray[0]!
                    }
                    let jobStatusArray = job[kJobStatus] as? [String?] ?? []
                    var firstJobStatus = ""
                    if jobStatusArray.count > 0{
                        firstJobStatus = jobStatusArray[0]!
                    }
                    let tinyUrl = job[kTinyUrl] as? String ?? ""
                    
                    if isVideo {
                        insertScan = self.scansTable.insert(self.locationLat <- job[kLocationLat] as? Int ?? 0,
                                                                self.locationLng <- job[kLocationLng] as? Int ?? 0,
                                                                self.action <- job[kAction] as? String ?? "",
                                                                self.deviceType <- job[kDeviceType] as? String ?? "",
                                                                self.partId <- partDetails[kPartId] as! String,
                                                                self.localShootTime <- job[kLocalShootTime] as? String ?? "",
                                                                self.localShootTimeStr <- job[kLocalShootTimeStr] as? String ?? "",
                                                                self.parentScanId <- job[kParentScanId] as! String,
                                                                self.photosCount <- job[kPhotosCount] as! Int,
                                                                self.unitCreatedOn <- job[kUnitCreatedOn] as! String,
                                                                self.unitDisplayName <- job[kUnitDisplayName] as! String,
                                                                self.unitId <- job[kUnitId] as! String,
                                                                self.unitName <- job[kUnitName] as! String,
                                                                self.unitStatus <- job[kUnitStatus] as? String ?? "",
                                                                self.isUploaded <- true,
                                                                self.isUploadingInProgress <- false,
                                                                self.uploadStatus <- UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue,
                                                                self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                                self.scanIsVideo <- job[kVideo] as! Bool,
                                                                self.videoShootTime <- job[kShootTime] as? Int ?? 0,
                                                                self.jobIDsCount <- (job[kJobIds] as? [String])?.count ?? 0,
                                                                self.mergePartDone <- true,
                                                                self.objectType <- jobWindowDict[kType] as? String ?? "window",
                                                                self.objectTypeName <- jobWindowDict[kName] as? String ?? "",
                                                                self.roomType <- jobRoomDict[kName] as? String ?? "",
                                                                self.videoURLStr <- job[kVideoURLStr] as? String ?? "",
                                                                self.unitNotes <- job[kUnitNotes] as? String ?? "",
                                                                self.unitSold <- job[kUnitSold] as? Int ?? 0,
                                                                self.isUnitSelected <- job[kIsUnitSelected] as? Bool ?? false,
                                                                self.appSelectionType <- job[kAppSelectionType] as? String ?? "",
                                                                self.jobID <- firstJobId,
                                                                self.jobName <- firstJobName,
                                                                self.jobStatus <- firstJobStatus,
                                                                self.tinUrl <- tinyUrl
                                                                )
                    }else{
                        insertScan = self.scansTable.insert(self.locationLat <- job[kLocationLat] as? Int ?? 0,
                                                                self.locationLng <- job[kLocationLng] as? Int ?? 0,
                                                                self.action <- job[kAction] as? String ?? "",
                                                                self.deviceType <- job[kDeviceType] as? String ?? "",
                                                                self.partId <- partDetails[kPartId] as! String,
                                                                self.localShootTime <- job[kLocalShootTime] as? String ?? "",
                                                                self.localShootTimeStr <- job[kLocalShootTimeStr] as? String ?? "",
                                                                self.parentScanId <- job[kParentScanId] as! String,
                                                                self.photosCount <- job[kPhotosCount] as! Int,
                                                                self.unitCreatedOn <- job[kUnitCreatedOn] as! String,
                                                                self.unitDisplayName <- job[kUnitDisplayName] as! String,
                                                                self.unitId <- job[kUnitId] as! String,
                                                                self.unitName <- job[kUnitName] as! String,
                                                                self.unitStatus <- job[kUnitStatus] as! String,
                                                                self.isUploaded <- true,
                                                                self.isUploadingInProgress <- false,
                                                                self.uploadStatus <- UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue,
                                                                self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                                self.scanIsVideo <- false,
                                                                self.videoShootTime <- 0,
                                                                self.jobIDsCount <- (job[kJobIds] as? [String])?.count ?? 0,
                                                                self.mergePartDone <- true,
                                                                self.objectType <- jobWindowDict[kType] as? String ?? "window",
                                                                self.objectTypeName <- jobWindowDict[kName] as? String ?? "",
                                                                self.roomType <- jobRoomDict[kName] as? String ?? "",
                                                                self.videoURLStr <- job[kVideoURLStr] as? String ?? "",
                                                                self.unitNotes <- job[kUnitNotes] as? String ?? "",
                                                                self.unitSold <- job[kUnitSold] as? Int ?? 0,
                                                                self.isUnitSelected <- job[kIsUnitSelected] as? Bool ?? false,
                                                                self.appSelectionType <- job[kAppSelectionType] as? String ?? "",
                                                                self.jobID <- firstJobId,
                                                                self.jobName <- firstJobName,
                                                                self.jobStatus <- firstJobStatus,
                                                                self.tinUrl <- tinyUrl
                                                                )
                    }
                    
                    do {
                        try pgDatabase.run(insertScan)
                    }catch{
                        LogConfig.logE(message:"Error in scan insertion \(error)", displayToThirdParty: true)
                    }
                }
            }
        }
        
        var scansToUpdate = [Dictionary<String, Any>]()
        var scanDetails = [String : Any]()
        do {
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans {
                if (scan[self.jobIDsCount] == 0) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? ""
                                ]
                    
                    scansToUpdate.append(scanDetails)
                }
            }
        } catch {
            LogConfig.logE(message:"Error in part updation", displayToThirdParty: true)
        }
        
        callback(scansToUpdate)
    }
    
    func insertSinglePart(partDetails: [String : Any], callback: (() -> ())) {
        var duplicate = false
        
        do {
            let parts = try pgDatabase.prepare(self.allPartsTable)
            for part in parts{
                if (part[self.partId] == partDetails[kPartId] as! String) {
                    duplicate = true
                    break
                }else{
                    duplicate = false
                }
            }
        }catch{
            LogConfig.logE(message:"Error in listing Parts", displayToThirdParty: true)
        }
        
        if !duplicate {
            let insertPart = self.allPartsTable.insert(self.locationLat <- 0,
                                                       self.locationLng <- 0,
                                                       self.partCreatedOn <- "",
                                                       self.localPartTimeCreation <- partDetails[kLocalPartTimeCreation] as? String,
                                                       self.partId <- partDetails[kPartId] as! String,
                                                       self.partName <- partDetails[kPartName] as! String,
                                                       self.partDesc <- partDetails[kPartDesc] as? String,
                                                       self.photosCount <- 0,
                                                       self.profilePic <- "",
                                                       self.scanCount <- 0,
                                                       self.unitCount <- 0,
                                                       self.latestShootTime <- partDetails[kLatestShootTime] as! String,
                                                       self.address <- (partDetails[kAddress] as! String),
                                                       self.zipCode <- (partDetails[kZipCode] as! String),
                                                       self.partCustomer <- (partDetails[kPartCustomer] as! String))
                                                       
            
            do {
                try pgDatabase.run(insertPart)
            }catch{
                LogConfig.logE(message:"Error in part insertion \(error)", displayToThirdParty: true)
            }
        }
        callback()
    }
    
    func updateLatestShootTimeForPart(latestShootTime: String, partID: String) {
        do{
            let filteredPart = allPartsTable.filter(self.partId == partID)
            
            try pgDatabase.run(filteredPart.update(self.latestShootTime <- latestShootTime))
//            LogConfig.logE(message:"Latest shoot time in Parts UPDATED")
            
        }catch{
            LogConfig.logE(message:"Error in Latest shoot time updation", displayToThirdParty: true)
        }

    }
    
    func updatePartIdForPart(partName: String, partId: String) {
        do{
            let filteredPart = allPartsTable.filter(self.partName == partName)
            try pgDatabase.run(filteredPart.update(self.partId <- partId))
        }catch{
            LogConfig.logE(message:"Error in Latest shoot time updation", displayToThirdParty: true)
        }

    }
    
    func updatePartNameFor(partId: String, partName: String) {
        do{
            let filteredPart = allPartsTable.filter(self.partId == partId)
            try pgDatabase.run(filteredPart.update(self.partName <- partName))
        }catch{
            LogConfig.logE(message:"Error in partname updation", displayToThirdParty: true)
        }
    }
    
    func updatePartInfoFor(partId: String, partName: String, newPartId: String,localPartTimeCreation:String) {
        do{
            let filteredPart = allPartsTable.filter(self.partId == partId)
            try pgDatabase.run(filteredPart.update(self.partName <- partName,
                                                   self.partId <- newPartId,
                                                   self.localPartTimeCreation <- localPartTimeCreation,
                                                   self.latestShootTime <- localPartTimeCreation))
        }catch{
            LogConfig.logE(message:"Error in partInfo updation \(error)", displayToThirdParty: true)
        }
    }
    
    func updatePartIdForScan(dummyPartId: String, partId: String) {
        do{
            print("PartId is a dummy partId")
            let filteredScan = scansTable.filter(self.partId == dummyPartId)
            try pgDatabase.run(filteredScan.update(self.partId <- partId))
        }catch{
            LogConfig.logE(message:"Error in Latest shoot time updation", displayToThirdParty: true)
        }

    }
    
    func getScanInfoForParts() -> [Dictionary<String, Any>] {
        let joinTable = scansTable.join(allPartsTable, on: allPartsTable[partId] == scansTable[partId])
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(joinTable.filter(self.isUploaded == true))
            for scan in scans{
                scanDetails = [kPartId : scan[allPartsTable[partId]],
                               kPartName : scan[allPartsTable[partName]],
                               kPartDesc : scan[allPartsTable[partDesc]] ?? "",
                               kProfilePic : scan[allPartsTable[profilePic]] ?? "",
                               kLatestShootTime : scan[allPartsTable[latestShootTime]],
                               kUnitCreatedOn : scan[scansTable[unitCreatedOn]],
                               kUnitDisplayName : scan[scansTable[unitDisplayName]],
                               kUnitId : scan[scansTable[unitId]],
                               kUnitName : scan[scansTable[unitName]],
                               kUnitStatus : scan[scansTable[unitStatus]],
                               kUploaded : scan[scansTable[isUploaded]],
                               kUploading : scan[scansTable[isUploadingInProgress]],
                               kUploadStatus : scan[scansTable[uploadStatus]],
                               kUploadRunningStatus : scan[scansTable[uploadRunningStatus]],
                               kVideo : scan[scansTable[scanIsVideo]],
                               kVideoURLStr: scan[scansTable[videoURLStr]],
                               kAppSelectionType: scan[scansTable[appSelectionType]]!,
                               kJobId: scan[scansTable[jobID]]!,
                               kJobName: scan[scansTable[jobName]]!,
                               kJobStatus: scan[scansTable[jobStatus]]!,
                               kTinyUrl: scan[scansTable[tinUrl]] ?? ""
                            ]

                scansList.append(scanDetails)
            }
            return scansList
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return [[:]]
        }
    }
    
    func updatePart(partsData: [[String: Any]],dBWrapper:DatabaseWrapper,isInsertPart:Bool = false, callback: (([Dictionary<String, Any>]) -> ())) {
            for partDetails in partsData {
                
                //before inserting data to DB, sort the jobs to get Latest shoot time for all the parts
                var latestShootTime = String()
                var biggestTime = String()
                let unitsData = partDetails[kUnitsData] as! [[String: Any]]
                if unitsData.count > 0 {
                    for units in unitsData {
                        var subUnit = units[kSubUnits] as! [[String: Any]]
                        subUnit.sort { (first: [String : Any], second: [String : Any]) -> Bool in
                            return helperGetServerTimeInMillis(serverTime: first[kLocalShootTime] as! String) > helperGetServerTimeInMillis(serverTime: second[kLocalShootTime] as! String)
                        }
                        
                        if helperGetServerTimeInMillis(serverTime: biggestTime) < helperGetServerTimeInMillis(serverTime: subUnit[0][kLocalShootTime] as! String) {
                            biggestTime = subUnit[0][kLocalShootTime] as! String
                        }
                    }
                    latestShootTime = biggestTime
                }else{
                    latestShootTime = partDetails[kLocalPartTimeCreation] as? String ?? ""
                }
                
                do {
                    var duplicate = false
                    let parts = try pgDatabase.prepare(self.allPartsTable)
                    for part in parts{
                        if (part[self.partId] == partDetails[kPartId] as! String) {
                            duplicate = true
                            break
                        }else{
                            duplicate = false
                        }
                    }
                    
                    if (duplicate) {
                    
                        let filteredPart = allPartsTable.filter(self.partId == partDetails[kPartId] as! String)
                    
                        try pgDatabase.run(filteredPart.update(self.locationLat <- partDetails[kLocationLat] as! Int,
                                                           self.locationLng <- partDetails[kLocationLng] as! Int,
                                                           self.partCreatedOn <- partDetails[kPartCreatedOn] as! String,
                                                           self.localPartTimeCreation <- partDetails[kLocalPartTimeCreation] as? String,
                                                           self.partName <- partDetails[kPartName] as! String,
                                                           self.partDesc <- partDetails[kPartDesc] as? String,
                                                           self.photosCount <- partDetails[kPhotosCount] as! Int,
                                                           self.profilePic <- partDetails[kProfilePic] as? String,
                                                           self.scanCount <- partDetails[kScanCount] as! Int,
                                                           self.unitCount <- partDetails[kUnitCount] as! Int,
                                                           self.latestShootTime <- latestShootTime))
                    } else {
                        let insertPart = self.allPartsTable.insert(self.locationLat <- partDetails[kLocationLat] as! Int,
                                                                   self.locationLng <- partDetails[kLocationLng] as! Int,
                                                                   self.partCreatedOn <- partDetails[kPartCreatedOn] as! String,
                                                                   self.localPartTimeCreation <- partDetails[kLocalPartTimeCreation] as? String,
                                                                   self.partId <- partDetails[kPartId] as! String,
                                                                   self.partName <- partDetails[kPartName] as! String,
                                                                   self.partDesc <- partDetails[kPartDesc] as? String,
                                                                   self.photosCount <- partDetails[kPhotosCount] as! Int,
                                                                   self.profilePic <- partDetails[kProfilePic] as? String,
                                                                   self.scanCount <- partDetails[kScanCount] as! Int,
                                                                   self.unitCount <- partDetails[kUnitCount] as! Int,
                                                                   self.latestShootTime <- latestShootTime,
                                                                   self.address <- partDetails[kAddress] as? String,
                                                                   self.zipCode <- partDetails[kZipCode] as? String,
                                                                   self.partCustomer <- partDetails[kPartCustomer] as? String)
                        
                        do {
                            try pgDatabase.run(insertPart)
                            LogConfig.logD(message:"Parts UPDATED", displayToThirdParty: true)
                        }catch{
                            LogConfig.logE(message:"Error in part insertion \(error)", displayToThirdParty: true)
                        }
                    }
                    
                    LogConfig.logD(message:"Parts UPDATED", displayToThirdParty: true)
                    
                    var scansToUpdate = [Dictionary<String, Any>]()
                    let unitsData = partDetails[kUnitsData] as! [[String: Any]]
                    LogConfig.logD(message:">>>>>>>>>>>>>>>>>>> UNITS DATA COUNT = \(unitsData.count) <<<<<<<<<<<<<<<<<<", displayToThirdParty: true)
                    
                    for units in unitsData {
                        let subUnit = units[kSubUnits] as! [[String: Any]]
                        for job in subUnit{
                            let jobRoomDict = job[kRoomType] as? [String: Any] ?? [:]
                            let jobWindowDict = job[kObjectType] as? [String: Any] ?? [:]
                            let jobIdArray = job[kJobIds] as? [String?] ?? []
                            var firstJobId = ""
                            if jobIdArray.count > 0{
                                firstJobId = jobIdArray[0]!
                                //print(firstJobId)
                            }
                            let jobNamesArray = job[kJobName] as? [String?] ?? []
                            var firstJobName = ""
                            if jobNamesArray.count > 0{
                                firstJobName = jobNamesArray[0]!
                            }
                            let jobStatusArray = job[kJobStatus] as? [String?] ?? []
                            var firstJobStatus = ""
                            if jobStatusArray.count > 0{
                                firstJobStatus = jobStatusArray[0]!
                            }
                            let tinyUrl = job[kTinyUrl] as? String ?? ""
                            
                            //debugPrint("Tiny Url============ ",tinyUrl)
                            
                            do {
                                
                                let countOfExistingServerScan = try pgDatabase.scalar(scansTable.filter(self.unitId == job[kUnitId] as! String).count)
                                let countOfExistingLocalScan = try pgDatabase.scalar(scansTable.filter(self.unitId == job[kUnitName] as! String).count)
                                
                                var isUploaded = true
                                var unitStatus = job[kUnitStatus] as! String
                                let jobCountOnServer = (job[kJobIds] as? [String])?.count ?? 0
                                if jobCountOnServer == 0 && isInsertPart == false{
                                    var existingScan :  [[String : Any]] = []
                                    if countOfExistingServerScan != 0 {
                                        existingScan = self.getScanByUnitId(unitId: job[kUnitId] as! String)
                                    }else if countOfExistingLocalScan != 0 {
                                        existingScan = self.getScanByUnitId(unitId: job[kUnitName] as! String)
                                    }
                                    if existingScan.count > 0 {
                                        unitStatus = existingScan[0][kUnitStatus] as! String
                                    }
                                    isUploaded = false
                                }
                                
                                if countOfExistingServerScan == 1 {
                                    LogConfig.logD(message:"UPDATE SCAN!!!!!", displayToThirdParty: true)
                                    let filteredscan = scansTable.filter(self.unitId == job[kUnitId] as! String)
                                    try pgDatabase.run(filteredscan.update(self.locationLat <- job[kLocationLat] as? Int ?? 0,
                                                                           self.locationLng <- job[kLocationLng] as? Int ?? 0,
                                                                           self.action <- job[kAction] as? String ?? "",
                                                                           self.deviceType <- job[kDeviceType] as? String ?? "",
                                                                           self.partId <- partDetails[kPartId] as! String,
                                                                           self.localShootTime <- job[kLocalShootTime] as? String ?? "",
                                                                           self.localShootTimeStr <- job[kLocalShootTimeStr] as? String ?? "",
                                                                           self.parentScanId <- job[kParentScanId] as! String,
                                                                           self.photosCount <- job[kPhotosCount] as! Int,
                                                                           self.unitCreatedOn <- job[kUnitCreatedOn] as! String,
                                                                           self.unitDisplayName <- job[kUnitDisplayName] as! String,
                                                                           self.unitId <- job[kUnitId] as! String,
                                                                           self.unitName <- job[kUnitName] as! String,
                                                                           self.unitStatus <- unitStatus,
                                                                           self.isUploaded <- isUploaded,
                                                                           self.isUploadingInProgress <- false,
                                                                           self.uploadStatus <- ((job[kJobIds] as? [String])?.count == 0) ? (UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue) : (UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue),
                                                                           self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                                           self.scanIsVideo <- job[kVideo] as? Bool ?? false,
                                                                           self.videoShootTime <- job[kShootTime] as? Int ?? 0,
                                                                           self.jobIDsCount <- (job[kJobIds] as? [String])?.count ?? 0,
                                                                           self.mergePartDone <- true,
                                                                           self.objectType <- jobWindowDict[kType] as? String ?? "window",
                                                                           self.objectTypeName <- jobWindowDict[kName] as? String ?? "",
                                                                           self.roomType <- jobRoomDict[kName] as? String ?? "",
                                                                           self.videoURLStr <- job[kVideoURLStr] as? String ?? "",
                                                                           self.unitNotes <- job[kUnitNotes] as? String ?? "",
                                                                           self.unitSold <- job[kUnitSold] as? Int ?? 0,
                                                                           self.isUnitSelected <- job[kIsUnitSelected] as? Bool ?? false,
                                                                           self.appSelectionType <- job[kAppSelectionType] as? String ?? "",
                                                                           self.jobID <- firstJobId,
                                                                           self.jobName <- firstJobName,
                                                                           self.jobStatus <- firstJobStatus,
                                                                           self.tinUrl <- tinyUrl
                                                                          ))
                                    
                                    if (job[kJobIds] as? [String])?.count == 0 {
                                        var scanDetails = [String : Any]()
                                        scanDetails = [kLocationLat : job[kLocationLat] as? Int ?? 0,
                                                       kLocationLng : job[kLocationLng] as? Int ?? 0,
                                                       kPartId : partDetails[kPartId] as! String,
                                                       kAction : job[kAction] as? String ?? "",
                                                       kDeviceType : job[kDeviceType] as? String ?? "",
                                                       kLocalShootTime : job[kLocalShootTime] as? String ?? "",
                                                       kLocalShootTimeStr : job[kLocalShootTimeStr] as? String ?? "",
                                                       kParentScanId : job[kParentScanId] as! String,
                                                       kPhotosCount : job[kPhotosCount] as! Int,
                                                       kUnitCreatedOn : job[kUnitCreatedOn] as! String,
                                                       kUnitDisplayName : job[kUnitDisplayName] as! String,
                                                       kUnitId : job[kUnitId] as! String,
                                                       kUnitName : job[kUnitName] as! String,
                                                       kUnitStatus : unitStatus,
                                                       kUploaded : isUploaded,
                                                       kUploading : false,
                                                       kUploadStatus : UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue,
                                                       kUploadRunningStatus : UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                       kVideo : job[kVideo] as? Bool ?? false,
                                                       kShootTime : job[kShootTime] as? Int ?? 0,
                                                       kJobIds: 0,
                                                       kUnitNotes: job[kUnitNotes] as? String ?? "",
                                                       kUnitSold: job[kUnitSold] as? Int ?? 0,
                                                       kIsUnitSelected: job[kIsUnitSelected] as? Bool ?? false,
                                                       kAppSelectionType: job[kAppSelectionType] as? String ?? "",
                                                       kJobId: firstJobId,
                                                       kJobName: firstJobName,
                                                       kJobStatus: firstJobStatus,
                                                        kTinyUrl : tinyUrl,
                                                       kMergePartDone: true]
                                        
                                        scansToUpdate.append(scanDetails)
                                    }
                                    
                                    
                                }else if countOfExistingLocalScan != 0 {
                                    //let uploadingJobs = dBWrapper.getUploadingJobs()
                                    LogConfig.logD(message:"UPDATE LOCAL SCAN!!!!!", displayToThirdParty: true)
                                    let filteredscan = scansTable.filter(self.unitId == job[kUnitName] as! String)
                                    try pgDatabase.run(filteredscan.update(self.locationLat <- job[kLocationLat] as? Int ?? 0,
                                                                           self.locationLng <- job[kLocationLng] as? Int ?? 0,
                                                                           self.action <- job[kAction] as? String ?? "",
                                                                           self.deviceType <- job[kDeviceType] as? String ?? "",
                                                                           self.partId <- partDetails[kPartId] as! String,
                                                                           self.localShootTime <- job[kLocalShootTime] as? String ?? "",
                                                                           self.localShootTimeStr <- job[kLocalShootTimeStr] as? String ?? "",
                                                                           self.parentScanId <- job[kParentScanId] as! String,
                                                                           self.photosCount <- job[kPhotosCount] as! Int,
                                                                           self.unitCreatedOn <- job[kUnitCreatedOn] as! String,
                                                                           self.unitDisplayName <- job[kUnitDisplayName] as! String,
                                                                           self.unitId <- job[kUnitId] as! String,
                                                                           self.unitName <- job[kUnitName] as! String,
                                                                           self.unitStatus <- unitStatus,
                                                                           self.isUploaded <- isUploaded,
                                                                           self.isUploadingInProgress <- false,
                                                                           self.uploadStatus <- ((job[kJobIds] as? [String])?.count == 0) ? (UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue) : (UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue),
                                                                           self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                                           self.scanIsVideo <- job[kVideo] as? Bool ?? false,
                                                                           self.videoShootTime <- job[kShootTime] as? Int ?? 0,
                                                                           self.jobIDsCount <- (job[kJobIds] as? [String])?.count ?? 0,
                                                                           self.mergePartDone <- true,
                                                                           self.objectType <- job[kObjectType] as? String ?? "window",
                                                                           self.objectTypeName <- job[kObjectTypeName] as? String ?? "",
                                                                           self.roomType <- jobRoomDict[kName] as? String ?? "",
                                                                           self.videoURLStr <- job[kVideoURLStr] as? String ?? "",
                                                                           self.unitNotes <- job[kUnitNotes] as? String ?? "",
                                                                           self.unitSold <- job[kUnitSold] as? Int ?? 0,
                                                                           self.isUnitSelected <- job[kIsUnitSelected] as? Bool ?? false,
                                                                           self.appSelectionType <- job[kAppSelectionType] as? String ?? "",
                                                                           self.jobID <- firstJobId,
                                                                           self.jobName <- firstJobName,
                                                                           self.tinUrl <- tinyUrl
                                                                          ))
                                    
                                    if (job[kJobIds] as? [String])?.count == 0 {
                                        var scanDetails = [String : Any]()
                                        scanDetails = [kLocationLat : job[kLocationLat] as? Int ?? 0,
                                                       kLocationLng : job[kLocationLng] as? Int ?? 0,
                                                       kPartId : partDetails[kPartId] as! String,
                                                       kAction : job[kAction] as? String ?? "",
                                                       kDeviceType : job[kDeviceType] as? String ?? "",
                                                       kLocalShootTime : job[kLocalShootTime] as? String ?? "",
                                                       kLocalShootTimeStr : job[kLocalShootTimeStr] as? String ?? "",
                                                       kParentScanId : job[kParentScanId] as! String,
                                                       kPhotosCount : job[kPhotosCount] as! Int,
                                                       kUnitCreatedOn : job[kUnitCreatedOn] as! String,
                                                       kUnitDisplayName : job[kUnitDisplayName] as! String,
                                                       kUnitId : job[kUnitId] as! String,
                                                       kUnitName : job[kUnitName] as! String,
                                                       kUnitStatus : unitStatus,
                                                       kUploaded : isUploaded,
                                                       kUploading : false,
                                                       kUploadStatus : UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue,
                                                       kUploadRunningStatus : UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                       kVideo : job[kVideo] as? Bool ?? false,
                                                       kUnitNotes: job[kUnitNotes] as? String ?? "",
                                                       kUnitSold: job[kUnitSold] as? Int ?? 0,
                                                       kIsUnitSelected: job[kIsUnitSelected] as? Bool ?? false,
                                                       kAppSelectionType: job[kAppSelectionType] as? String ?? "",
                                                       kJobId: firstJobId,
                                                       kJobName: firstJobName,
                                                       kJobStatus: firstJobStatus,
                                                           kTinyUrl : tinyUrl,
                                                       kMergePartDone: true,
                                                       kShootTime : job[kShootTime] as? Int ?? 0,
                                                       kJobIds: 0]
                                        
                                        scansToUpdate.append(scanDetails)
                                    }
                                    
                                }else if countOfExistingServerScan == 0 {
                                    LogConfig.logD(message:"INSERT A NEW SCAN!!!!!", displayToThirdParty: true)
                                    let insertScan = self.scansTable.insert(self.locationLat <- job[kLocationLat] as? Int ?? 0,
                                                                            self.locationLng <- job[kLocationLng] as? Int ?? 0,
                                                                            self.action <- job[kAction] as? String ?? "",
                                                                            self.deviceType <- job[kDeviceType] as? String ?? "",
                                                                            self.partId <- partDetails[kPartId] as! String,
                                                                            self.localShootTime <- job[kLocalShootTime] as? String ?? "",
                                                                            self.localShootTimeStr <- job[kLocalShootTimeStr] as? String ?? "",
                                                                            self.parentScanId <- job[kParentScanId] as! String,
                                                                            self.photosCount <- job[kPhotosCount] as! Int,
                                                                            self.unitCreatedOn <- job[kUnitCreatedOn] as! String,
                                                                            self.unitDisplayName <- job[kUnitDisplayName] as! String,
                                                                            self.unitId <- job[kUnitId] as! String,
                                                                            self.unitName <- job[kUnitName] as! String,
                                                                            self.unitStatus <- unitStatus,
                                                                            self.isUploaded <- isUploaded,
                                                                            self.isUploadingInProgress <- false,
                                                                            self.uploadStatus <- ((job[kJobIds] as? [String])?.count == 0) ? (UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue) : (UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue),
                                                                            self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                                            self.scanIsVideo <- job[kVideo] as? Bool ?? false,
                                                                            self.videoShootTime <- job[kShootTime] as? Int ?? 0,
                                                                            self.jobIDsCount <- (job[kJobIds] as? [String])?.count ?? 0,
                                                                            self.mergePartDone <- true,
                                                                            self.objectType <- jobWindowDict[kType] as? String ?? "window",
                                                                            self.objectTypeName <- jobWindowDict[kName] as? String ?? "",
                                                                            self.roomType <- jobRoomDict[kName] as? String ?? "",
                                                                            self.videoURLStr <- job[kVideoURLStr] as? String ?? "",
                                                                            self.unitNotes <- job[kUnitNotes] as? String ?? "",
                                                                            self.unitSold <- job[kUnitSold] as? Int ?? 0,
                                                                            self.isUnitSelected <- job[kIsUnitSelected] as? Bool ?? false,
                                                                            self.appSelectionType <- job[kAppSelectionType] as? String ?? "",
                                                                            self.jobID <- firstJobId,
                                                                            self.jobName <- firstJobName,
                                                                            self.jobStatus <- firstJobStatus,
                                                                            self.tinUrl <- tinyUrl
                                                                            )
                                    do {
                                        try pgDatabase.run(insertScan)
                                        
                                        if (job[kJobIds] as? [String])?.count == 0 {
                                            var scanDetails = [String : Any]()
                                            scanDetails = [kLocationLat : job[kLocationLat] as? Int ?? 0,
                                                           kLocationLng : job[kLocationLng] as? Int ?? 0,
                                                           kPartId : partDetails[kPartId] as! String,
                                                           kAction : job[kAction] as? String ?? "",
                                                           kDeviceType : job[kDeviceType] as? String ?? "",
                                                           kLocalShootTime : job[kLocalShootTime] as? String ?? "",
                                                           kLocalShootTimeStr : job[kLocalShootTimeStr] as? String ?? "",
                                                           kParentScanId : job[kParentScanId] as! String,
                                                           kPhotosCount : job[kPhotosCount] as! Int,
                                                           kUnitCreatedOn : job[kUnitCreatedOn] as! String,
                                                           kUnitDisplayName : job[kUnitDisplayName] as! String,
                                                           kUnitId : job[kUnitId] as! String,
                                                           kUnitName : job[kUnitName] as! String,
                                                           kUnitStatus : unitStatus,
                                                           kUploaded : isUploaded,
                                                           kUploading : false,
                                                           kUploadStatus : UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue,
                                                           kUploadRunningStatus : UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_UPLOADED.rawValue,
                                                           kVideo : job[kVideo] as? Bool ?? false,
                                                           kUnitNotes: job[kUnitNotes] as? String ?? "",
                                                           kUnitSold: job[kUnitSold] as? Int ?? 0,
                                                           kIsUnitSelected: job[kIsUnitSelected] as? Bool ?? false,
                                                           kAppSelectionType: job[kAppSelectionType] as? String ?? "",
                                                           kJobId: firstJobId,
                                                           kJobName: firstJobName,
                                                           kJobStatus: firstJobStatus,
                                                            kTinyUrl: tinyUrl,
                                                           kMergePartDone: true,
                                                           kShootTime : job[kShootTime] as? Int ?? 0,
                                                           kJobIds: 0]
                                            
                                            scansToUpdate.append(scanDetails)
                                        }
                                        
                                    }catch{
    //                                        LogConfig.logE(message:"Error in scan insertion - updateParts \(error)")
                                    }
                                    
                                }
                            }catch{
                                LogConfig.logE(message:"Error in listing SCANS", displayToThirdParty: true)
                            }
                        }
                    }
                    callback(scansToUpdate)
                } catch {
                    LogConfig.logE(message:"Error in part updation", displayToThirdParty: true)
                }
            }
        }
    
    func insertScansLocally(shootInfo: [String : Any], action: String, unitStatus: String, isVideo: Bool) {
        
        let partDetails = shootInfo[kPartDetails] as! [String : Any]
//        let scanDetails = shootInfo["scanDetails"] as! [[String : Any]]

        let insertScan = self.scansTable.insert(self.locationLat <- shootInfo[kLocationLat] as? Int ?? 0,
                                                self.locationLng <- shootInfo[kLocationLng] as? Int ?? 0,
                                                self.action <- action,
                                                self.deviceType <- str_phone,
                                                self.partId <- partDetails[kPartId] as! String,
                                                self.localShootTime <- shootInfo[kDateForDB] as! String,
                                                self.localShootTimeStr <- shootInfo[kLocalShootTimeStr] as? String ?? "",
                                                self.parentScanId <- shootInfo[kParentScanId] as? String ?? "",
                                                self.photosCount <- shootInfo[kPicCount] as! Int,
                                                self.unitCreatedOn <- shootInfo[kUnitCreatedOnLocal] as? String ?? "",
                                                self.unitDisplayName <- shootInfo[kDisplayName] as? String ?? "",
                                                self.unitId <- shootInfo[kScanName] as? String ?? "",
                                                self.unitName <- shootInfo[kScanName] as? String ?? "",
                                                self.unitStatus <- unitStatus,
                                                self.isUploaded <- false,
                                                self.isUploadingInProgress <- true,
                                                self.uploadStatus <- UPLOADSTATUS.UPLOAD_FILES_FAIL.rawValue,
                                                self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_NONE.rawValue,
                                                self.scanIsVideo <- shootInfo[kVideo] as? Bool ?? false,
                                                self.videoShootTime <- shootInfo[kVideoShootTime] as? Int ?? 0,
                                                self.jobIDsCount <- 0,
                                                self.mergePartDone <- false,
                                                self.objectType <- shootInfo[kObjectType] as? String ?? "window",
                                                self.objectTypeName <- shootInfo[kObjectTypeName] as? String ?? "",
                                                self.roomType <- shootInfo[kRoomType] as? String ?? "",
                                                self.videoURLStr <- shootInfo[kVideoURLStr] as? String ?? "",
                                                self.unitNotes <- shootInfo[kUnitNotes] as? String ?? "",
                                                self.unitSold <- shootInfo[kUnitSold] as? Int ?? 0,
                                                self.isUnitSelected <- shootInfo[kIsUnitSelected] as? Bool ?? false,
                                                self.appSelectionType <- shootInfo[kAppSelectionType] as? String ?? "",
                                                self.jobID <- shootInfo[kJobIds] as? String,
                                                self.jobName <- shootInfo[kJobName] as? String,
                                                self.jobStatus <- shootInfo[kJobStatus] as? String,
                                                self.tinUrl <- shootInfo[kTinyUrl] as? String)
        do {
            try pgDatabase.run(insertScan)
            LogConfig.logD(message:"Local Scan inserted", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error in scan insertion -insertScansLocally \(error)", displayToThirdParty: true)
        }
        
    }
    
//    func updateLocalScanNotes(scanData: [String : Any], notes: String, callback: (() -> ())) {
//        do {
//            let filteredscan = scansTable.filter(self.unitId == scanData[kScanName] as! String)
//
//            try pgDatabase.run(filteredscan.update(self.unitNotes <- notes))
//            LogConfig.logD(message:"Localscan for notes UPDATED", displayToThirdParty: true)
//        }catch{
//            LogConfig.logE(message:"Error in Local scan updation \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
    
    func updateLocalScan(scanData: [String : Any], uploadStatus: String, uploadStatusStr: String, callback: (() -> ())) {
        do {
            let filteredscan = scansTable.filter(self.unitName == scanData[kScanName] as! String)
            
            try pgDatabase.run(filteredscan.update(self.unitStatus <- uploadStatusStr,
                                                   self.isUploaded <- false,
                                                   self.isUploadingInProgress <- true,
                                                   self.uploadStatus <- uploadStatus,
                                                   self.mergePartDone <- (uploadStatus == UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue ? true : false),
                                                   self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_NONE.rawValue))
            
            LogConfig.logD(message:"Localscan updated UPDATED", displayToThirdParty: true)
            LogConfig.logD(message:"Localscan \(String(describing: scanData[kScanName])) updated UPDATED with \n Unitstatus \(uploadStatusStr)\n isUploaded: False\n isUploadProgess: true \n upload status: \(uploadStatus) \n mergepartDone: \((uploadStatus == UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue ? true : false)) \n uploadRunning Status:\(UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_NONE.rawValue)", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error in Local scan updation \(error)", displayToThirdParty: true)
        }
        callback()
    }
    
    func updateInspectionJobScan(scanData: [String : Any], uploadStatus: String, callback: (() -> ())) {
        do {
            let filteredscan = scansTable.filter(self.unitName == scanData[kUnitName] as! String)
            
            try pgDatabase.run(filteredscan.update(self.unitStatus <- str_Uploaded,
                                                   self.isUploaded <- true,
                                                   self.isUploadingInProgress <- false,
                                                   self.uploadStatus <- uploadStatus,
                                                   self.mergePartDone <- true,
                                                   self.uploadRunningStatus <- UPLOADRUNNINGSTATUS.UPLOAD_RUNNING_STATUS_NONE.rawValue
            ))
            
            LogConfig.logD(message:"Localscan updated UPDATED", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error in Local scan updation \(error)", displayToThirdParty: true)
        }
        callback()
    }
    
//    func updateUnitStatusOfLocalScan(scanData: [String : Any], uploadStatus: String, callback: (() -> ())) {
//        do {
//            let filteredscan = scansTable.filter(self.unitId == scanData[kScanName] as! String)
//
//            try pgDatabase.run(filteredscan.update(self.unitStatus <- uploadStatus))
//
//            LogConfig.logD(message:"Localscan updated UPDATED", displayToThirdParty: true)
//        }catch{
//            LogConfig.logE(message:"Error in Local scan updation \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
    
    func updateUnitStatusOfScan(scanData: [String : Any], unitStatus: String, callback: (() -> ())) {
        do {
            if scanData[kUnitId] as? String != nil {
                let filteredscan = scansTable.filter(self.unitName == scanData[kUnitName] as! String)
                
                try pgDatabase.run(filteredscan.update(self.unitStatus <- unitStatus))
                
                LogConfig.logD(message:"UnitStatusOfScan updated UPDATED \(unitStatus)", displayToThirdParty: true)
            }
        }catch{
            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
        }
        callback()
    }
    
    func updateMergePartOfScan(scanData: [String : Any]) {
        do {
            if scanData[kUnitName] as? String != nil {
                let filteredscan = scansTable.filter(self.unitName == scanData[kUnitName] as! String)
                
                try pgDatabase.run(filteredscan.update(self.mergePartDone <- true))
                
                LogConfig.logD(message:"UnitStatusOfScan updated UPDATED", displayToThirdParty: true)
            }
        }catch{
            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
        }
    }
    
//    func updateUploadStatusOfScan(scanData: [String : Any], unitstatus: String, uploadStatus: Bool, isProgressStatus: Bool, callback: (() -> ())) {
//        do {
//            if scanData[kUnitId] as? String != nil {
//                let filteredscan = scansTable.filter(self.unitId == scanData[kUnitId] as! String)
//
//                try pgDatabase.run(filteredscan.update(self.unitStatus <- unitStatus,
//                                                       self.isUploaded <- uploadStatus,
//                                                       self.isUploadingInProgress <- isProgressStatus))
//
//                LogConfig.logD(message:"UnitStatusOfScan updated UPDATED", displayToThirdParty: true)
//            }
//        }catch{
//            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
    
//    func getUnitScanStatus(unitId: String,callback: ((String) -> ())){
//        do {
//            var unitStatus = ""
//            let scans = try pgDatabase.prepare(self.scansTable)
//            for scan in scans{
//                if scan[self.unitId] == unitId{
//                    unitStatus = scan[self.unitStatus] as? String ?? ""
//                }
//            }
//            callback(unitStatus)
//
//            LogConfig.logD(message:"UnitStatusOfScan updated UPDATED", displayToThirdParty: true)
//
//        }catch{
//            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
//        }
//        callback("")
//    }
    
//    func updateUnitStatusOfScanByID(scanID: String, unitStatus: String, callback: (() -> ())) {
//        do {
//            let filteredscan = scansTable.filter(self.unitId == scanID)
//
//            try pgDatabase.run(filteredscan.update(self.unitStatus <- unitStatus))
//
//            LogConfig.logD(message:"UnitStatusOfScan updated UPDATED", displayToThirdParty: true)
//        }catch{
//            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
//
    func updateScansForRetryUpload(unitName: String, callback: (() -> ())) {
        do {
            let filteredscan = scansTable.filter(self.unitName == unitName)
            
            try pgDatabase.run(filteredscan.update(self.unitStatus <- str_uploading))
            LogConfig.logD(message:"UnitStatusOfScan updated UPDATED", displayToThirdParty: true)
            self.queueRetryUploadJobs()
            
        }catch{
            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
        }
        callback()
    }
    
//    func updateMarkAsSold(scanData: [String : Any], markValue: Int, callback: (() -> ())) {
//        do {
//            if scanData[kUnitId] as? String != nil {
//                let filteredscan = scansTable.filter(self.unitId == scanData[kUnitId] as! String)
//
//                try pgDatabase.run(filteredscan.update(self.unitSold <- markValue))
//
//                LogConfig.logD(message:"Mark as sold updated for Window", displayToThirdParty: true)
//            }
//        }catch{
//            LogConfig.logE(message:"Error in Mark as sold updation \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
    
//    func updateUnitSelection(scanData: [String : Any], selection: Bool, callback: (() -> ())) {
//        do {
//            if scanData[kUnitId] as? String != nil {
//                let filteredscan = scansTable.filter(self.unitId == scanData[kUnitId] as! String)
//
//                try pgDatabase.run(filteredscan.update(self.isUnitSelected <- selection))
//
//                LogConfig.logD(message:"Unit selection updated for Window", displayToThirdParty: true)
//            }
//        }catch{
//            LogConfig.logE(message:"Error in Unit selection updation \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
    
    func queueRetryUploadJobs() {
        do {
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans {
                if (scan[self.unitStatus] == str_retry_upload) {
                    let newFilteredscan = scansTable.filter(self.unitName == scan[self.unitName])
                    try pgDatabase.run(newFilteredscan.update(self.unitStatus <- str_queued))
                }
            }
        } catch{
            LogConfig.logE(message:"Error in UnitStatusOfScan updation \(error)", displayToThirdParty: true)
        }
    }
    
    func checkForJobsUpdating() -> Bool {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_updating) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            if scansList.count > 0 {
                return true
            }else{
                return false
            }
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return false
        }
    }
    
    func getUpdatingJobs() -> [Dictionary<String, Any>] {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_updating) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            return scansList
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return [[:]]
        }
    }
    
    func checkForJobsUploading() -> Bool {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_uploading) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            if scansList.count > 0 {
                return true
            }else{
                return false
            }
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return false
        }
    }
    
    func getUploadingJobs() -> [Dictionary<String, Any>] {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_uploading) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            return scansList
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return [[:]]
        }
    }
    
    func checkForRetryUploadJobs() -> (Bool, [[String : Any]])  {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_retry_upload) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            if scansList.count > 0 {
                return (true, scansList)
            }else{
                return (false, scansList)
            }
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return (false, [])
        }
    }
    
    func checkForJobsQueued() -> (Bool, [[String : Any]])  {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_queued) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            if scansList.count > 0 {
                return (true, scansList)
            }else{
                return (false, scansList)
            }
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return (false, [])
        }
    }
    
    func checkForJobsPaused() -> (Bool, [[String : Any]])  {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_paused) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            if scansList.count > 0 {
                return (true, scansList)
            }else{
                return (false, scansList)
            }
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return (false, [])
        }
    }
    
    func getJobUploading() -> ([[String : Any]])  {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (scan[self.unitStatus] == str_uploading) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? ""]
                    
                    scansList.append(scanDetails)
                }
            }
            return scansList
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return ([])
        }
    }
    
//    func deleteLocalScan(scanData: [String : Any], callback: (() -> ())) {
//        do {
//            let filteredScan = scansTable.filter(self.unitId == scanData[kUnitId] as! String)
//
//            try pgDatabase.run(filteredScan.delete())
//
//            LogConfig.logD(message:"Local scan deleted UPDATED", displayToThirdParty: true)
//        }catch{
//            LogConfig.logE(message:"Error in scan deletion \(error)", displayToThirdParty: true)
//        }
//        callback()
//    }
    
    func deleteLocalPart(partName: String) {
        do {
            let filteredScan = allPartsTable.filter(self.partName == partName)
            
            try pgDatabase.run(filteredScan.delete())
            
            LogConfig.logD(message:"Local part deleted ", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error in part deletion \(error)", displayToThirdParty: true)
        }
    }
    
    
    func listParts() {
        do {
            let parts = try pgDatabase.prepare(self.allPartsTable)
            for part in parts{
                LogConfig.logD(message:"lat: \(part[self.locationLat]), lng: \(part[self.locationLng]), LocalPTCreation: \(String(describing: part[self.localPartTimeCreation])), partCreatedon: \(part[self.partCreatedOn]), partId: \(part[self.partId]),partName: \(part[self.partName]),partdesc: \(String(describing: part[self.partDesc])), photosCount: \(part[self.photosCount]),profilePic: \(String(describing: part[self.profilePic])), scanCount: \(part[self.scanCount]), unitCount: \(part[self.unitCount])", displayToThirdParty: true)
            }
        }catch{
            LogConfig.logE(message:"Error in listing Parts", displayToThirdParty: true)
        }
    }
    
    func listScans() {
        do {
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                LogConfig.logD(message:"""
                    partId: \(scan[self.partId])
                    lat: \(scan[self.locationLat]), \n
                    lng: \(scan[self.locationLng]),\n
                    action: \(String(describing: scan[self.action])), \n
                    deviceType: \(String(describing: scan[self.deviceType])), \n
                    localShootTime: \(String(describing: scan[self.localShootTime])), \n
                    localShootTimeStr: \(String(describing: scan[self.localShootTimeStr])), \n
                    parentScanId: \(String(describing: scan[self.parentScanId])), \n
                    photosCount: \(scan[self.photosCount]), \n
                    unitCreatedOn: \(scan[self.unitCreatedOn]), \n
                    unitDisplayName: \(scan[self.unitDisplayName]), \n
                    unitId: \(scan[self.unitId]), \n
                    unitName: \(scan[self.unitName]), \n
                    unitStatus: \(scan[self.unitStatus]), \n
                    """, displayToThirdParty: true)
            }
        }catch{
            LogConfig.logE(message:"Error in listing Parts", displayToThirdParty: true)
        }
    }
    func getPartsFromTable() -> [[String : Any]] {
        do {
            var partList = [Dictionary<String, Any>]()
            var partDetails = [String : Any]()
            let parts = try pgDatabase.prepare(self.allPartsTable)
            for part in parts{
                                
                partDetails = [kLocationLat : part[self.locationLat],
                               kLocationLng : part[self.locationLng],
                               kLocalPartTimeCreation : part[self.localPartTimeCreation] as Any,
                               kPartCreatedOn : part[self.partCreatedOn],
                               kPartId : part[self.partId],
                               kPartName : part[self.partName],
                               kPartDesc : part[self.partDesc] ?? "",
                               kPhotosCount : part[self.photosCount],
                               kProfilePic : part[self.profilePic] ?? "",
                               kScanCount : part[self.scanCount],
                               kUnitCount : part[self.unitCount],
                               kAddress: part[self.address] ?? "",
                               kZipCode: part[self.zipCode] ?? "",
                               kPartCustomer: part[self.partCustomer] ?? "",
                               kLatestShootTime : part[self.latestShootTime]]
                
                partList.append(partDetails)
            }
            
            partList.sort(by: {(helperGetServerTimeInMillis(serverTime: $0[kLatestShootTime] as! String)) > (helperGetServerTimeInMillis(serverTime: $1[kLatestShootTime] as! String))})
            return partList
//            callback(partList)
            
        }catch{
            LogConfig.logE(message:"Error in listing Parts", displayToThirdParty: true)
            return []
//            return callback([])
        }
    }
    
    func getScansForPartFromTable(partID: String) -> [[String : Any]] {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable)
            for scan in scans{
                if (partID == scan[self.partId]) {
                    scanDetails = [kLocationLat : scan[self.locationLat],
                                   kLocationLng : scan[self.locationLng],
                                   kPartId : scan[self.partId],
                                   kAction : scan[self.action],
                                   kDeviceType : scan[self.deviceType],
                                   kLocalShootTime : scan[self.localShootTime],
                                   kLocalShootTimeStr : scan[self.localShootTimeStr],
                                   kParentScanId : scan[self.parentScanId],
                                   kPhotosCount : scan[self.photosCount],
                                   kUnitCreatedOn : scan[self.unitCreatedOn],
                                   kUnitDisplayName : scan[self.unitDisplayName],
                                   kUnitId : scan[self.unitId],
                                   kUnitName : scan[self.unitName],
                                   kUnitStatus : scan[self.unitStatus],
                                   kUploaded : scan[self.isUploaded],
                                   kUploading : scan[self.isUploadingInProgress],
                                   kUploadStatus : scan[self.uploadStatus],
                                   kUploadRunningStatus : scan[self.uploadRunningStatus],
                                   kVideo : scan[self.scanIsVideo],
                                   kShootTime : scan[self.videoShootTime],
                                   kJobIds: scan[self.jobIDsCount],
                                   kMergePartDone: scan[self.mergePartDone],
                                   kObjectType: scan[self.objectType],
                                   kObjectTypeName: scan[self.objectTypeName],
                                   kRoomType: scan[self.roomType],
                                   kVideoURLStr: scan[self.videoURLStr],
                                   kUnitNotes: scan[self.unitNotes],
                                   kUnitSold: scan[self.unitSold],
                                   kIsUnitSelected: scan[self.isUnitSelected],
                                   kAppSelectionType: scan[self.appSelectionType]!,
                                   kJobId: scan[self.jobID]!,
                                   kJobName: scan[self.jobName]!,
                                   kJobStatus: scan[self.jobStatus]!,
                                   kTinyUrl: scan[self.tinUrl] ?? "",
                                   kRequestId: scan[self.requestId] ?? "" ]
                    
                    scansList.append(scanDetails)
                }
            }
            return scansList
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return []
        }
    }
    
    func getPartsForDate(dates: [Date]) -> [[String : Any]] {
        do {
            var partList = [Dictionary<String, Any>]()
            var partDetails = [String : Any]()

            for date in dates {
                let parts = try pgDatabase.prepare(self.allPartsTable)
                let dateStr = date.toString()
                let dateComponent = dateStr.components(separatedBy: " ")
                let dateSelectedStr = dateComponent[0] //"28-01-2021"
                
                for part in parts {
                    let partDate = part[self.latestShootTime]
                    let dateCompont = partDate.components(separatedBy: "T")
                    if dateCompont[0] != "" {
                        let dateFromParts = helperChangeDateFormat(dateString: dateCompont[0]) // "2021-01-28"

                        if dateSelectedStr == dateFromParts {
                            partDetails = [kLocationLat : part[self.locationLat],
                                           kLocationLng : part[self.locationLng],
                                           kLocalPartTimeCreation : part[self.localPartTimeCreation] as Any,
                                           kPartCreatedOn : part[self.partCreatedOn],
                                           kPartId : part[self.partId],
                                           kPartName : part[self.partName],
                                           kPartDesc : part[self.partDesc] ?? "",
                                           kPhotosCount : part[self.photosCount],
                                           kProfilePic : part[self.profilePic] ?? "",
                                           kScanCount : part[self.scanCount],
                                           kUnitCount : part[self.unitCount],
                                           kLatestShootTime : part[self.latestShootTime],
                                           kAddress: part[self.address] ?? "",
                                           kZipCode: part[self.zipCode] ?? "",
                                           kPartCustomer: part[self.partCustomer] ?? ""]
                            
                            partList.append(partDetails)
                        }
                    }
                }
            }
            return partList
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return []
        }
    }
    
    func getScansForDate(dates: [Date], allScans: [[String : Any]]) -> [[String : Any]] {
        var scansList = [Dictionary<String, Any>]()

        for date in dates {
            let dateStr = date.toString()
            let dateComponent = dateStr.components(separatedBy: " ")
            let dateSelectedStr = dateComponent[0] //"28-01-2021"
            
            for scan in allScans {
//                let scanDate = scan[kUnitCreatedOn] as! String
                let dateCompont = (scan[kUnitCreatedOn] as! String).components(separatedBy: "T")
                if dateCompont[0] != "" {
                    let dateFromParts = helperChangeDateFormat(dateString: dateCompont[0]) // "2021-01-28"
                    
                    if dateSelectedStr == dateFromParts {
                        scansList.append(scan)
                    }
                }
                
            }
        }
        return scansList
    }
    
    func getSinglePartFromTable(partId: String) -> [[String : Any]] {
        do {
            var partList = [Dictionary<String, Any>]()
            var partDetails = [String : Any]()
            let parts = try pgDatabase.prepare(self.allPartsTable)
            for part in parts{
                if (partId == part[self.partId]) {
                    partDetails = [kLocationLat : part[self.locationLat],
                                   kLocationLng : part[self.locationLng],
                                   kLocalPartTimeCreation : part[self.localPartTimeCreation] as Any,
                                   kPartCreatedOn : part[self.partCreatedOn],
                                   kPartId : part[self.partId],
                                   kPartName : part[self.partName],
                                   kPartDesc : part[self.partDesc] ?? "",
                                   kPhotosCount : part[self.photosCount],
                                   kProfilePic : part[self.profilePic] ?? "",
                                   kScanCount : part[self.scanCount],
                                   kUnitCount : part[self.unitCount],
                                   kAddress: part[self.address] ?? "",
                                   kZipCode: part[self.zipCode] ?? "",
                                   kPartCustomer: part[self.partCustomer] ?? "",
                                   kLatestShootTime : part[self.latestShootTime]]
                    partList.append(partDetails)
                }
            }
            
            return partList
            
        }catch{
            LogConfig.logE(message:"Error in getSinglePartFromTable", displayToThirdParty: true)
            return []
        }
    }
    
    func getPartFromTable(withPartName: String) -> [String : Any] {
        do {
            var partDetails = [String : Any]()
            let parts = try pgDatabase.prepare(self.allPartsTable)
            for part in parts{
                if (part[self.partName].uppercased() == withPartName.uppercased()) {
                    partDetails = [kLocationLat : part[self.locationLat],
                                   kLocationLng : part[self.locationLng],
                                   kLocalPartTimeCreation : part[self.localPartTimeCreation] as Any,
                                   kPartCreatedOn : part[self.partCreatedOn],
                                   kPartId : part[self.partId],
                                   kPartName : part[self.partName],
                                   kPartDesc : part[self.partDesc] ?? "",
                                   kPhotosCount : part[self.photosCount],
                                   kProfilePic : part[self.profilePic] ?? "",
                                   kScanCount : part[self.scanCount],
                                   kUnitCount : part[self.unitCount],
                                   kAddress: part[self.address] ?? "",
                                   kZipCode: part[self.zipCode] ?? "",
                                   kPartCustomer: part[self.partCustomer] ?? "",
                                   kLatestShootTime : part[self.latestShootTime]]
                }
            }
            return partDetails
            
        }catch{
            LogConfig.logE(message:"Error in getSinglePartFromTable", displayToThirdParty: true)
            return [:]
        }
    }
    
    func getPartFromTable(withPartId: String) -> [String : Any] {
        do {
            var partDetails = [String : Any]()
            let parts = try pgDatabase.prepare(self.allPartsTable)
            for part in parts{
                if (part[self.partId] == withPartId) {
                    partDetails = [kLocationLat : part[self.locationLat],
                                   kLocationLng : part[self.locationLng],
                                   kLocalPartTimeCreation : part[self.localPartTimeCreation] as Any,
                                   kPartCreatedOn : part[self.partCreatedOn],
                                   kPartId : part[self.partId],
                                   kPartName : part[self.partName],
                                   kPartDesc : part[self.partDesc] ?? "",
                                   kPhotosCount : part[self.photosCount],
                                   kProfilePic : part[self.profilePic] ?? "",
                                   kScanCount : part[self.scanCount],
                                   kUnitCount : part[self.unitCount],
                                   kAddress: part[self.address] ?? "",
                                   kZipCode: part[self.zipCode] ?? "",
                                   kPartCustomer: part[self.partCustomer] ?? "",
                                   kLatestShootTime : part[self.latestShootTime]]
                }
            }
            return partDetails
            
        }catch{
            LogConfig.logE(message:"Error in getSinglePartFromTable", displayToThirdParty: true)
            return [:]
        }
    }
    
    func getScanByUnitId(unitId:String) -> ([[String : Any]])  {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable.filter(self.unitId == unitId))
            for scan in scans{
                scanDetails = [
                       kLocationLat : scan[self.locationLat],
                       kLocationLng : scan[self.locationLng],
                       kPartId : scan[self.partId],
                       kAction : scan[self.action],
                       kDeviceType : scan[self.deviceType],
                       kLocalShootTime : scan[self.localShootTime],
                       kLocalShootTimeStr : scan[self.localShootTimeStr],
                       kParentScanId : scan[self.parentScanId],
                       kPhotosCount : scan[self.photosCount],
                       kUnitCreatedOn : scan[self.unitCreatedOn],
                       kUnitDisplayName : scan[self.unitDisplayName],
                       kUnitId : scan[self.unitId],
                       kUnitName : scan[self.unitName],
                       kUnitStatus : scan[self.unitStatus],
                       kUploaded : scan[self.isUploaded],
                       kUploading : scan[self.isUploadingInProgress],
                       kUploadStatus : scan[self.uploadStatus],
                       kUploadRunningStatus : scan[self.uploadRunningStatus],
                       kVideo : scan[self.scanIsVideo],
                       kShootTime : scan[self.videoShootTime],
                       kJobIds: scan[self.jobIDsCount],
                       kMergePartDone: scan[self.mergePartDone],
                       kObjectType: scan[self.objectType],
                       kObjectTypeName: scan[self.objectTypeName],
                       kRoomType: scan[self.roomType],
                       kVideoURLStr: scan[self.videoURLStr],
                       kUnitNotes: scan[self.unitNotes],
                       kUnitSold: scan[self.unitSold],
                       kIsUnitSelected: scan[self.isUnitSelected],
                       kAppSelectionType: scan[self.appSelectionType]!,
                       kJobId: scan[self.jobID]!,
                       kJobName: scan[self.jobName]!,
                       kJobStatus: scan[self.jobStatus]!,
                       kTinyUrl: scan[self.tinUrl] ?? "",
                       kRequestId: scan[self.requestId] ?? ""]
                
                scansList.append(scanDetails)
            }
            return scansList
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return ([])
        }
        
    }
    
    
    func dropTables(){
        
        do{
            try pgDatabase.run(allPartsTable.drop(ifExists: true))
            LogConfig.logD(message:"##########SUCCESS while dropping parts table##########", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"ERROR while dropping parts table", displayToThirdParty: true)
        }
        
        do{
            try pgDatabase.run(scansTable.drop(ifExists: true))
            LogConfig.logD(message:"##########SUCCESS while dropping scans table##########", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"ERROR while dropping scans table", displayToThirdParty: true)
        }
    }
    
    func updateUnitStatusToInQueueIfStatusIs(forStatus:String) {
        do {
            let filteredscan = scansTable.filter(self.unitStatus == forStatus && self.appSelectionType != "" && self.isUploaded == false)
            try pgDatabase.run(filteredscan.update(self.unitStatus <- str_queued))
            
            LogConfig.logD(message:"Update Unit Status Of Scan App Starts Up Localscan updated UPDATED", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error in Local scan updation \(error)", displayToThirdParty: true)
        }
    }
    
    func getScanByUnitName(unitName:String) -> ([[String : Any]])  {
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(self.scansTable.filter(self.unitName == unitName))
            for scan in scans{
                scanDetails = [
                       kLocationLat : scan[self.locationLat],
                       kLocationLng : scan[self.locationLng],
                       kPartId : scan[self.partId],
                       kAction : scan[self.action],
                       kDeviceType : scan[self.deviceType],
                       kLocalShootTime : scan[self.localShootTime],
                       kLocalShootTimeStr : scan[self.localShootTimeStr],
                       kParentScanId : scan[self.parentScanId],
                       kPhotosCount : scan[self.photosCount],
                       kUnitCreatedOn : scan[self.unitCreatedOn],
                       kUnitDisplayName : scan[self.unitDisplayName],
                       kUnitId : scan[self.unitId],
                       kUnitName : scan[self.unitName],
                       kUnitStatus : scan[self.unitStatus],
                       kUploaded : scan[self.isUploaded],
                       kUploading : scan[self.isUploadingInProgress],
                       kUploadStatus : scan[self.uploadStatus],
                       kUploadRunningStatus : scan[self.uploadRunningStatus],
                       kVideo : scan[self.scanIsVideo],
                       kShootTime : scan[self.videoShootTime],
                       kJobIds: scan[self.jobIDsCount],
                       kMergePartDone: scan[self.mergePartDone],
                       kObjectType: scan[self.objectType],
                       kObjectTypeName: scan[self.objectTypeName],
                       kRoomType: scan[self.roomType],
                       kVideoURLStr: scan[self.videoURLStr],
                       kUnitNotes: scan[self.unitNotes],
                       kUnitSold: scan[self.unitSold],
                       kIsUnitSelected: scan[self.isUnitSelected],
                       kAppSelectionType: scan[self.appSelectionType]!,
                       kJobId: scan[self.jobID]!,
                       kJobName: scan[self.jobName]!,
                       kJobStatus: scan[self.jobStatus]!,
                       kTinyUrl: scan[self.tinUrl] ?? "",
                       kRequestId: scan[self.requestId] ?? ""]
                
                scansList.append(scanDetails)
            }
            return scansList
            
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return ([])
        }
        
    }
    
    func updateRequestId(forUnitName:String,requestId:String) {
        do {
            let filteredscan = scansTable.filter(self.unitName == forUnitName)
            try pgDatabase.run(filteredscan.update(self.requestId <- requestId))
            
            LogConfig.logD(message:"Update Request Id \(forUnitName)  \(requestId)", displayToThirdParty: true)
        }catch{
            LogConfig.logE(message:"Error in Local scan updation \(error)", displayToThirdParty: true)
        }
    }
    
    func getScanInfoForPartsUploading() -> [Dictionary<String, Any>] {
        let joinTable = scansTable.join(allPartsTable, on: allPartsTable[partId] == scansTable[partId])
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(joinTable.filter(self.isUploaded == false && self.unitStatus == str_uploading))
            for scan in scans{
                scanDetails = [kPartId : scan[allPartsTable[partId]],
                               kPartName : scan[allPartsTable[partName]],
                               kPartDesc : scan[allPartsTable[partDesc]] ?? "",
                               kProfilePic : scan[allPartsTable[profilePic]] ?? "",
                               kLatestShootTime : scan[allPartsTable[latestShootTime]],
                               kUnitCreatedOn : scan[scansTable[unitCreatedOn]],
                               kUnitDisplayName : scan[scansTable[unitDisplayName]],
                               kUnitId : scan[scansTable[unitId]],
                               kUnitName : scan[scansTable[unitName]],
                               kUnitStatus : scan[scansTable[unitStatus]],
                               kUploaded : scan[scansTable[isUploaded]],
                               kUploading : scan[scansTable[isUploadingInProgress]],
                               kUploadStatus : scan[scansTable[uploadStatus]],
                               kUploadRunningStatus : scan[scansTable[uploadRunningStatus]],
                               kVideo : scan[scansTable[scanIsVideo]],
                               kVideoURLStr: scan[scansTable[videoURLStr]],
                               kAppSelectionType: scan[scansTable[appSelectionType]]!,
                               kJobId: scan[scansTable[jobID]]!,
                               kJobName: scan[scansTable[jobName]]!,
                               kJobStatus: scan[scansTable[jobStatus]]!,
                               kTinyUrl: scan[scansTable[tinUrl]] ?? ""
                            ]

                scansList.append(scanDetails)
            }
            return scansList
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return [[:]]
        }
    }
    
    func getScanInfoForPartsNoUploaded() -> [Dictionary<String, Any>] {
        let joinTable = scansTable.join(allPartsTable, on: allPartsTable[partId] == scansTable[partId])
        do {
            var scansList = [Dictionary<String, Any>]()
            var scanDetails = [String : Any]()
            let scans = try pgDatabase.prepare(joinTable.filter(self.isUploaded == false && self.unitStatus != str_uploading))
            for scan in scans{
                scanDetails = [kPartId : scan[allPartsTable[partId]],
                               kPartName : scan[allPartsTable[partName]],
                               kPartDesc : scan[allPartsTable[partDesc]] ?? "",
                               kProfilePic : scan[allPartsTable[profilePic]] ?? "",
                               kLatestShootTime : scan[allPartsTable[latestShootTime]],
                               kUnitCreatedOn : scan[scansTable[unitCreatedOn]],
                               kUnitDisplayName : scan[scansTable[unitDisplayName]],
                               kUnitId : scan[scansTable[unitId]],
                               kUnitName : scan[scansTable[unitName]],
                               kUnitStatus : scan[scansTable[unitStatus]],
                               kUploaded : scan[scansTable[isUploaded]],
                               kUploading : scan[scansTable[isUploadingInProgress]],
                               kUploadStatus : scan[scansTable[uploadStatus]],
                               kUploadRunningStatus : scan[scansTable[uploadRunningStatus]],
                               kVideo : scan[scansTable[scanIsVideo]],
                               kVideoURLStr: scan[scansTable[videoURLStr]],
                               kAppSelectionType: scan[scansTable[appSelectionType]]!,
                               kJobId: scan[scansTable[jobID]]!,
                               kJobName: scan[scansTable[jobName]]!,
                               kJobStatus: scan[scansTable[jobStatus]]!,
                               kTinyUrl: scan[scansTable[tinUrl]] ?? ""
                            ]

                scansList.append(scanDetails)
            }
            return scansList
        }catch{
            LogConfig.logE(message:"Error in listing SCans", displayToThirdParty: true)
            return [[:]]
        }
    }
    
}

