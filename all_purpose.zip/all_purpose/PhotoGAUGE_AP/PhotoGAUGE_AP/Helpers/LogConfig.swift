//
//  LogConfig.swift
//  ConstructionApp
//
//  Created by Surbhi Lath on 01/03/22.
//  Copyright © 2022 Photo Gauge. All rights reserved.
//

import Foundation
import BugfenderSDK
import FirebaseCrashlytics
//import Kingfisher

class LogConfig{
    
    static func logD(message: String, displayToThirdParty: Bool){
       Logger.debug(message)
        if displayToThirdParty{
            Crashlytics.crashlytics().log(message)
#if !DEBUG
            Bugfender.print(message)
#endif
        }
    }
    
    
    static func logW(message: String, displayToThirdParty: Bool){
        Logger.debug(message)
        if displayToThirdParty{
            Crashlytics.crashlytics().log(message)
#if !DEBUG
            Bugfender.warning(message)
#endif
        }
    }
    
    static func logE(message: String, displayToThirdParty: Bool){
        Logger.debug(message)
        if displayToThirdParty{
            Crashlytics.crashlytics().log(message)
#if !DEBUG
            Bugfender.error(message)
#endif
        }
    }
    
}
