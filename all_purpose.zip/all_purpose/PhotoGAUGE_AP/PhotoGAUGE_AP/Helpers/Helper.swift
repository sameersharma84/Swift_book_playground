//
//  Helper.swift
//  PhotoGauge
//
//  Created by apple on 04/08/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import UIKit
import SnackBar_swift

class PGSnackBar: SnackBar {
    override var style: SnackBarStyle {
        var style = SnackBarStyle()
        style.background = .black
        style.textColor = .white
        return style
    }
}


struct AppUtility {
    static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.orientationLock = orientation
        }
    }
    /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
    static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {
        self.lockOrientation(orientation)
        UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
        UINavigationController.attemptRotationToDeviceOrientation()
    }
}

func helperCheckAppUpdateVersion() -> String {
    return UserDefaults.standard.string(forKey: kLastAppUpdateVersion) ?? ""
}

func helperSetAppUpdateVersion() {
    UserDefaults.standard.set(helperGetAppVersion(), forKey: kLastAppUpdateVersion)
}

// return the instance of app delegate (Global function)
func helperGetAppDeleate() -> AppDelegate {
    let delegate = UIApplication.shared.delegate as! AppDelegate
    return delegate
}

func helperIsLogin() -> Bool {
    return UserDefaults.standard.bool(forKey: kLoggedIn)
}

func helperGetDocumentsDirectory() -> URL {
    let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
    return paths[0]
}

func helperGetAppVersion() -> String {
    guard let dict = Bundle.main.infoDictionary else {
        return ""
    }
    let build = helperGetAppBuildNo()
    
    if let version: String = dict["CFBundleShortVersionString"] as? String {
        return version + " (\(build))"
    } else{
        return ""
    }
}

func helperGetAppBuildNo() -> String {
    guard let dict = Bundle.main.infoDictionary else {
        return ""
    }
    
    if let build: String = dict["CFBundleVersion"] as? String {
        return build
    } else{
        return ""
    }
}


func helperGetAppName() -> String {
    guard let dict = Bundle.main.infoDictionary else {
        return ""
    }
    
    if let appName: String = dict["CFBundleName"] as? String {
        return appName
    } else{
        return ""
    }
}

func helperAddAttributeToLabel(baseString: String, hightlightString: String) -> NSMutableAttributedString {
    let range = (baseString as NSString).range(of: hightlightString)
    let attributedString = NSMutableAttributedString(string: baseString)
    attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.blue, range: range)
    attributedString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range)
    
    return attributedString
}

func helperSetEnvironment(env: ENVIRONMENT) -> Void {
    UserDefaults.standard.set(env.rawValue, forKey: kEnvironment)
}

func helperGetEnvironment() -> ENVIRONMENT {
    return ENVIRONMENT(rawValue: UserDefaults.standard.integer(forKey: kEnvironment)) ?? ENVIRONMENT.ENVIRONMENT_PRODUCTION
}

func helperCheckAuthTokenExpiry() {
    if UserSession.shared.getUserData() != nil {
        let tokenExpiry = UserSession.shared.getUserData()?.authTokenExpiry
        let authToken = UserSession.shared.getUserData()?.authToken
        let currentTime = Date().timeIntervalSince1970 * 1000
        let tweleveHrs = Double(12 * 3600 * 1000) //12hrs in ms

        if (!helperGetAppDeleate().isOffline && tokenExpiry! > 0 && (tokenExpiry! - currentTime) < tweleveHrs){
            LogConfig.logD(message:"#####****** TOKEN: \(authToken!) EXPIRED #####******", displayToThirdParty: true)
            helperGetAppDeleate().refreshAppToken()
        }else{
            LogConfig.logD(message:"#####****** TOKEN: \(authToken!) IS NOT EXPIRED #####******", displayToThirdParty: true)
        }
    }else{
        LogConfig.logD(message:"#####****** USER DATA NIL CHECK AUTH TOKEN EXPIRY #####******", displayToThirdParty: true)
    }
}

func helperGetCurrentDate() -> String {
    let currentDateTime = Date()
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    
    let dateString = formatter.string(from: currentDateTime)
    return dateString
}

func helperGetISODateString() -> String {
    let date = Date()
    let formatter = DateFormatter()
//    formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss ZZZ"
    let dateStr = formatter.string(from: date)
    return dateStr
}

func helperGetFormattedTime() -> String {
    let date = Date()
    let formatter = DateFormatter()
    formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss ZZZ"
    let defaultTimeZoneStr = formatter.string(from: date)
    
    formatter.timeZone = NSTimeZone(abbreviation: "UTC") as TimeZone?
    let utcTimeZoneStr = formatter.string(from: date)
    //    let isoformatter = ISO8601DateFormatter.init()
    //    let timeStr = isoformatter.string(from: date)
    //    let dateFromString = isoformatter.date(from: timeStr)
    
    
    print("DEFAULT: \(defaultTimeZoneStr)")
    print("UTC: \(utcTimeZoneStr)")
    //    print("ISO: \(timeStr)")
    //    print("DATE: \(String(describing: "Nov 2, 2016, 5:14 AM"))")
    return utcTimeZoneStr
}


func helperGetDateStrForLocal() -> String {
    let date = Date()
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
    formatter.timeZone = NSTimeZone(abbreviation: "UTC") as TimeZone?
    let utcTimeZoneStr = formatter.string(from: date) //UTC: 2021-07-13 19:32:04
    let dateComp = utcTimeZoneStr.components(separatedBy: " ")
    let localDateStr = dateComp[0] + "T" + dateComp[1] + ".000+0000"
    print("LOCAL: \(localDateStr)")//"2021-07-13T19:30:52.000+0000"
    return localDateStr
}

func helperGetFormattedLocalShootTime() -> (String, String, String) {
    let date = Date()
    
    let utcTimeZoneStr = helperGetFormattedTime()
    
    let formatter2 = DateFormatter()//"11 Nov 2020 & 02:33:21 pm",
    formatter2.amSymbol = "am"
    formatter2.pmSymbol = "pm"
    formatter2.dateFormat = "dd MMM yyyy '&' HH:mm:ss a"
    let timeZoneStr = formatter2.string(from: date)
    
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat =  "yyyy-MM-dd HH:mm:ss" //2020-12-28T11:03:11.000+0000
    dateFormatter.timeZone = NSTimeZone(abbreviation: "UTC") as TimeZone?
    dateFormatter.locale = Locale.init(identifier: "en_GB")
    let dateForDB = dateFormatter.string(from: date)
    
    var newStr = String()
    if dateForDB.contains(" ") {
        let components = dateForDB.components(separatedBy: " ")
        let date = components[0]
        let time = components[1]
        
        newStr = date + "T" + time + ".000+0000"
    }
    return (utcTimeZoneStr,timeZoneStr, newStr)
}

func helperGetDateString(date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss ZZZ"
    let defaultTimeZoneStr = formatter.string(from: date)
    return defaultTimeZoneStr
}

func helperGetDateInWords(date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "dd MMM yyyy"
    let defaultTimeZoneStr = formatter.string(from: date)
    return defaultTimeZoneStr
}

//func 

func helperChangeDateFormatTo(dateString: String)->String?{
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat =  "yyyy-MM-dd"
    if let date = dateFormatter.date(from: dateString){
        if Calendar.current.isDateInToday(date){
            return "Today"
        }else if Calendar.current.isDateInYesterday(date){
            return "Yesterday"
        }
        dateFormatter.dateFormat = "MMM dd, yyyy"
        return dateFormatter.string(from: date)
    }else{
        return nil
    }
}

func helperIsDateToday(serverTime: String)->Bool? {
    if serverTime.contains("T"){
        let shootDate = serverTime.components(separatedBy: "T").first!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat =  "yyyy-MM-dd"
        if let date = dateFormatter.date(from: shootDate){
            if Calendar.current.isDateInToday(date){
                return true
            }
        }
    }
    return nil
}

func helperIsDateYesterday(serverTime: String)->Bool? {
    if serverTime.contains("T"){
        let shootDate = serverTime.components(separatedBy: "T").first!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat =  "yyyy-MM-dd"
        if let date = dateFormatter.date(from: shootDate){
            if Calendar.current.isDateInYesterday(date){
                return true
            }
        }
    }
    return nil
}

func helperIsDate(serverTime: String, in range: Int)->Bool? {
    if serverTime.contains("T"){
        let shootDate = serverTime.components(separatedBy: "T").first!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat =  "yyyy-MM-dd"
        if let date = dateFormatter.date(from: shootDate){
            let difference = Calendar.current.dateComponents([.day], from: date, to: Date())
            if difference.day ?? 0 < range {
                return true
            }
        }
    }
     return nil
}

func helperGetDateFromServerString(dateString: String) -> String {
    var date = String()
    var time = String()
    
    if dateString.contains(".000"){
        let components = dateString.components(separatedBy: ".000")
        date = components[0]
        time = components[1]
    }
    let newDate = date + "" + time
    return newDate
}

func helperGetServerTimeInMillis(serverTime: String) -> Double {
    var timeInterval = Double()
    var timeStr = String()
    
    if serverTime.contains("T") && serverTime.contains(".") {
        let time1 = serverTime.components(separatedBy: "T")
        // time1[0] = 2020-11-25, time1[1] = 08:03:25.000+0000
        if !time1.isEmpty { //"2020-11-25T08:03:25.000+0000"
            let time2 = time1[1].components(separatedBy: ".")
            if !time2.isEmpty {
                timeStr = time1[0] + " " + time2[0]   //yyyy-MM-dd HH:mm:ss  OR  yyyy-MM-dd HH:mm
            }
        }
    }
    
    timeInterval = 0
    if !timeStr.isEmpty {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat =  "yyyy-MM-dd HH:mm:ss"
        dateFormatter.locale = Locale.init(identifier: "en_GB")
        let date = dateFormatter.date(from: timeStr)
        timeInterval = date?.timeIntervalSince1970 ?? 0
    }
    
    return timeInterval
}

func helperChangeDateFormat(dateString: String) -> String {
    let inputFormatter = DateFormatter()
    inputFormatter.dateFormat = "YYYY-MM-dd"
    if let showDate = inputFormatter.date(from: dateString){
        inputFormatter.dateFormat = "dd-MM-YYYY"
        let resultString = inputFormatter.string(from: showDate)
        return resultString}
    else{
            return ""
        }
}

func helperGetTrimmedString(str: String) -> String {
    let trimmedStr = str.trimmingCharacters(in: .whitespacesAndNewlines)
    return trimmedStr
}

func helperGetCurrentTimeStamp() -> String {
    let timestamp = Double(NSDate().timeIntervalSince1970 * 1000)
    return String(Int(floor(timestamp)))
}

func helperDismissKeyboard(view: UIView) {
    view.endEditing(true)
}

func helperAllPartsExists() -> Bool {
    return UserDefaults.standard.bool(forKey: kHasAllParts)
}

func helperGetOnlineStatus() -> Bool {
    return UserDefaults.standard.bool(forKey: kIsOnline)
}

func helperSetOnlineStatus(isOnline: Bool) {
    UserDefaults.standard.set(isOnline, forKey: kIsOnline)
}

func helperGetBatteryPercentage() -> String {
    UIDevice.current.isBatteryMonitoringEnabled = true
    let battery = Double(UIDevice.current.batteryLevel * 100)
    let battLevel = String(Int(floor(battery)))
    return battLevel
}

func helperGetLogFile() -> URL {
    let filePathURL = helperGetDocumentsDirectory().appendingPathComponent("logFile.txt")
        return filePathURL
}

func helperGetAWSBucketPath(withPartId: String, scanName: String) -> String {
    let companyUID = UserSession.shared.getUserData()?.companyUID ?? ""
    let accountUID = UserSession.shared.getUserData()?.accountUID ?? ""
    
    let filePath = "\(companyUID)/\(accountUID)/\(withPartId)/units/\(scanName)/photos/Auto1"
    return filePath
}

func helperGetAWSBucketPathForProfilePic(withPartId: String, scanName: String) -> String {
    let companyUID = UserSession.shared.getUserData()?.companyUID ?? ""
    let accountUID = UserSession.shared.getUserData()?.accountUID ?? ""
    
    let filePath = "\(companyUID)/\(accountUID)/\(withPartId)/units/\(scanName)/profilePic"
    return filePath
}

func helperGetAWSBucketPathForLogFile(withPartId: String, scanName: String) -> String {
    let companyUID = UserSession.shared.getUserData()?.companyUID ?? ""
    let accountUID = UserSession.shared.getUserData()?.accountUID ?? ""
    let filePath = "\(companyUID)/\(accountUID)/\(withPartId)/units/\(scanName)"
    return filePath
}

func helperGetAWSBucketPathForVideo(withPartId: String, scanName: String) -> String {
    let companyUID = UserSession.shared.getUserData()?.companyUID ?? ""
    let accountUID = UserSession.shared.getUserData()?.accountUID ?? ""
    
    let filePath = "\(companyUID)/\(accountUID)/\(withPartId)/units/\(scanName)/videos/Auto1"
    return filePath
}

func helperGetScanObjURL(withPartId: String, scanName: String, jobname: String) -> String {
    let companyUID = UserSession.shared.getUserData()?.companyUID ?? ""
    let accountUID = UserSession.shared.getUserData()?.accountUID ?? ""
    
    let filePath = "\(companyUID)/\(accountUID)/\(withPartId)/units/\(scanName)/output/\(jobname)/\(scanName)_\(jobname).obj"
    return filePath
}

func helperGetFormattedVideoTime(timeMin: Int, timeSec: Int) -> String {
    var timeStr = String()
    if timeMin < 10 && timeSec < 10 {
        timeStr = "0\(timeMin):0\(timeSec)"
    }else if timeMin < 10 {
        timeStr = "0\(timeMin):\(timeSec)"
    }else if timeSec < 10{
        timeStr = "\(timeMin):0\(timeSec)"
    } else {
        timeStr = "\(timeMin):\(timeSec)"
    }
    return timeStr
}

func logTime()->String{
    let date = Date()
    return "\(Calendar.current.component(.hour, from: date)):\(Calendar.current.component(.minute, from: date)):\(Calendar.current.component(.second, from: date))"
}

func helperGetFormattedShootTime(timeMin: Int, timeSec: Int) -> String {
    var timeStr = String()
    if timeMin < 10 && timeSec < 10 {
        timeStr = "\(timeMin) min \(timeSec) secs"
    }else if timeMin < 10 {
        timeStr = "\(timeMin) min \(timeSec) secs"
    }else if timeSec < 10{
        timeStr = "\(timeMin) min \(timeSec) secs"
    } else {
        timeStr = "\(timeMin):\(timeSec)"
    }
    return timeStr
}

extension String {
    func stringByAddingPercentEncodingForRFC3986() -> String {
        let unreserved = "-._~/?:"
        let allowed = NSMutableCharacterSet.alphanumeric()
        allowed.addCharacters(in: unreserved)
        return addingPercentEncoding(withAllowedCharacters: allowed as CharacterSet)!
    }
}
