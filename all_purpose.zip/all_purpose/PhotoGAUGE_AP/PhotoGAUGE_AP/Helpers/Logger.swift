//
//  Logger.swift
//  PhotoGauge
//
//  Created by apple on 04/08/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import FirebaseCrashlytics

enum LogEvent: String {
    case debug = "‼️ Debug: "
}

func print(_ object: Any) {
  #if DEBUG
      Swift.print(object)
  #endif
}

class Logger{
    static var dateFormat = "dd-MM-yyyy hh:mm:ss"
    static var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = dateFormat
        formatter.locale = Locale.current
        formatter.timeZone = TimeZone.current
        return formatter
    }
    
    private static var isLoggingEnabled: Bool {
        #if DEBUG
        return true
        #else
        return true // To be revisited (discuss with Narendar); this is true for adhoc build
        #endif
    }
        
    private class func sourceFileName(filePath: String) -> String {
       let components = filePath.components(separatedBy: "/")
       return components.isEmpty ? "" : components.last!
    }
    
    class func debug ( _ object: Any, type: String = "INFO", filename: String = #file, line: Int = #line, column: Int = #column, funcName: String = #function) {
        if isLoggingEnabled {
            var logStr = ""
            if String(describing: object) == "" {
                logStr = "\(Date().toString()) \(LogEvent.debug.rawValue)[\(type)] : [\(sourceFileName(filePath: filename))] : \(funcName)"
            } else {
                logStr = "\(Date().toString()) \(LogEvent.debug.rawValue)[\(type)] : [\(sourceFileName(filePath: filename))] : -> \(line) \(object)"
            }
            ///Following lines had line, column and func information
//            if String(describing: object) == "" {
//                logStr = "\(Date().toString()) \(LogEvent.debug.rawValue)[\(type)] : [\(sourceFileName(filePath: filename))] : \(line) \(column) \(funcName)"
//            } else {
//                logStr = "\(Date().toString()) \(LogEvent.debug.rawValue)[\(type)] : [\(sourceFileName(filePath: filename))] : \(line) \(column) \(funcName) -> \(object)"
//            }
            
//            if filename == "/Users/ellyn/Documents/dev/PhotoGauge/PhotoGauge/PhotoGauge/Model/Database/DatabaseWrapper.swift" {
//                print(logStr)
//            }
            writeTofile(logStr: logStr)
            Crashlytics.crashlytics().log(logStr)
        }
    }
    
    class func writeTofile(logStr: String){
        let fileURL = helperGetDocumentsDirectory().appendingPathComponent("logFile.txt")
        let logString = " \n \(logStr) ;"
        if let fileUpdater = try? FileHandle(forUpdating: fileURL) {
            fileUpdater.seekToEndOfFile()
            fileUpdater.write(logString.data(using: .utf8)!)
            fileUpdater.closeFile()
        }
    }
    
    class func checkIfFileExists(logStr: String) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let url = NSURL(fileURLWithPath: path)
        if let pathComponent = url.appendingPathComponent("logFile.txt") {
            let filePath = pathComponent.path
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: filePath) {
                print("FILE AVAILABLE")
                writeTofile(logStr: logStr)
            } else {
                print("FILE NOT AVAILABLE")
                writeFirstToFile(logStr: logStr)
                UserDefaults.standard.setValue(Date(), forKey: "logFileTime")
            }
        } else {
            print("FILE PATH NOT AVAILABLE")
        }
    }
    
    class func writeFirstToFile(logStr: String){
        let fileURL = helperGetDocumentsDirectory().appendingPathComponent("logFile.txt")
        do {
            try logStr.write(to: fileURL, atomically: true, encoding: String.Encoding.utf8)
        } catch {
            LogConfig.logD(message:"Error in log file", displayToThirdParty: true)
        }
    }
    
    class func readFromFile(){
        let fileURL = helperGetDocumentsDirectory().appendingPathComponent("logFile.txt")
        do {
            let text2 = try String(contentsOf: fileURL, encoding: .utf8)
            print("!!!!!THIS IS THE CONTENTS OF FILE!!!!!! \n \n \n \(text2)")
        }
        catch {
            print("Error in file \(error)")
        }
    }
}

extension Date {
   func toString() -> String {
      return Logger.dateFormatter.string(from: self as Date)
   }
}
