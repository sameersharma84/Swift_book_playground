//
//  DownloadHelper.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 13/05/22.
//

import Foundation

class DownloadHelper {
    static var sharedInstance : DownloadHelper = DownloadHelper()
    private init() {}
    
    
    func downloadVideo(strVideoUrl:String) {
        var bucketName = String()
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            bucketName = str_s3ProdBucketName
        } else {
            bucketName = str_s3BucketName
        }
        
        AWSS3Manager.shared.bucketName = "\(bucketName)"
        let filepath = strVideoUrl
        
        let preSignedURL = AWSS3Manager.shared.getPreSignedURL(s3DownloadKeyName: filepath)
        print("URL: \(preSignedURL)")
        
        if preSignedURL != "" {
            UserSession.shared.setVideoTipsDownloading(status: true)
            let downloadTask = URLSession.shared.downloadTask(with: URL(string: strVideoUrl)!) {
                urlOrNil, responseOrNil, errorOrNil in
                
                let filename = UserSession.shared.getMeasurementTypeForServerUse() + "_video.mp4"
                guard let fileURL = urlOrNil else {
                    UserSession.shared.setVideoTipsUrlByMeasurement(videoUrl: "")
                    return
                }

                //print("Download Task Complete",fileURL)
                do {
                    let documentsURL = try
                        FileManager.default.url(for: .documentDirectory,
                                                in: .userDomainMask,
                                                appropriateFor: nil,
                                                create: false)
                    let savedURL = documentsURL.appendingPathComponent(filename)
                    
                    
                    if FileManager.default.fileExists(atPath: savedURL.path) {
                        try! FileManager.default.removeItem(at: savedURL)
                    }
                    
                    try FileManager.default.moveItem(at: fileURL, to: savedURL)
                    
                    UserSession.shared.setVideoTipsUrlByMeasurement(videoUrl: filename)
                } catch {
                    
                    LogConfig.logD(message: "Video Tips file download error: \(error)", displayToThirdParty: true)
                    UserSession.shared.setVideoTipsUrlByMeasurement(videoUrl: "")
                }
                UserSession.shared.setVideoTipsDownloading(status: false)
//                DispatchQueue.main.async {
//                    self.stopAnimation()
//                    self.loadPlayer()
//                }
            }
            downloadTask.resume()
        }else{
            LogConfig.logD(message: "ERROR: Presigned URL empty For Video Tips", displayToThirdParty: true)
            UserSession.shared.setVideoTipsUrlByMeasurement(videoUrl: "")
        }
    }
    
    func download3DModelObjectFile(allDetails : [String : Any]) {
        var bucketName = String()
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            bucketName = str_s3ProdBucketName
        } else {
            bucketName = str_s3BucketName
        }
        
        AWSS3Manager.shared.bucketName = "\(bucketName)"
        let filepath = helperGetScanObjURL(withPartId: allDetails[kPartId] as! String, scanName: allDetails[kUnitName] as! String, jobname: allDetails[kJobName] as! String)
        let preSignedURL = AWSS3Manager.shared.getPreSignedURL(s3DownloadKeyName: filepath)
        print("URL: \(preSignedURL)")
        let fileDownloadKey = allDetails[kPartId] as! String;
        if preSignedURL != "" {
            UserSession.shared.set3DModelObjectFileDownloadingFor(key: fileDownloadKey, value: true)
            let downloadTask = URLSession.shared.downloadTask(with: URL(string: preSignedURL)!) {
                urlOrNil, responseOrNil, errorOrNil in
                // check for and handle errors:
                // * errorOrNil should be nil
                // * responseOrNil should be an HTTPURLResponse with statusCode in 200..<299
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd-MM-yyyy-HH-mm-ss"
                let date = dateFormatter.string(from: Date())
                let filename = "3D_Model" + "_" + date + ".obj"
                guard let fileURL = urlOrNil else {
                    UserSession.shared.set3DModelObjectFileDownloadingFor(key: fileDownloadKey, value: false)
                    DispatchQueue.main.async {
                        helperGetAppDeleate().showAlert(titleStr: "", msg: "3D Model download for \(allDetails[kPartName] as! String) failed!")
                    }
                    return
                }
                do {
                    let documentsURL = try
                        FileManager.default.url(for: .documentDirectory,
                                                in: .userDomainMask,
                                                appropriateFor: nil,
                                                create: false)
                    let savedURL = documentsURL.appendingPathComponent(filename)
                    try FileManager.default.moveItem(at: fileURL, to: savedURL)
                    UserSession.shared.set3DModelObjectFileDownloadingFor(key: fileDownloadKey, value: false)
                    DispatchQueue.main.async {
                        helperGetAppDeleate().showAlert(titleStr: "", msg: "3D Model download for \(allDetails[kPartName] as! String) successful!")
                    }
                } catch {
                    LogConfig.logD(message: "file download error: \(error)", displayToThirdParty: true)
                    UserSession.shared.set3DModelObjectFileDownloadingFor(key: fileDownloadKey, value: false)
                    DispatchQueue.main.async {
                        helperGetAppDeleate().showAlert(titleStr: "", msg: "3D Model download for \(allDetails[kPartName] as! String) failed!")
                    }
                }
                debugPrint("Video downloaded====")
                
            }
            downloadTask.resume()
        }else{
            LogConfig.logD(message: "ERROR: Presigned URL empty", displayToThirdParty: true)
        }
    }
}
