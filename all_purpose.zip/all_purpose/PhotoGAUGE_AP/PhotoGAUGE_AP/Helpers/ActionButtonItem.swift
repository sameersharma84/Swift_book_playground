// ActionButton.swift

import UIKit

public typealias ActionButtonItemAction = (ActionButtonItem) -> Void

open class ActionButtonItem: NSObject {
    
    /// The action the item should perform when tapped
    open var action: ActionButtonItemAction?
    
    /// Description of the item's action
    open var text: String {
        get {
            return self.label.text!
        }
        
        set {
            self.label.text = newValue
        }
    }
    /// View that will hold the item's button and label
    internal var view: UIView!
    
    /// Label that contain the item's *text*
    fileprivate var label: UILabel!
    
    /// Main button that will perform the defined action
    fileprivate var button: UIButton!
    
    /// Image used by the button
    fileprivate var image: UIImage!
    
    /// Size needed for the *view* property presente the item's content
    fileprivate let viewSize = CGSize(width: 260, height: 70)
    
    /// Button's size by default the button is 35x35
    fileprivate let buttonSize = CGSize(width: 70, height: 70)
    
    fileprivate var labelBackground: UIView!
    fileprivate let backgroundInset = CGSize(width: 10, height: 10)
    
    /**
        :param: title Title that will be presented when the item is active
        :param: image Item's image used by the it's button
    */
    public init(title optionalTitle: String?, image: UIImage?) {
        super.init()
        
        self.view = UIView(frame: CGRect(origin: CGPoint.zero, size: self.viewSize))
        self.view.alpha = 0
        self.view.isUserInteractionEnabled = true
        self.view.backgroundColor = UIColor.clear
        
        self.button = UIButton(type: .custom)
        self.button.frame = CGRect(origin: CGPoint(x: (self.viewSize.width - self.buttonSize.width) - 60, y:-20), size: buttonSize)
        self.button.layer.shadowOpacity = 1
        self.button.layer.shadowRadius = 2
        self.button.layer.shadowOffset = CGSize(width: 1, height: 1)
        self.button.layer.shadowColor = UIColor.gray.cgColor
        self.button.addTarget(self, action: #selector(ActionButtonItem.buttonPressed(_:)), for: .touchUpInside)

        if let unwrappedImage = image {
            self.button.setImage(unwrappedImage, for: UIControl.State())
        }
                
        if let text = optionalTitle , text.trimmingCharacters(in: CharacterSet.whitespaces).isEmpty == false {
            self.label = UILabel()
            self.label.font = UIFont(name: "SFProText-Regular", size: 14)
            self.label.textColor = #colorLiteral(red: 0.00800000038, green: 0.5329999924, blue: 0.7289999723, alpha: 1)
            self.label.textAlignment = .center
            self.label.text = text
            self.label.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(ActionButtonItem.labelTapped(_:))))
            self.label.frame = CGRect.init(x: 0, y: 0, width: 120, height: 20)
            
            self.labelBackground = UIView()
            self.labelBackground.frame = self.label.frame
            self.labelBackground.backgroundColor = #colorLiteral(red: 0.7764705882, green: 0.875, blue: 0.9219999909, alpha: 1)
            self.labelBackground.layer.cornerRadius = 3
            self.labelBackground.layer.shadowOpacity = 1.0
            self.labelBackground.layer.shadowOffset = CGSize(width: 0, height: 0)
            self.labelBackground.layer.shadowRadius = 6.0
            self.labelBackground.layer.shadowColor = UIColor.lightGray.cgColor
            
            // Adjust the label's background inset
            self.labelBackground.frame.size.width = self.label.frame.size.width + backgroundInset.width
            self.labelBackground.frame.size.height = self.label.frame.size.height + backgroundInset.height
            self.label.frame.origin.x = self.label.frame.origin.x + backgroundInset.width / 2
            self.label.frame.origin.y = self.label.frame.origin.y + backgroundInset.height / 2
            
            // Adjust label's background position
            self.labelBackground.frame.origin.x = CGFloat(120 - self.label.frame.size.width)
            self.labelBackground.center.y = self.view.center.y - 20
            self.labelBackground.addSubview(self.label)
            
            // Add Tap Gestures Recognizer
            let tap = UITapGestureRecognizer(target: self, action: #selector(ActionButtonItem.labelTapped(_:)))
            self.view.addGestureRecognizer(tap)
            
            self.view.addSubview(self.labelBackground)
        }
        
        self.view.addSubview(self.button)
    }
        
    //MARK: - Button Action Methods
    @objc func buttonPressed(_ sender: UIButton) {
        if let unwrappedAction = self.action {
            unwrappedAction(self)
        }
    }
    
    //MARK: - Gesture Recognizer Methods
    @objc func labelTapped(_ gesture: UIGestureRecognizer) {
        if let unwrappedAction = self.action {
            unwrappedAction(self)
        }
    }
}
