//
//  Validator.swift
//  PhotoGauge
//
//  Created by apple on 04/08/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation

func validateEmail(email: String) -> Bool {
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailPredicate.evaluate(with: email)
}

func validatePhone(mobileNumber: String) -> Bool {
    let phoneRegEx = "^[+][0-9]{6,14}"
    let phonePredicate = NSPredicate(format:"SELF MATCHES %@", phoneRegEx)
    return phonePredicate.evaluate(with: mobileNumber)
}


