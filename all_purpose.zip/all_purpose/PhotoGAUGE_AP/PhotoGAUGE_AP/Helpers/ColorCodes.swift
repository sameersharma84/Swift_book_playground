//
//  ColorCodes.swift
//  PhotoGauge
//
//  Created by apple on 04/08/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import UIKit

class Color{
    static let themeBlueColor = #colorLiteral(red: 0.007843137255, green: 0.5333333333, blue: 0.7294117647, alpha: 1)
    static let themeAquaColor = #colorLiteral(red: 0.1176470588, green: 0.7215686275, blue: 0.7529411765, alpha: 1)
    static let themeAliceBlueColor = #colorLiteral(red: 0.9411764706, green: 0.9647058824, blue: 0.9921568627, alpha: 1)
    static let themeLinenColor = #colorLiteral(red: 0.9568627451, green: 0.9254901961, blue: 0.8980392157, alpha: 1)
    static let themeRedColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
    static let themeGreenColor = #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 1)
    static let themeOrangeColor = #colorLiteral(red: 0.9411764706, green: 0.3960784314, blue: 0.137254902, alpha: 1)
    static let themeErrorColor =  #colorLiteral(red: 0.9411764706, green: 0.3960784314, blue: 0.137254902, alpha: 1)
    static let themeWhiteColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    static let themeGreyColor = #colorLiteral(red: 0.4352941176, green: 0.4745098039, blue: 0.5098039216, alpha: 1)
    static let themeSelectionBlueColor = #colorLiteral(red: 0.007843137255, green: 0.5333333333, blue: 0.7294117647, alpha: 1)
    static let themeSelectionGreyColor = #colorLiteral(red: 0.4274509804, green: 0.4745098039, blue: 0.5137254902, alpha: 0.2)
}

extension UIColor{
    convenience init(red: Int, green: Int, blue: Int){
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red)/255.0, green: CGFloat(green)/255.0, blue: CGFloat(blue)/255.0, alpha: 1.0)
    }
    
    struct PhotogaugeColors {
        struct LoginIcon {
            static let color = UIColor(red: 0/255, green: 168/255, blue: 226/255, alpha: 1)
        }
        
        struct CaptureButtonColor {
            static let captureBtnBgColor = UIColor(red: 10/255, green: 68/255, blue: 226/255, alpha: 1)
            static let captureBtnTextColor = Color.themeWhiteColor
        }
    }
}


