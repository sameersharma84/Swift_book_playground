//
//  UserSession.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 03/12/21.
//

import Foundation
import UIKit

class UserSession {
    private init() {}
    
    static var shared = UserSession()
//    ios_construct@photogauge.com
    
    func getUserData() -> LoginResponse? {
        if let data =  UserDefaults.standard.value(forKey: "userInfo") as? Data{
            let dataDecoded = try? PropertyListDecoder().decode(LoginResponse.self, from: data)
            return dataDecoded
        }else{
            return nil
        }
    }
    
    func setUserData(data: LoginResponse){
        LogConfig.logD(message:"#####****** USER DATA RESET: \(data) #####******", displayToThirdParty: true)
        UserDefaults.standard.setValue(try? PropertyListEncoder().encode(data), forKey: "userInfo")
    }
    
    func setFirstTimeUserLogin(){
        UserDefaults.standard.setValue(false, forKey: "firstTimeLoggedIn")
    }
    
    func removeFirstTimeUserLogin(){
        UserDefaults.standard.setValue(true, forKey: "firstTimeLoggedIn")
    }
    
    func getUserSelection()->String?{
        return  UserDefaults.standard.value(forKey: "shootTypeSelection") as? String
    }
    
    func set(userSelection: String){
        UserDefaults.standard.setValue(userSelection, forKey: "shootTypeSelection")
    }
    
    func removeUserSelection(){
        UserDefaults.standard.removeObject(forKey: "shootTypeSelection")
    }
    
    func removeDontShowMeAgain(){
        if (UserDefaults.standard.value(forKey: "dontShowTargetScreen") != nil){
            UserDefaults.standard.removeObject(forKey: "dontShowTargetScreen")
        }
    }
    
    func isFirstTime()->Bool?{
        if let isUserLoggedIFirstTime = UserDefaults.standard.value(forKey: "firstTimeLoggedIn"){
            return isUserLoggedIFirstTime as? Bool
        }else{
            return  true
        }
    }
    
    func isFirstLoadOfMyUploads()->Bool?{
        if let isFirstLoadMyUploads = UserDefaults.standard.value(forKey: "firstLoadMyUploads"){
            return isFirstLoadMyUploads as? Bool
        }else{
            return  true
        }
    }
    
    func removeFirstLoadOfMyUploadScreen(){
        UserDefaults.standard.setValue(nil, forKey: "firstLoadMyUploads")
    }
    
    func setFirstLoadOfMyUploadScreen(){
        UserDefaults.standard.setValue(false, forKey: "firstLoadMyUploads")
    }
    
    func setDontShowTargetScreen(isSet: Bool){
        UserDefaults.standard.set(isSet, forKey: "dontShowTargetScreen")
    }
    
    func setDontShowTargetCount(){
        let dontShowAgainCount = UserDefaults.standard.integer(forKey: "dontShowAgainCount")
        UserDefaults.standard.set(dontShowAgainCount + 1, forKey: "dontShowAgainCount")
    }
    
    func getDontShowMeAgain()-> Int?{
        return UserDefaults.standard.integer(forKey: "dontShowAgainCount")
    }
    
    func isDontShowTargetScreenSet()-> Bool{
        if let isSet = UserDefaults.standard.value(forKey: "dontShowTargetScreen") as? Bool{
            return isSet
        }else{
            return false
        }
    }
    
    func getDeviceUUID()->  String{
        if let uuid = UIDevice.current.identifierForVendor?.uuidString {
            return uuid
        }else{
            return ""
        }
    }
    
    func setUserTypeAsGuest(){
        UserDefaults.standard.set("guest", forKey: "userType")
    }
    
    func isUserTypeGuest()->  Bool{
        if let userType = UserDefaults.standard.value(forKey: "userType") as? String{
            return userType == "guest" ? true : false
        }
        return false
    }
    
    func setUserTypeAsNormal(){
        UserDefaults.standard.set("normal", forKey: "userType")
    }
    
    func setDontShowScanTipsScreen(isSet: Bool){
        UserDefaults.standard.set(isSet, forKey: "dontShowScanTipsScreen")
    }

    
    func isDontShowScreenTipsScreenSet()-> Bool{
        if let isSet = UserDefaults.standard.value(forKey: "dontShowScanTipsScreen") as? Bool{
            return isSet
        }else{
            return false
        }
    }
    
    func getMeasurementTypeForServerUse()->String{
        var measurementType = ""
        if let type = getUserSelection(){
            if type == str_3d_model {
                measurementType = str_3d_model
            }else{
                measurementType = str_measurements
            }
        }
        return measurementType
    }

    
    func getVideoTipsUrlByMeasurement()->String{
        if let videoUrl = UserDefaults.standard.value(forKey: "\(getMeasurementTypeForServerUse())_video") as? String{
            return videoUrl
        }else{
            return ""
        }
    }
    
    func setVideoTipsUrlByMeasurement(videoUrl:String){
        UserDefaults.standard.setValue(videoUrl, forKey: "\(getMeasurementTypeForServerUse())_video")
    }
    
    func isVideoTipsDownloading()->Bool{
        if let isVideoTipsDownloading = UserDefaults.standard.value(forKey: "isVideoTipsDownloading") as? Bool{
            return isVideoTipsDownloading
        }else{
            return false
        }
    }
    
    func setVideoTipsDownloading(status:Bool){
        UserDefaults.standard.setValue(status, forKey: "isVideoTipsDownloading")
    }
    
    func set3DModelObjectFileDownloadingFor(key:String,value:Bool){
        UserDefaults.standard.setValue(value, forKey: "3dmodel_object_\(key)")
        debugPrint("Key 3dmodel_object_\(key)",value)
    }
    
    func is3DModelObjectFileDownloading(allDetails : [String : Any])->Bool{
        let fileDownloadKey = allDetails[kPartId] as! String
        if let is3DModelObjectFileDownloading = UserDefaults.standard.value(forKey: "3dmodel_object_\(fileDownloadKey)") as? Bool{
            return is3DModelObjectFileDownloading
        }else{
            return false
        }
    }
    
    func resetDownloadingSession(){
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()
        dictionary.keys.forEach { key in
            if key.hasPrefix("3dmodel_object_"){
                defaults.removeObject(forKey: key)
            }
        }
        setVideoTipsDownloading(status: false)
    }
    
    func setGuestUserData(data: LoginResponse){
        UserDefaults.standard.setValue(try? PropertyListEncoder().encode(data), forKey: "guestUserInfo")
    }
    
    func getGuestUserData() -> LoginResponse? {
        if let data =  UserDefaults.standard.value(forKey: "guestUserInfo") as? Data{
            let dataDecoded = try? PropertyListDecoder().decode(LoginResponse.self, from: data)
            return dataDecoded
        }else{
            return nil
        }
    }
    
    func setPartsCountOfUser(partsCount:Int){
        UserDefaults.standard.setValue(partsCount, forKey: "userPartCount")
    }
    
    func getUserPartsCount() -> Int{
        if let partsCount = UserDefaults.standard.value(forKey: "userPartCount") as? Int{
            return partsCount
        }else{
            return 0
        }
    }
    
    func setAllPartsRequestRunning(status:Bool){
        UserDefaults.standard.setValue(status, forKey: "allPartsRequestRunning")
    }
    
    func getIsAllPartsRequestRunning() -> Bool{
        if let isAllPartsRequestRunning = UserDefaults.standard.value(forKey: "allPartsRequestRunning") as? Bool {
            return isAllPartsRequestRunning
        }else{
            return false
        }
    }
    
    func getUserLoginDetail() -> LoginRequest? {
        if let userLoginDetailData =  UserDefaults.standard.value(forKey: "userLoginDetail") as? Data{
            let dataDecoded = try? PropertyListDecoder().decode(LoginRequest.self, from: userLoginDetailData)
            return dataDecoded
        }else{
            return nil
        }
    }
    
    func setUserLoginDetail(data: LoginRequest){
        LogConfig.logD(message:"#####****** Set User Login Detail: \(data) #####******", displayToThirdParty: true)
        UserDefaults.standard.setValue(try? PropertyListEncoder().encode(data), forKey: "userLoginDetail")
    }
}
extension UserSession {
    var arrSavedVideos: [VideoInfoModel] {
        get {
            guard let data = UserDefaults.standard.data(forKey: "arrSavedVideos") else { return [] }
            return (try? PropertyListDecoder().decode([VideoInfoModel].self, from: data))!
        }
        set {
            UserDefaults.standard.set(try? PropertyListEncoder().encode(newValue), forKey: "arrSavedVideos")
        }
    }
    
    func saveAllVideoInfoByScanName(scanName:String,arrSavedVideo:[VideoInfoModel]){
        UserDefaults.standard.set(try? PropertyListEncoder().encode(arrSavedVideo), forKey: "video_info_\(scanName)")
    }
    
    func getAllVideoInfoByScanName(scanName:String) -> [VideoInfoModel]{
        guard let data = UserDefaults.standard.data(forKey: "video_info_\(scanName)") else { return [] }
        return (try? PropertyListDecoder().decode([VideoInfoModel].self, from: data))!
    }
}
