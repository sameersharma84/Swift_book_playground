//
//  AWSManager.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 15/12/21.
//

import Foundation
import UIKit
import AWSS3
import AVFoundation

protocol NetworkSpeedUpdater {
    func updateNetworkSpeed(speed: String)
}

protocol CopyUpdateDelegate : NSObject {
    func percentageUpdated(progress: Float)
    func showNoNetworkError()
}
typealias progressBlock = (_ progress: Double) -> Void
typealias completionBlock = (_ response: Any?, _ error: Error?) -> Void

class AWSS3Manager {
    
    static let shared = AWSS3Manager()
    private init () { }
    var bucketName = String()
    var copyUpdateDelegate: CopyUpdateDelegate?
    var copyUpdateToHelperDelegate: CopyUpdateToUploadHelperDelegate?
    var delegateVar: NetworkSpeedUpdater?
    
    var startTime: CFAbsoluteTime = CFAbsoluteTimeGetCurrent()
    
    func uploadImage(fileName: String, image: UIImage, progress: progressBlock?, completion: completionBlock?) {
        Logger.debug("")
        guard let imageData = image.pngData() else {
            Logger.debug("invalid image")
            let error = NSError(domain:"", code:402, userInfo:[NSLocalizedDescriptionKey: "invalid image"])
            completion?(nil, error)
            return
        }
        
        let imageSize = imageData.count
        let tmpPath = NSTemporaryDirectory() as String
        let filePath = tmpPath + fileName
        let fileUrl = URL(fileURLWithPath: filePath)
        
        do {
            try imageData.write(to: fileUrl)
            self.startTime = CFAbsoluteTimeGetCurrent()
            self.uploadfile(fileSize: imageSize, fileUrl: fileUrl, fileName: fileName, contenType: "image", progress: progress, completion: completion)
            Logger.debug("Photo file exists at path")
        } catch {
            Logger.debug("invalid image - imageData.write to \(fileUrl)")
            let error = NSError(domain:"", code:402, userInfo:[NSLocalizedDescriptionKey: "invalid image"])
            completion?(nil, error)
        }
    }
    
    // Upload video from local path url
    func uploadVideo(fileSize: Int, videoUrl: URL, filename: String, progress: progressBlock?, completion: completionBlock?) {
        Logger.debug("")
        if FileManager.default.fileExists(atPath: videoUrl.path) {
            do {
                self.uploadfile(fileSize: fileSize, fileUrl: videoUrl, fileName: filename, contenType: "video", progress: progress, completion: completion)
                Logger.debug("Video File exists at path")
            }catch {
                Logger.debug("Could not find file at url: \(videoUrl)")
            }
        }
    }
    
    func uploadVideoW(videoAsset: AVAsset, progress: progressBlock?, completion: completionBlock?) {
        
    }
    
    // Upload files like Text, Zip, etc from local path url
    func uploadOtherFile(fileUrl: URL, conentType: String, progress: progressBlock?, completion: completionBlock?) {
        Logger.debug("")
        var fileName = ""
        if conentType == "Text" {
            var tempURL = fileUrl
            tempURL.deleteLastPathComponent()
            fileName = tempURL.lastPathComponent + ".txt"
        } else {
            fileName = self.getUniqueFileName(fileUrl: fileUrl)
        }
        self.uploadfile(fileSize: 0, fileUrl: fileUrl, fileName: fileName, contenType: conentType, progress: progress, completion: completion)
    }
    
    // Get unique file name
    func getUniqueFileName(fileUrl: URL) -> String {
        Logger.debug("")
        let strExt: String = "." + (URL(fileURLWithPath: fileUrl.absoluteString).pathExtension)
        return (ProcessInfo.processInfo.globallyUniqueString + (strExt))
    }
    
    func checkIfFileExist(fileName: String, completion: @escaping (Bool) -> Void) {
        Logger.debug("")
        let s3 = AWSS3.default()
        let headObjectsRequest: AWSS3HeadObjectRequest = AWSS3HeadObjectRequest()
        headObjectsRequest.bucket = self.bucketName
        headObjectsRequest.key = fileName
        
        DispatchQueue.main.async {
            s3.headObject(headObjectsRequest).continueWith { (task) -> Bool? in

                if let error = task.error {
                    Logger.debug("Error finding file: \(error)")
                    completion(false)
                    return false
                } else {
                    Logger.debug("File Exists")
                    completion(true)
                    return true
                }
            }
        }
    }
    
    func copyFiles(destBucketName: String, srcBucketName: String, unitFiles: [[String : Any]], partId: String, isVideo: Bool) {
        Logger.debug("")
        
        let s3 = AWSS3.default()
        let replicateRequest = AWSS3ReplicateObjectRequest.init()
        
        var destPath = String()
        if isVideo {
            destPath = helperGetAWSBucketPathForVideo(withPartId: partId, scanName: destBucketName)
        }else{
            destPath = helperGetAWSBucketPath(withPartId: partId, scanName: destBucketName)
        }
        
        var bucketName = String()
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            bucketName = str_s3ProdBucketName
        } else {
            bucketName = str_s3BucketName
        }
        
        let destinationBucket = bucketName
        var sourcePath = String()
        if isVideo {
            sourcePath = helperGetAWSBucketPathForVideo(withPartId: partId, scanName: srcBucketName)
        }else{
            sourcePath = helperGetAWSBucketPath(withPartId: partId, scanName: srcBucketName)
        }
        let sourceBucket = bucketName
        var count = 0
        for unit in unitFiles {
            replicateRequest?.bucket = destinationBucket
            replicateRequest?.key = "\(destPath)/\(unit[kFileName] as! String)"
            replicateRequest?.replicateSource = "\(sourceBucket)/\(sourcePath)/\(unit[kFileName] as! String)"
            replicateRequest?.acl = .publicReadWrite
            
            
            s3.replicateObject(replicateRequest!) { (response, error) in
                if error == nil {
                    count += 1
                    Logger.debug("***************** Replication success *****************")
                    let progress = Float(count * 100/unitFiles.count)
                    DispatchQueue.main.async {
                        self.copyUpdateDelegate?.percentageUpdated(progress: progress)
                        self.copyUpdateToHelperDelegate?.percentageCopyUpdated(progress: progress)
                    }
                }else{
                    Logger.debug("***************** Replication Error: \(error?.localizedDescription as Any) *****************")
                    if error?.localizedDescription == "The Internet connection appears to be offline." {
                        self.copyUpdateDelegate?.showNoNetworkError()
                    }
                }
            }
            
        }
    }
    
    //MARK:- AWS file upload
    // fileUrl :  file local path url
    // fileName : name of file, like "myimage.jpeg" "video.mov"
    // contenType: file MIME type
    // progress: file upload progress, value from 0 to 1, 1 for 100% complete
    // completion: completion block when uplaoding is finish, you will get S3 url of upload file here
    private func uploadfile(fileSize: Int, fileUrl: URL, fileName: String, contenType: String, progress: progressBlock?, completion: completionBlock?) {
        Logger.debug("Upload File method called")
        // Upload progress block
        Logger.debug("Total Bytes: " + String(fileSize))
        var previousUploadedBytes: Double = 0.0
        let expression = AWSS3TransferUtilityUploadExpression()
        expression.progressBlock = {(task, awsProgress) in
            if task.status == AWSS3TransferUtilityTransferStatusType.waiting {
                UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                task.cancel()
            }
            guard let uploadProgress = progress else { return }
            DispatchQueue.main.async {
                uploadProgress(awsProgress.fractionCompleted)
                
                let stopTime = CFAbsoluteTimeGetCurrent()
                let elapsed = stopTime - self.startTime
                self.startTime = CFAbsoluteTimeGetCurrent()
                
                let totalBytesUploaded = (awsProgress.fractionCompleted * Double(fileSize))
                let bytesUploaded = totalBytesUploaded - previousUploadedBytes
                previousUploadedBytes = totalBytesUploaded
            
                let speed = elapsed != 0 ? Double(bytesUploaded) / elapsed : -1
                self.delegateVar?.updateNetworkSpeed(speed: (Units(bytes: Int64(speed))).getReadableUnit())
//                Logger.debug("Bytes Uploaded: " + String(bytesUploaded))
                Logger.debug("Network Speed: " + (Units(bytes: Int64(speed))).getReadableUnit())
                UserDefaults.standard.setValue(false, forKey: "showRedSnackBar")
            }
        }
        
        // Completion block
        var completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
        completionHandler = { (task, error) -> Void in
            DispatchQueue.main.async(execute: {
                if error == nil {
                    let url = AWSS3.default().configuration.endpoint.url
                    let publicURL : URL = (url?.appendingPathComponent(self.bucketName).appendingPathComponent(fileName))!
                    Logger.debug("AWS S3 manager Uploaded to:  \(publicURL.absoluteString)")
                    if let completionBlock = completion {
                        UserDefaults.standard.setValue(false, forKey: "showRedSnackBar")
                        completionBlock(publicURL.absoluteString, nil)
                    }
                } else {
                    if let completionBlock = completion {
                        UserDefaults.standard.setValue(true, forKey: "showRedSnackBar")
                        completionBlock(nil, error)
                        Logger.debug("Error while uploading to S3 \(String(describing: error))", type: "ERROR")
                    }
                }
//                changed
//                helperGetAppDeleate().partScreen.handleScreenSpecificRedSnackBarChange()
            })
        }
        
        // Start uploading using AWSS3TransferUtility
        let awsTransferUtility = AWSS3TransferUtility.default()
        awsTransferUtility.uploadFile(fileUrl, bucket: bucketName, key: fileName, contentType: contenType, expression: expression, completionHandler: completionHandler).continueWith { (task) -> Any? in
            if let error = task.error {
                UploadHelper.sharedInstance.showSSLError = false
                if (error as NSError).code == -1001 {
                    DispatchQueue.main.async {
                        UploadHelper.sharedInstance.noOfRetries = 0
                        UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                    }
                } else if (error as NSError).code == -1009 {
                    DispatchQueue.main.async {
                        UploadHelper.sharedInstance.noOfRetries = 0
                        UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                    }
                } else if (error as NSError).code == -1003 {
                    DispatchQueue.main.async {
                        UploadHelper.sharedInstance.noOfRetries = 0
                        UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                    }
                } else if (error as NSError).code == -1200 {
                    DispatchQueue.main.async {
                        UploadHelper.sharedInstance.noOfRetries = 0
                        UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                        UploadHelper.sharedInstance.showSSLError = true
                    }
                }
                Logger.debug("Error while uploading to S3 \(String(describing: error))", type: "ERROR")
            }
            if let _ = task.result {
                // your uploadTask
                Logger.debug("Upload Task ID = " + String(task.result?.taskIdentifier ?? 0))
            }
            return nil
        }
        
    }
    
    func cancelUploads(callback: (() -> ())) {

        Logger.debug("Cancel Uploads Called")
        let uploadTasks = AWSS3TransferUtility.default().getUploadTasks()
        if (uploadTasks.result != nil) {
            for uploadTask in uploadTasks.result! {
                if ((uploadTask as? AWSS3TransferUtilityUploadTask) != nil) {
                    let task: AWSS3TransferUtilityUploadTask = uploadTask as! AWSS3TransferUtilityUploadTask
                    task.cancel()
                    if task.status == AWSS3TransferUtilityTransferStatusType.cancelled {
                        Logger.debug("Upload Cancelled")
                    }
                }
            }
        }
        callback()
    }
    
    func resumeUploads(callback: (() -> ())) {
        Logger.debug("Resume Uploads Called")
        let uploadTasks = AWSS3TransferUtility.default().getUploadTasks()
        if (uploadTasks.result != nil) {
            for uploadTask in uploadTasks.result! {
                if ((uploadTask as? AWSS3TransferUtilityUploadTask) != nil) {
                    let task: AWSS3TransferUtilityUploadTask = uploadTask as! AWSS3TransferUtilityUploadTask
                    task.resume()
                    if task.status == AWSS3TransferUtilityTransferStatusType.inProgress {
                        Logger.debug("Upload Resumed")
                    }
                }
            }
        }
        callback()

    }
    
    func pauseUploads(callback: (() -> ())) {
        
        Logger.debug("Pause Uploads Called")
        let uploadTasks = AWSS3TransferUtility.default().getUploadTasks()
        if (uploadTasks.result != nil) {
            for uploadTask in uploadTasks.result! {
                if ((uploadTask as? AWSS3TransferUtilityUploadTask) != nil) {
                    let task: AWSS3TransferUtilityUploadTask = uploadTask as! AWSS3TransferUtilityUploadTask
                    task.cancel()
                    if task.status == AWSS3TransferUtilityTransferStatusType.paused {
                        Logger.debug("Upload Paused")
                    }
                }
            }
        }
        callback()
    }
}

public struct Units {
  
  public let bytes: Int64
  
  public var kilobytes: Double {
    return Double(bytes) / 1_024
  }
  
  public var megabytes: Double {
    return kilobytes / 1_024
  }
  
  public var gigabytes: Double {
    return megabytes / 1_024
  }
  
  public init(bytes: Int64) {
    self.bytes = bytes
  }
  
  public func getReadableUnit() -> String {
    
    switch bytes {
    case 0..<1_024:
      return "\(bytes) bytes"
    case 1_024..<(1_024 * 1_024):
      return "\(String(format: "%.2f", kilobytes)) KB/s"
    case 1_024..<(1_024 * 1_024 * 1_024):
      return "\(String(format: "%.2f", megabytes)) MB/s"
    case (1_024 * 1_024 * 1_024)...Int64.max:
      return "\(String(format: "%.2f", gigabytes)) MB/s"
    default:
        if bytes < 0 {
            return "0 bytes"
        }
      return "\(bytes) bytes"
    }
  }
}

