//
//  UIKitExt.swift
//  PhotoGauge
//
//  Created by User on 8/8/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import UIKit

//MARK:- UIButton Extension
extension UIButton {
    func setSelectedColor(){
        self.backgroundColor = #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1)
    }
    
    func setDeSelectedColor(){
        self.backgroundColor = #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
    }
    
    func setNewCornerRadius(){
        self.layer.cornerRadius = 5.0
        self.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        self.layer.borderWidth = 1.0
    }
}

//MARK:- UIView Extension
extension UIView {
    func setBgColor(){
        self.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    }
    
    func setViewCornerRadius(){
        self.layer.cornerRadius = 5.0
        self.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        self.layer.borderWidth = 1.0
    }
}
