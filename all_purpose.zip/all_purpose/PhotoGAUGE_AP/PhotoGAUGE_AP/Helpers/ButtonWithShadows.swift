//
//  ButtonWithShadows.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 10/01/22.
//

import UIKit

class ButtonWithShadow: UIButton {
    var shadowLayer = CAShapeLayer()
    override func draw(_ rect: CGRect) {
        centerVertically()
//        updateLayerProperties()
    }
   
    func centerVertically(padding: CGFloat = 10.0) {
            guard
                let imageViewSize = self.imageView?.frame.size,
                let titleLabelSize = self.titleLabel?.frame.size else {
                return
            }
            
            let totalHeight = imageViewSize.height + titleLabelSize.height + padding
            
            self.imageEdgeInsets = UIEdgeInsets(
                top: -(totalHeight - imageViewSize.height-25),
                left: 0.0,
                bottom: 0.0,
                right: -titleLabelSize.width
            )
            
            self.titleEdgeInsets = UIEdgeInsets(
                top: 0.0,
                left: -imageViewSize.width,
                bottom: -(totalHeight - titleLabelSize.height+23),
                right: 0.0
            )
            
            self.contentEdgeInsets = UIEdgeInsets(
                top: 0.0,
                left: 0.0,
                bottom: titleLabelSize.height,
                right: 0.0
            )
        }
        
    func updateLayerProperties(fillColor: UIColor = .clear) {
        // on dong this the background color of the layer is not updating
//        shadowLayer.path = UIBezierPath(roundedRect: bounds, cornerRadius: 6).cgPath
//        shadowLayer.fillColor = self.backgroundColor?.cgColor
//        shadowLayer.backgroundColor = UIColor.clear.cgColor
//        shadowLayer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.3).cgColor
//        shadowLayer.shadowPath = shadowLayer.path
//        shadowLayer.shadowOffset = CGSize(width: 0, height: 2.0)
//        shadowLayer.shadowOpacity = 0.8
//        shadowLayer.shadowRadius = 2
//        layer.insertSublayer(shadowLayer, at: 0)
        
        
        self.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.3).cgColor
        self.layer.shadowPath =  UIBezierPath(roundedRect: bounds, cornerRadius: 6).cgPath
        self.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.layer.shadowOpacity = 0.8
        self.layer.shadowRadius = 3.0
        self.layer.masksToBounds = false
    }
    
}


