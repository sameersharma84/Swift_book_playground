//
//  CustomButton.swift
//  PhotoGauge
//
//  Created by User on 8/8/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import UIKit

class CustomButton: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpButton()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpButton()
    }
    
    func setUpButton(){
        setBtnColors()
        setCornerRadiusForBtn()
    }
    
    private func setCornerRadiusForBtn(){
        self.layer.cornerRadius = 5.0
        self.layer.borderWidth = 1.0
        self.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
    }
    
    private func setBtnColors(){
        self.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
    }
}
