//
//  UIImageLoader.swift
//  Demo App
//
//  Created by Swathi on 10/05/21.
//

import Foundation
import UIKit

class UIImageLoader {
    static let loader = UIImageLoader()

    private let imageLoader = ImageLoader()
    private var uuidMap = [UIImageView: UUID]()

    private init() {}

    func load(_ photoKey: String, for imageView: UIImageView, completion: @escaping (Bool) -> Void) {
        let token = imageLoader.loadImage(photoKey) { result in
        
            defer { self.uuidMap.removeValue(forKey: imageView) }
            do {
            
                let image = try result.get()
                DispatchQueue.main.async {
                    imageView.image = image
                    completion(true)
                }
            } catch {
              // handle the error
            }
        }
        
        if let token = token {
            uuidMap[imageView] = token
        }
    }

    func cancel(for imageView: UIImageView) {
        if let uuid = uuidMap[imageView] {
            imageLoader.cancelLoad(uuid)
            uuidMap.removeValue(forKey: imageView)
        }
    }
}

