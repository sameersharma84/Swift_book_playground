//
//  Helper.swift
//  Demo App
//
//  Created by Swathi on 10/05/21.
//

import Foundation
import UIKit
import AWSS3
import AWSCore

class ImageLoader {
    private var loadedImages = [String: UIImage]()
    private var runningRequests = [UUID: AWSTask<AWSS3TransferUtilityDownloadTask>]()
    var s3Bucket = String()
    
    func loadImage(_ photoKey: String, _ completion: @escaping (Result<UIImage, Error>) -> Void) -> UUID? {

        if let image = loadedImages[photoKey] {
            completion(.success(image))
            return nil
        }

        let uuid = UUID()
        let transferUtil = AWSS3TransferUtility.default()
        let expression = AWSS3TransferUtilityDownloadExpression()
        expression.progressBlock = { (task, progress) in DispatchQueue.main.async(execute: {
            _ = Float(progress.fractionCompleted)
            //Logger.debugt("Progess: \(progress)")
        })
        }
        
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            s3Bucket = str_s3ProdBucketName
        } else {
            s3Bucket = str_s3BucketName
        }

        let task = transferUtil.downloadData(fromBucket: s3Bucket, key: photoKey, expression: expression, completionHandler: { (task, url, data, error) in
            defer {self.runningRequests.removeValue(forKey: uuid) }
            
            if let data = data, let image = UIImage(data: data) {
                self.loadedImages[photoKey] = image
                completion(.success(image))
                return
            }
            
            guard let error = error else {
                return
            }
            
            guard (error as NSError).code == NSURLErrorCancelled else {
                completion(.failure(error))
                return
            }
        })
            
        runningRequests[uuid] = task
        return uuid
    }
    
    func cancelLoad(_ uuid: UUID) {
        if (runningRequests[uuid] != nil) {
            let task = runningRequests[uuid]!
            let downloadTask = task.result
            downloadTask?.cancel()
            runningRequests.removeValue(forKey: uuid)
        }
    }
}
