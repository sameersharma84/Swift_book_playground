//
//  UploadHelper.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 02/12/21.
//

import Foundation
import AWSCore
import AWSCognito
import AWSS3
import Alamofire
//typealias progressBlock = (_ progress: Double) -> Void //2
//typealias completionBlock = (_ response: Any?, _ error: Error?) -> Void //3
//
//class UploadHelper {
//    static let shared = UploadHelper()
//    weak var uploadUpdateDelegate: UploadUpdateDelegate?
//    private init () { }
//    var bucketName:String{
////        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
////            return str_s3ProdBucketName
////        } else {
//            return str_s3BucketName
////        }
//    }
//
//
//    // Upload video from local path url
//    func uploadVideo(videoUrl: URL,fileName: String, progress: progressBlock?, completion: completionBlock?) {
////        let fileName = self.getUniqueFileName(fileUrl: videoUrl)
//        self.uploadfile(fileUrl: videoUrl, fileName: fileName, contenType: "video", progress: progress, completion: completion)
//    }
//
//    // Upload files like Text, Zip, etc from local path url
//    func uploadOtherFile(fileUrl: URL, conentType: String, progress: progressBlock?, completion: completionBlock?) {
//        let fileName = self.getUniqueFileName(fileUrl: fileUrl)
//        self.uploadfile(fileUrl: fileUrl, fileName: fileName, contenType: conentType, progress: progress, completion: completion)
//    }
//
//    // Get unique file name
//    func getUniqueFileName(fileUrl: URL) -> String {
//        let strExt: String = "." + (URL(fileURLWithPath: fileUrl.absoluteString).pathExtension)
//        return (ProcessInfo.processInfo.globallyUniqueString + (strExt))
//    }
//
//    //MARK:- AWS file upload
//    // fileUrl :  file local path url
//    // fileName : name of file, like "myimage.jpeg" "video.mov"
//    // contenType: file MIME type
//    // progress: file upload progress, value from 0 to 1, 1 for 100% complete
//    // completion: completion block when uplaoding is finish, you will get S3 url of upload file here
//    private func uploadfile(fileUrl: URL, fileName: String, contenType: String, progress: progressBlock?, completion: completionBlock?) {
//        // Upload progress block
//        let expression = AWSS3TransferUtilityUploadExpression()
//        expression.progressBlock = {(task, awsProgress) in
//            guard let uploadProgress = progress else { return }
//            DispatchQueue.main.async {
//                uploadProgress(awsProgress.fractionCompleted)
//                let progessInt = awsProgress.fractionCompleted
//                if Int(progessInt * 100).isMultiple(of: 25) {
//                    LogConfig.logD(message:"Upload Video progress - \(Float(progessInt))")
//                }
//                self.uploadUpdateDelegate?.percentageUpdated(uploadedImgCount: 1, totalImgCount: 1, progress: Float(progessInt), isVideo: true)
//            }
//        }
//
//        // Completion block
//        var completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
//        completionHandler = { (task, error) -> Void in
//            DispatchQueue.main.async(execute: {
//
//                if error == nil {
//                    let url = AWSS3.default().configuration.endpoint.url
//                    let publicURL = url?.appendingPathComponent(self.bucketName).appendingPathComponent(fileName)
//                    print("Uploaded to:\(String(describing: publicURL))")
//                    if let completionBlock = completion {
//                        completionBlock(publicURL?.absoluteString, nil)
//                    }
//                } else {
//                    //error after the upload task has been created and is in progress
//                    if let completionBlock = completion {
//                        completionBlock(nil, error)
//                    }
//                }
//            })
//        }
//
//        // Start uploading using AWSS3TransferUtility
//        let awsTransferUtility = AWSS3TransferUtility.default()
//        awsTransferUtility.uploadFile(fileUrl, bucket: bucketName, key: fileName, contentType: contenType, expression: expression, completionHandler: completionHandler).continueWith { (task) -> Any? in
//            // reports errors in task creation
//            if let error = task.error {
//                print("error is: \(error.localizedDescription)")
//            }
//            if let _ = task.result {
//                // your uploadTask
//            }
//            return nil
//        }
//    }
//}



protocol CopyUpdateToUploadHelperDelegate {
    func percentageCopyUpdated(progress: Float)
}

protocol UploadStatusScreenProtocol {
    func notifyStatusChange()
}

protocol UploadUpdateDelegate : NSObject {
    func percentageUpdated(uploadedImgCount: Int, totalImgCount: Int, progress: Float, isVideo: Bool)
    func textInfoUpdated(projectName: String, windowName: String, uploadCount: Int, totalUploadsCount: Int, progress: Float, location: String, isVideo: Bool,partDesc:String)
    func uploadStartTimeUpdated(time: String, isVideo: Bool)
    func uploadSuccessUIUpdate(nwSpeedValue: String, uploadTimeValue: String, isVideo: Bool)
    func updateNetworkSpeed(speed: String)
    func uploadFailed(for unitName: String, isInternetAvailable: Bool)
}

enum UPLOADSTATUS : String {
    case UPLOAD_FILES_FAIL = "0"
    case UPLOAD_FILES_SUCCESS = "1"
    case MERGE_PART_API_CALL_DONE = "2"
    case ADD_INSPECTION_JOB_DONE = "3"
}

enum UPLOADRUNNINGSTATUS : String {
    case UPLOAD_RUNNING_STATUS_UPLOADED = "UPLOADED"
    case UPLOAD_RUNNING_STATUS_NONE = "NONE"
    case UPLOAD_RUNNING_STATUS_PAUSE = "PAUSE"
    case UPLOAD_RUNNING_STATUS_CANCELED = "CANCELED"
}

class UploadHelper {
    static var sharedInstance : UploadHelper = UploadHelper()
    
    var uploadTimeStr : String!
    //var imagesUploadedCount: Int = 0
    var imagesToUploadCount : Int!
    var totalImagesToUploadCount: Int = 0
    var timer = Timer()
    var startTime: Double = 0
    var time: Double = 0
    
    //timer for progressBlock
    var progressTimer = Timer()
    var previousProgressTime: Double = Date().timeIntervalSinceReferenceDate
    var fallbackFlagCount = 0
    var scanToUpload : String!
    var imagesToUpload = [UIImage]()
    var uploadingImagesId = [String]()
    var filePath = String()
    var profileFilePath = String()
    var logFilePath = String()
    var imagesInfo = [String : Any]()
    var timeStamps = [String]()
    var scanInfo = [String : Any]()
    var scanToUploadNext = [String : Any]()
    weak var uploadUpdateDelegate: UploadUpdateDelegate?
    weak var allScanScreen : AllUploadsViewController?
    //    weak var partsScreen : Parts?
    //    weak var addNewPartScreen : AddNewPartScreen?
    weak var uploadScreen : UploadViewController?
    var uploadStatusDelegate: UploadStatusScreenProtocol?
    var scanType = str_new_scan
    var reScanUnitName = String()
    var parentIdForReScan = String()
    var scanToUpdateInfo = [String : Any]()
    var isVideoUpload = Bool()
    var videoAssetURL: URL!
    var pushCopyScreen: Bool = false
    var videoFileName = String()
    var noOfRetries: Int = 0
    var showSSLError: Bool = false
    var addInspectionJobTask: Bool = false
    var etagCalledForMergePart: Bool = false
    var etagCalledForInspectionJob: Bool = false
    var uploadingDummyPart: Bool = false
    
    @objc func advanceTimer(timer: Timer) {
        time = Date().timeIntervalSinceReferenceDate - startTime
        LogConfig.logD(message:"////// Timer Running for \(time) /////", displayToThirdParty: true)
        uploadTimeStr = String(Int(floor(time)))
    }
    
    @objc func progressTimer(timer: Timer) {
        let timeDifference = Date().timeIntervalSinceReferenceDate - previousProgressTime
        LogConfig.logD(message:"//////Progress Timer Running for \(timeDifference) /////", displayToThirdParty: true)
        print("//////Progress Timer Running for \(timeDifference) /////")
    }
    
    func uploadVideo(localURL: URL, fileName: String) {
        LogConfig.logD(message:"POINT B - upload video", displayToThirdParty: true)
        //this code is to make sure if ever multiple uploads are triggered, it does not upload same video twice
        if videoFileName == fileName {
            LogConfig.logD(message:"same file name so upload returned", displayToThirdParty: true)
            return
        }else{
            
            if self.scanToUploadNext[kMergePartDone] as? Bool ?? false {
                LogConfig.logD(message:"Merge Part API is done. Call Add inpection job API", displayToThirdParty: true)
                invalidateTimers()
                self.createAddInspectionDict()
                return
            } else {
                if !FileManager.default.fileExists(atPath: localURL.path) {
                    helperGetAppDeleate().dbWrapper.updateLocalScan(scanData: self.scanInfo , uploadStatus: UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue, uploadStatusStr: str_uploading, callback: {
                        invalidateTimers()
                        self.updateSuccessOnApiCall()
                        UploadHelper.sharedInstance.callMergePart()
                    })
                    return
                }
            }
            
            if AWSS3Manager.shared.isAWSUploading() {
                return
            }
            
            LogConfig.logD(message:"New file name so upload continue", displayToThirdParty: true)
            videoFileName = fileName
            UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = true
            var videoDataSize : Int = 0
        #if ARKIT
            let arrSavedVideos = UserSession.shared.getAllVideoInfoByScanName(scanName: UploadHelper.sharedInstance.scanToUpload)
            let videoInfo = arrSavedVideos[0]
            videoDataSize = Int(videoInfo.videoSize)
        #else
            videoDataSize = Int(self.scanInfo[kVideoSize] as! Int64)
        #endif
            
            let date = Date()
            let calendar = Calendar.current
            let hour = calendar.component(.hour, from: date)
            let minutes = calendar.component(.minute, from: date)
            let secs = calendar.component(.second, from: date)
            var strHour: String = "\(hour)"
            var strMin: String = "\(minutes)"
            var strSec: String = "\(secs)"
            if hour < 10 {
                strHour = "0\(hour)"
            }
            if minutes < 10 {
                strMin = "0\(minutes)"
            }
            if secs < 10 {
                strSec = "0\(secs)"
            }
            
            UploadHelper.sharedInstance.addInspectionJobTask = false
            
            UserDefaults.standard.setValue(false, forKey: "showRedSnackBar")
            //        helperGetAppDeleate().partScreen.handleScreenSpecificRedSnackBarChange()
            uploadUpdateDelegate?.uploadStartTimeUpdated(time: "\(strHour):\(strMin):\(strSec)", isVideo: isVideoUpload)
            UserDefaults.standard.setValue("Upload Started: \(strHour):\(strMin):\(strSec)", forKey: "uploadStartedTime")
            LogConfig.logD(message:"Upload Started at \(String(describing: UserDefaults.standard.string(forKey: "uploadStartedTime")))", displayToThirdParty: true)
            UploadHelper.sharedInstance.previousProgressTime = Date().timeIntervalSinceReferenceDate
            UploadHelper.sharedInstance.startTime = Date().timeIntervalSinceReferenceDate
            UploadHelper.sharedInstance.timer = Timer.scheduledTimer(timeInterval: 1,
                                                                     target: UploadHelper.sharedInstance,
                                                                     selector: #selector(UploadHelper.sharedInstance.advanceTimer(timer:)),
                                                                     userInfo: nil,
                                                                     repeats: true)
            
            UploadHelper.sharedInstance.progressTimer = Timer.scheduledTimer(timeInterval: 1,
                                                                             target: UploadHelper.sharedInstance,
                                                                             selector: #selector(UploadHelper.sharedInstance.progressTimer(timer:)),
                                                                             userInfo: nil,
                                                                             repeats: true)
            // This will update the progress bar status if some parts of video already uploaded
            // and we are trying to upload cancelled shoot
            onVideoUploadProgress(progress: 0.005)

            
            var bucketName = String()
            if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
                bucketName = str_s3ProdBucketName
            } else {
                bucketName = str_s3BucketName
            }
            var partInfo = [String : Any]()
            partInfo = scanInfo[kPartDetails] as! [String : Any]
            let partname = partInfo[kPartName] as! String
            let scanName = self.scanInfo["scanName"] as! String
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
            LogConfig.logD(message: "######## AWS upload starting for \(partname) for scan \(scanName) at \(logTime()) ########\n", displayToThirdParty: true)
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
            AWSS3Manager.shared.bucketName = "\(bucketName)"
            let newfileName = "\(self.filePath)/\(fileName)"
            AWSS3Manager.shared.delegateVar = self
            LogConfig.logD(message:"Bucket Name - \(AWSS3Manager.shared.bucketName) \n FilePath: \(newfileName)", displayToThirdParty: true)
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
            AWSS3Manager.shared.uploadVideo(fileSize: videoDataSize, videoUrl: localURL, filename: newfileName, progress: { [weak self] (progress) in
                self?.onVideoUploadProgress(progress: progress)
            }) { [weak self] (uploadedFileUrl, error) in
                self?.invalidateTimers()
                self?.onVideoUploadCompletionViaAWS( fileName: fileName, uploadedFileUr: uploadedFileUrl,localURL: localURL, error: error, partname: partname)
            }
        }
    }
    
    func onVideoUploadProgress(progress: Double){
        
    #if ARKIT
        let arrSavedVideos = UserSession.shared.getAllVideoInfoByScanName(scanName: UploadHelper.sharedInstance.scanToUpload)
        var eachVideoPercentage = Double(1 / 4.0);
        let uploadedShoots = 4 - arrSavedVideos.count
        eachVideoPercentage =  eachVideoPercentage * Double(uploadedShoots) + (progress / Double(4))
        
        //debugPrint("Upload Video progress - \(Float(eachVideoPercentage))")
        
        self.previousProgressTime = Date().timeIntervalSinceReferenceDate
        LogConfig.logD(message:"Upload Video progress - \(Float(eachVideoPercentage))", displayToThirdParty: true)
        self.uploadUpdateDelegate?.percentageUpdated(uploadedImgCount: 1, totalImgCount: 1, progress: Float(eachVideoPercentage), isVideo: true)
        UserDefaults.standard.setValue("\(str_uploading) \(String(Int(Float(eachVideoPercentage) * 100)))%", forKey: "uploadStatusLblText")
        UserDefaults.standard.setValue(Float(eachVideoPercentage), forKey: "uploadProgress")
        UserDefaults.standard.setValue(Float(eachVideoPercentage), forKey: kVideoUploadingPercentage)
    #else
        self.previousProgressTime = Date().timeIntervalSinceReferenceDate
        LogConfig.logD(message:"Upload Video progress - \(Float(progress))", displayToThirdParty: true)
        self.uploadUpdateDelegate?.percentageUpdated(uploadedImgCount: 1, totalImgCount: 1, progress: Float(progress), isVideo: true)
        UserDefaults.standard.setValue("\(str_uploading) \(String(Int(Float(progress) * 100)))%", forKey: "uploadStatusLblText")
        UserDefaults.standard.setValue(Float(progress), forKey: "uploadProgress")
        UserDefaults.standard.setValue(Float(progress), forKey: kVideoUploadingPercentage)
    #endif
    }
    
    
    func onVideoUploadCompletionViaAWS(fileName: String, uploadedFileUr: Any?,localURL: URL, error: Error?, partname: String){
        var bucketName = String()
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            bucketName = str_s3ProdBucketName
        } else {
            bucketName = str_s3BucketName
        }
        if error != nil {
            debugPrint("File Uploaded Failed ===\(String(describing: error))")
            LogConfig.logE(message:"Error while uploading video - \(String(describing: error))", displayToThirdParty: true)
            self.noOfRetries = self.noOfRetries + 1
            LogConfig.logE(message:"Number of retries = \(self.noOfRetries)", displayToThirdParty: true)
            if (self.noOfRetries < 3) {
                DispatchQueue.main.async {
                    self.invalidateTimers()
                    self.videoFileName = ""
                #if ARKIT
                    self.uploadAllVideosToServer()
                #else
                    self.uploadVideo(localURL: localURL, fileName: fileName)
                #endif
                }
            } else {
                LogConfig.logE(message:"Retry upload", displayToThirdParty: true)
                UploadHelper.sharedInstance.noOfRetries = 0
                UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
                return
            }
        } else {
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
            LogConfig.logD(message: "######## Ending AWS upload for \(partname) at \(logTime() ) ########\n", displayToThirdParty: true)
            LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
            //After successful upload, check if the file exists on the S3 bucket
            let newFileName = "\(self.filePath)/\(fileName)"
            debugPrint("File Uploaded to ===\(newFileName)")
            AWSS3Manager.shared.checkIfFileExist(fileName: newFileName, completion: { success in
                LogConfig.logD(message:"Check if File exists at the path on S3", displayToThirdParty: true)
                if (success) {
                    self.invalidateTimers()
                #if ARKIT
                    var arrSavedVideos = UserSession.shared.getAllVideoInfoByScanName(scanName: UploadHelper.sharedInstance.scanToUpload)
                    arrSavedVideos.remove(at: 0)
                    UserSession.shared.saveAllVideoInfoByScanName(scanName: UploadHelper.sharedInstance.scanToUpload, arrSavedVideo: arrSavedVideos)
                    
                    //debugPrint("Video To Be Upload ",arrSavedVideos)
                    if arrSavedVideos.count > 0 {
                        self.uploadAllVideosToServer()
                        return
                    }
                #endif
                    //If file exists on S3 server, proceed with uploading the log file to the S3 bucket
//                    LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
//                    LogConfig.logD(message: "######## Starting LogFile Upload at \(logTime() ) ########\n", displayToThirdParty: true)
//                    LogConfig.logD(message: "=====================================================================", displayToThirdParty: true)
                    let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
                    let documentsDirectory = paths[0] as NSString
                    let directoryURL = URL(fileURLWithPath: documentsDirectory.appendingPathComponent(self.scanInfo["scanName"] as! String))
                    let fileURL = directoryURL.appendingPathComponent("logFile.txt")
                    let fileManager = FileManager.default
                    if fileManager.fileExists(atPath: fileURL.path) {
//                        let directoryFilePath = "\(bucketName)"
//                        let newFilePath = "\(self.logFilePath)"
                        
                        //Remove the scan folder after successful upload
                        if fileManager.fileExists(atPath: directoryURL.path) {
                            try? fileManager.removeItem(at: directoryURL)
                            LogConfig.logD(message:"Remove file from Local Directory", displayToThirdParty: true)
                        }
                    
                        DispatchQueue.main.async {
                            helperGetAppDeleate().dbWrapper.updateLocalScan(scanData: self.scanInfo , uploadStatus: UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue, uploadStatusStr: str_uploading, callback: {
                                self.invalidateTimers()
                                let dict = UserDefaults.standard.value(forKey: kMergePartUnitDict) as! [String : Any]
                                let shootTime = Int(dict[kShootTime] as! String)
                                var sec = shootTime! / 1000
                                let min = sec / 60
                                sec = sec - (min * 60)
                                let nwSpeedValue = helperGetFormattedShootTime(timeMin: min, timeSec: sec)
                                let uploadTime = Int(UploadHelper.sharedInstance.uploadTimeStr ?? "1")
                                let (min1,sec1) = ((uploadTime! % 3600) / 60, (uploadTime! % 3600) % 60)
                                let uploadTimeValue = "\(min1) min \(sec1) secs"
                                self.uploadUpdateDelegate?.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: uploadTimeValue, isVideo: true)
                                UploadHelper.sharedInstance.callMergePart()
                            })
                        }
                    }else {
                        DispatchQueue.main.async {
                            self.videoFileName = ""
                        #if ARKIT
                            self.uploadAllVideosToServer()
                        #else
                            self.uploadVideo(localURL: localURL, fileName: fileName)
                        #endif
                            
                        }
                    }
                }
            })
        }
    }
    
    func onVideoUploadCompletionViaFallback(uploadedFileUr: Any?, error: AFError?){
        var bucketName = String()
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            bucketName = str_s3ProdBucketName
        } else {
            bucketName = str_s3BucketName
        }
        if let error = error {
            LogConfig.logE(message:"Error while uploading video via fallback - \(error.localizedDescription))", displayToThirdParty: true)
            LogConfig.logE(message:"Retry upload", displayToThirdParty: true)
            UploadHelper.sharedInstance.noOfRetries = 0
            UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
            return
        } else {
            let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let documentsDirectory = paths[0] as NSString
            let directoryURL = URL(fileURLWithPath: documentsDirectory.appendingPathComponent(self.scanInfo["scanName"] as! String))
            let fileURL = directoryURL.appendingPathComponent("logFile.txt")
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: fileURL.path) {
                let directoryFilePath = "\(bucketName)"
                let newFilePath = "\(self.logFilePath)"
                AWSS3Manager.shared.bucketName = directoryFilePath
                AWSS3Manager.shared.uploadOtherFile(fileUrl: fileURL, conentType: "Text", filePath: newFilePath, progress: {( uploadProgress) in
                }) {[weak self] (uploadedFileUrl, error) in
                    UploadHelper.sharedInstance.noOfRetries = 0
                    DispatchQueue.main.async {
                        guard self != nil else { return }
                        if let finalPath = uploadedFileUrl as? String {
                            LogConfig.logD(message:"Uploaded file url: " + finalPath, displayToThirdParty: true)
                            
                            if fileManager.fileExists(atPath: directoryURL.path) {
                                try? fileManager.removeItem(at: directoryURL)
                                LogConfig.logD(message:"Remove file from Local Directory", displayToThirdParty: true)
                            }
                            
                            helperGetAppDeleate().dbWrapper.updateLocalScan(scanData: self!.scanInfo , uploadStatus: UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue, uploadStatusStr: str_uploading, callback: {
                                self?.invalidateTimers()
                                let dict = UserDefaults.standard.value(forKey: kMergePartUnitDict) as! [String : Any]
                                let shootTime = Int(dict[kShootTime] as! String)
                                var sec = shootTime! / 1000
                                let min = sec / 60
                                sec = sec - (min * 60)
                                let nwSpeedValue = helperGetFormattedShootTime(timeMin: min, timeSec: sec)
                                let uploadTime = Int(UploadHelper.sharedInstance.uploadTimeStr ?? "1")
                                let (min1,sec1) = ((uploadTime! % 3600) / 60, (uploadTime! % 3600) % 60)
                                let uploadTimeValue = "\(min1) min \(sec1) secs"
                                self?.uploadUpdateDelegate?.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: uploadTimeValue, isVideo: true)
                                    UploadHelper.sharedInstance.callMergePart()
                            })
                        } else {
                            LogConfig.logE(message:"\(String(describing: error?.localizedDescription))", displayToThirdParty: true)
                        }
                    }
                }
            }
        }
    }
    
    func invalidateTimers(){
        fallbackFlagCount = 0
        UploadHelper.sharedInstance.timer.invalidate()
        UploadHelper.sharedInstance.progressTimer.invalidate()
    }
    
    func updateSuccessOnApiCall(){
        let dict = UserDefaults.standard.value(forKey: kMergePartUnitDict) as! [String : Any]
        let shootTime = Int(dict[kShootTime] as! String)
        var sec = shootTime! / 1000
        let min = sec / 60
        sec = sec - (min * 60)
        let nwSpeedValue = helperGetFormattedShootTime(timeMin: min, timeSec: sec)
        let uploadTime = Int(UploadHelper.sharedInstance.uploadTimeStr ?? "1")
        let (min1,sec1) = ((uploadTime! % 3600) / 60, (uploadTime! % 3600) % 60)
        let uploadTimeValue = "\(min1) min \(sec1) secs"
        UserDefaults.standard.setValue(1.0, forKey: "uploadProgress")
        self.uploadUpdateDelegate?.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: uploadTimeValue, isVideo: true)
    }
    
    func copyFilesForUpdateScan() {
        Logger.debug("")
        let folders = self.scanToUpdateInfo[kFolders]! as! [[String : Any]]
        _ = folders[0][kUnitFiles] as! [[String : Any]]
        //this is error screen ask if this will be present in the current app
        //        let copyScreen = helperGetAppDeleate().updateScanProgressScreen
        //ask
        //        helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scanToUploadNext, unitStatus: str_updating) {
        //        }
        
        isVideoUpload = scanToUpdateInfo[kVideo] as? Bool ?? false
        //        if (pushCopyScreen) {
        //            LogConfig.logD(message:"Push Copy Screen")
        //            copyScreen.destBucketName = self.scanToUpload
        //            copyScreen.pushUploadScreen = true
        //            copyScreen.sourceBucketName = self.scanToUpdateInfo[kUnitName] as! String
        //            copyScreen.unitFiles = unitFiles
        //            copyScreen.partID = self.scanToUpdateInfo[kPartId] as! String
        //            copyScreen.isVideo = isVideoUpload
        //            copyScreen.startCopy = true
        //            if !(helperGetAppDeleate().navigation.viewControllers.contains(copyScreen)){
        //                helperGetAppDeleate().navigation.pushViewController(copyScreen, animated: true)
        //            }
        //        } else {
        //            LogConfig.logD(message:"Copy Files in Background")
        //            AWSS3Manager.shared.copyUpdateToHelperDelegate = self
        //            AWSS3Manager.shared.copyFiles(destBucketName: self.scanToUpload, srcBucketName: self.scanToUpdateInfo[kUnitName] as! String, unitFiles: unitFiles, partId: self.scanToUpdateInfo[kPartId] as! String, isVideo: isVideoUpload)
        //            copyScreen.pushUploadScreen = false
        //            copyScreen.startCopy = false
        //        }
    }
    
    func checkForJobsInQueue() {
        if UserSession.shared.getUserData() == nil {
            LogConfig.logD(message:"Guest Login - Upload Helper", displayToThirdParty: true)
            let loginRequest = LoginRequest(loginId: "ios_guest_user@photogauge.com", timezone: "333.0", password: "123456",deviceUUID: UserSession.shared.getDeviceUUID())
            APIClient.delegate = self
            APIClient.loginByUUID(request: loginRequest)
            return
        }
        
        LogConfig.logD(message:"JOB UPLOADING \(helperGetAppDeleate().dbWrapper.getUploadingJobs())", displayToThirdParty: true)
        
        LogConfig.logD(message:"JOBS IN QUEUE \(helperGetAppDeleate().dbWrapper.checkForJobsQueued())", displayToThirdParty: true)
        
        helperGetAppDeleate().dbWrapper.updateUnitStatusToInQueueIfStatusIs(forStatus: str_pending)
        
        LogConfig.logD(message:"################## CHECK FOR JOBS IN QUEUE ##################", displayToThirdParty: true)
        if !uploadingDummyPart {
            let isJobUploading = helperGetAppDeleate().dbWrapper.checkForJobsUploading()
            debugPrint("\(isJobUploading) Job Is Uploading ")
            if !isJobUploading{
                var (isQueued, scanList) = helperGetAppDeleate().dbWrapper.checkForJobsQueued()
                debugPrint("\(isQueued) Is IN Queue  ",scanList)
                if isQueued {
                    scanList.sort { (first, second) -> Bool in
                        return helperGetServerTimeInMillis(serverTime: first[kLocalShootTime] as! String) < helperGetServerTimeInMillis(serverTime: second[kLocalShootTime] as! String)
                    }
                    scanToUploadNext = scanList[0]
                   
                    if (scanToUploadNext[kVideo] as? Bool ?? false) && (scanToUploadNext[kMergePartDone] as? Bool ?? false) {
                        if (scanToUploadNext[kJobIds] as? Int == 0){
                            let isJobUploading = helperGetAppDeleate().dbWrapper.checkForJobsUploading()
                            if !isJobUploading{
                                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: self.scanToUploadNext, unitStatus: str_uploading) {
                                    UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = true
                                    UploadHelper.sharedInstance.scanToUpload = (scanToUploadNext[kUnitId] as! String)
                                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                                        helperGetAppDeleate().allUploadScreen.setupScanDetails()
                                    }
                                    self.uploadStatusDelegate?.notifyStatusChange()
                                }
                                
                                scanInfo = scanToUploadNext
                                UploadHelper.sharedInstance.addInspectionJobTask = true
                                //self.scanType = scanToUploadNext[kAction] as! String
                                var dict = [String : Any]()
                                dict[kPartId] = scanToUploadNext[kPartId]
                                dict[kUnitName] = scanToUploadNext[kUnitName]
                                UserDefaults.standard.setValue(dict, forKey: kMergePartUnitDict)
                                self.createAddInspectionDict()
                            }
                        }else{
                            helperGetAppDeleate().dbWrapper.updateInspectionJobScan(scanData: scanToUploadNext, uploadStatus: UPLOADSTATUS.ADD_INSPECTION_JOB_DONE.rawValue) {
                            }
                            checkForJobsInQueue()
                        }
                        return
                    }
                    
                    LogConfig.logD(message:"ScanToUploadNext - \(scanList[0])", displayToThirdParty: true)
                    let partId = scanToUploadNext[kPartId] as! String
                    if partId.contains("dummy") {
                        LogConfig.logD(message:"Offline Part - Create Part On Server", displayToThirdParty: true)
                        //create part
                        let partInfo = helperGetAppDeleate().dbWrapper.getSinglePartFromTable(partId: partId)
                        if !partInfo.isEmpty {
                            let partName = partInfo[0][kPartName] as! String
                            var partDesc = partInfo[0][kPartDesc] as? String ?? " "
                            let localPartCreationTime = partInfo[0][kLocalPartTimeCreation] as? String ?? " "
                            
                            if partDesc == "" {
                                partDesc = " "
                            }
                            
                            if !NetworkState.isConnected() {
                                return
                            }
                            
                            if !uploadingDummyPart {
                                self.uploadingDummyPart = true
                                callAddPartApi(with: partName, description: partDesc,localPartCreationTime: localPartCreationTime)
                            }
                        }
                    }else{
                        let isJobUploading = helperGetAppDeleate().dbWrapper.checkForJobsUploading()
                        
                        if !isJobUploading{
                            LogConfig.logD(message:"Job is not Uploading. Start Upload", displayToThirdParty: true)
                            if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                                helperGetAppDeleate().allUploadScreen.setupScanDetails()
                            }
                            UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
                            UploadHelper.sharedInstance.scanToUpload = (scanToUploadNext[kUnitId] as! String)
                            uploadStatusDelegate?.notifyStatusChange()
                            
                            if scanList[0][kAction] as! String == str_update_scan {
                                UploadHelper.sharedInstance.scanType = str_update_scan //"scanToUpDate_NewPart18Jan_Four_scan_1611150980712"
                                let scanToUpdate = UserDefaults.standard.value(forKey: "scanToUpDate_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
                                UploadHelper.sharedInstance.scanToUpdateInfo = scanToUpdate as! [String : Any]
                                copyFilesForUpdateScan()
                                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scanToUploadNext, unitStatus: str_updating) {
                                }
                            }else if scanList[0][kAction] as! String == str_re_scan {
                                UploadHelper.sharedInstance.scanType = str_re_scan
                                UploadHelper.sharedInstance.createJson()
                            }else{
                                UploadHelper.sharedInstance.scanType = str_new_scan
                                UploadHelper.sharedInstance.createJson()
                            }
                        }else{
                            LogConfig.logD(message:"Upload is in progress. Move to Queue", displayToThirdParty: true)
                            UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = true
                            UploadHelper.sharedInstance.uploadScreen!.toastMessage = str_upload_is_queued
                        }
                    }
                }else{
                    LogConfig.logD(message:"NO SCANS in QUEUE", displayToThirdParty: true)
                    uploadStatusDelegate?.notifyStatusChange()
                    return
                }
            }
        } else {
            LogConfig.logD(message:"Uploading Dummy part in progress", displayToThirdParty: true)
        }
    }
    
    func getUploadingScan() {
        LogConfig.logD(message:"################## GET UPLOADING SCAN ##################", displayToThirdParty: true)
        let updatingScanList = helperGetAppDeleate().dbWrapper.getUpdatingJobs()
        if updatingScanList.count > 0 {
            scanToUploadNext = updatingScanList[0]
            LogConfig.logD(message:"ScanToUpload - \(updatingScanList[0])", displayToThirdParty: true)
            helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scanToUploadNext, unitStatus: str_updating) {
            }
            if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                helperGetAppDeleate().allUploadScreen.setupScanDetails()
            }
            UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
            UploadHelper.sharedInstance.scanToUpload = (scanToUploadNext[kUnitId] as! String)
            
            UploadHelper.sharedInstance.scanType = str_update_scan
            let scanToUpdate = UserDefaults.standard.value(forKey: "scanToUpDate_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
            UploadHelper.sharedInstance.scanToUpdateInfo = scanToUpdate as! [String : Any]
            copyFilesForUpdateScan()
        } else {
            checkForJobsInQueue()
        }
    }
    
    func callAddPartApi(with partName: String, description: String,localPartCreationTime:String){
        let addPartRequest = AddPartRequest(partName: partName, zipCode: "", partCustomer: "", address: "", localPartTimeCreation: localPartCreationTime, partDescription: description)
        APIClient.delegate = self
        APIClient.addPart(request: addPartRequest)
    }
    
    func createJson() {
        LogConfig.logD(message:"POINT A - create JSON", displayToThirdParty: true)
        self.imagesToUpload = []
        self.uploadingImagesId = []
        self.imagesInfo = [:]
        imagesToUploadCount = 0
        self.totalImagesToUploadCount = 0
        //self.imagesUploadedCount = 0
        if UserDefaults.standard.value(forKey: scanToUpload) as? [String : Any] == nil {
            scanInfo = scanToUploadNext
            let partId = scanInfo[kPartId] as! String
            let partDetails = helperGetAppDeleate().dbWrapper.getSinglePartFromTable(partId: partId)
            let partInfo: [String : Any] = partDetails[0]
            let partname = partInfo[kPartName] as! String
            self.isVideoUpload = scanInfo[kVideo] as! Bool
            if (isVideoUpload) {
                self.uploadUpdateDelegate?.textInfoUpdated(projectName: (partInfo[kPartName] as! String), windowName: (scanInfo[kUnitDisplayName] as! String), uploadCount: 1, totalUploadsCount: 1, progress: 1, location: (scanInfo[kRoomType] as! String), isVideo: isVideoUpload,partDesc: partInfo[kPartDesc] as? String ?? "")
                let shootTime = scanInfo[kShootTime] as! Int
                var sec = shootTime / 1000
                let min = sec / 60
                sec = sec - (min * 60)
                let nwSpeedValue = helperGetFormattedShootTime(timeMin: min, timeSec: sec)
                //let uploadTime = Int(UploadHelper.sharedInstance.uploadTimeStr ?? "1")
                //let (min1,sec1) = ((uploadTime! % 3600) / 60, (uploadTime! % 3600) % 60)
                //let uploadTimeValue = "\(min1) min \(sec1) secs"
                self.uploadUpdateDelegate?.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: "", isVideo: true)
            } else {
                self.totalImagesToUploadCount = UserDefaults.standard.value(forKey: "totalImageCount_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))") as! Int
                let imagesUploadedCount = totalImagesToUploadCount
                let decimalProgress = 1
                self.uploadUpdateDelegate?.textInfoUpdated(projectName: partname, windowName: (scanInfo[kUnitDisplayName] as! String), uploadCount: imagesUploadedCount, totalUploadsCount: totalImagesToUploadCount, progress: Float(decimalProgress), location: "0 bytes", isVideo: isVideoUpload,partDesc: partInfo[kPartDesc] as? String ?? "")
                let shootTime = scanInfo[kShootTime] as! Int
                let (min,sec) = ((shootTime % 3600) / 60, (shootTime % 3600) % 60)
                let nwSpeedValue = "\(min) min \(sec) secs"
                self.uploadUpdateDelegate?.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: "", isVideo: false)
            }
            
            return
        } else {
            scanInfo = UserDefaults.standard.value(forKey: scanToUpload) as! [String : Any]
            scanToUploadNext = scanInfo
        }
        
        let scanName = scanInfo[kScanName] as! String
        DispatchQueue.main.async {
            helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: self.scanToUploadNext, unitStatus: str_uploading) {
                if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                    helperGetAppDeleate().allUploadScreen.setupScanDetails()
                }
                self.uploadStatusDelegate?.notifyStatusChange()
            }
        }
        
        isVideoUpload = scanInfo[kVideo] as! Bool
        
        //        if !isVideoUpload {
        //            self.fetchCustomAlbumPhotos(albumName: scanToUpload)
        //        }
        //
        var dict = [String: Any]()
        
        if self.scanType == str_new_scan {
            dict[kAction] = str_new_scan
        }else if self.scanType == str_re_scan {
            dict[kAction] = str_re_scan
        }else if self.scanType == str_update_scan {
            dict[kAction] = str_update_scan
        }
        
        LogConfig.logD(message:"scanType - \(self.scanType)", displayToThirdParty: true)
        
        dict[kAppVersion] = helperGetAppVersion()
        dict[kDeviceSerialNo] = str_generic_phone
        dict[kDeviceType] = str_iPhone
        dict[kDisplayName] = scanInfo[kDisplayName] as! String
        dict[kChannelFlag] = ""
        //scanInfo[kChannelFlag] as! String
        
        var folders = [[String : Any]]()
        var unitFiles = [[String : Any]]()
        timeStamps = scanInfo[kTimeStamps] as! [String]
        var videoName = String()
        if !isVideoUpload {
            if self.scanType == str_update_scan {
                let oldFolders = self.scanToUpdateInfo[kFolders] as! [[String : Any]]
                let oldUnitFiles = oldFolders[0][kUnitFiles] as! [[String : Any]]
                
                for oldUnitFile in oldUnitFiles {
                    var unitFile = [String : Any]()
                    unitFile[kFileHeight] = oldUnitFile[kFileHeight]
                    unitFile[kFileName] = oldUnitFile[kFileName]
                    unitFile[kFileOriginalName] = oldUnitFile[kFileOriginalName]
                    unitFile[kFileType] = oldUnitFile[kFileType]
                    unitFile[kFileWidth] = oldUnitFile[kFileWidth]
                    unitFile[kMasked] = oldUnitFile[kMasked]
                    
                    unitFiles.append(unitFile)
                }
            }
            
            if (imagesToUpload.count > 0) {
                for i in 0...imagesToUpload.count - 1 {
                    if uploadingImagesId[i] != "profilePic" {
                        let image = imagesToUpload[i]
                        let imageName = "PhotoGAUGE_" + uploadingImagesId[i] + ".png"
                        imagesInfo[imageName] = image
                        uploadingImagesId[i] = imageName
                        
                        var unitFile = [String : Any]()
                        unitFile[kFileHeight] = image.size.height
                        unitFile[kFileName] = imageName
                        unitFile[kFileOriginalName] = imageName
                        unitFile[kFileType] = str_image
                        unitFile[kFileWidth] = image.size.width
                        unitFile[kMasked] = str_false
                        
                        unitFiles.append(unitFile)
                    } else {
                        let imageName = uploadingImagesId[i] + ".png"
                        uploadingImagesId[i] = imageName
                    }
                }
            }
            
            UploadHelper.sharedInstance.imagesToUploadCount = self.uploadingImagesId.count
            if (self.imagesToUploadCount == 0) {
                LogConfig.logD(message:"imagesToUploadCount is 0. Calling Merge Part API", displayToThirdParty: true)
                
                if UserDefaults.standard.dictionary(forKey: "mergePartDict_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))") != nil {
                    let mergePartDict = UserDefaults.standard.dictionary(forKey: "mergePartDict_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
                    UserDefaults.standard.setValue(mergePartDict, forKey: kMergePartUnitDict)
                    LogConfig.logD(message:"Merge Part Dict - \(String(describing: mergePartDict))", displayToThirdParty: true)
                    
                    DispatchQueue.main.async {
                        helperGetAppDeleate().dbWrapper.updateLocalScan(scanData: self.scanInfo , uploadStatus: UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue, uploadStatusStr: str_uploading, callback: {
                            self.invalidateTimers()
                            let dict = UserDefaults.standard.value(forKey: kMergePartUnitDict) as! [String : Any]
                            let shootTime = Int(dict[kShootTime] as! String)
                            let (min,sec) = ((shootTime! % 3600) / 60, (shootTime! % 3600) % 60)
                            let nwSpeedValue = "\(min) min \(sec) secs"
                            let uploadTime = Int(UploadHelper.sharedInstance.uploadTimeStr ?? "1")
                            let (min1,sec1) = ((uploadTime! % 3600) / 60, (uploadTime! % 3600) % 60)
                            let uploadTimeValue = "\(min1) min \(sec1) secs"
                            self.uploadUpdateDelegate?.uploadSuccessUIUpdate(nwSpeedValue: nwSpeedValue, uploadTimeValue: uploadTimeValue, isVideo: false)
                            UploadHelper.sharedInstance.callMergePart()
                        })
                    }
                }
            }
            var tempD = [String : Any]()
            tempD[kFolderName] = str_auto1
            tempD[kUnitFiles] = unitFiles
            folders.append(tempD)
            dict[kFolders] = folders
        }else{
        #if ARKIT
            let arrSavedVideos = UserSession.shared.getAllVideoInfoByScanName(scanName: UploadHelper.sharedInstance.scanToUpload)
            for videoInfo in arrSavedVideos {
                let videoName = URL.init(string: videoInfo.newFileURLStr)?.lastPathComponent
                var unitFile = [String : Any]()
                unitFile[kFileHeight] = 0
                unitFile[kFileName] = videoName
                unitFile[kFileOriginalName] = videoName
                unitFile[kFileType] = str_video
                unitFile[kFileWidth] = 0
                unitFile[kMasked] = str_false
                unitFiles.append(unitFile)
            }
        #else
            videoName = "video_" + timeStamps[0] + ".mp4"
            var unitFile = [String : Any]()
            unitFile[kFileHeight] = 0
            unitFile[kFileName] = videoName
            unitFile[kFileOriginalName] = videoName
            unitFile[kFileType] = str_video
            unitFile[kFileWidth] = 0
            unitFile[kMasked] = str_false
            unitFiles.append(unitFile)
        #endif
            
            
            var tempD = [String : Any]()
            tempD[kFolderName] = str_auto1
            tempD[kUnitFiles] = unitFiles
            folders.append(tempD)
            dict[kFolders] = folders
        }
        
        if UploadHelper.sharedInstance.scanType == str_re_scan {
            if UploadHelper.sharedInstance.parentIdForReScan != "" {
                dict[kParentScanId] = UploadHelper.sharedInstance.parentIdForReScan
            }
        }else if UploadHelper.sharedInstance.scanType == str_update_scan {
            dict[kParentScanId] = scanInfo[kParentScanId]
        }
        var partInfo = [String : Any]()
        partInfo = scanInfo[kPartDetails] as! [String : Any]
        //let partname = partInfo[kPartName] as! String
        //partInfo = helperGetAppDeleate().dbWrapper.getPartFromTable(withPartName: partname)
        let partId = partInfo[kPartId] as! String
        dict[kLocalShootTime] = scanInfo[kLocalShootTime] as! String
        dict[kLocalShootTimeStr] = scanInfo[kLocalShootTimeStr] as! String
        dict[kLocationLat] = 0.0
        dict[kLocationLng] = 0.0
        dict[kPartId]  = partId
        
        if self.scanType == str_update_scan {
            dict[kCalibrationScan] = self.scanToUpdateInfo[kCalibrationScan]
            dict[kPartReconst] = self.scanToUpdateInfo[kPartReconst]
            dict[kRunCreateMask] = self.scanToUpdateInfo[kRunCreateMask]
            dict[kRunMetrology] = self.scanToUpdateInfo[kRunMetrology]
            dict[kRunPhotoScan] = self.scanToUpdateInfo[kRunPhotoScan]
            dict[kScan] = self.scanToUpdateInfo[kScan]
            dict[kTurnTableStatus] = self.scanToUpdateInfo[kTurnTableStatus]
            dict[kSubParentScanId] = scanInfo[kParentScanId]
        } else if self.scanType == str_re_scan {
            dict[kCalibrationScan] = true
            dict[kPartReconst] = str_high
            let maskInfo = scanInfo["maskInfo"] as! [String:Any]
            dict[kRunCreateMask] = maskInfo[kRunCreateMask]
            dict[kRunMetrology] = maskInfo[kRunMetrology]
            dict[kRunPhotoScan] = true
            dict[kScan] = true
            dict[kTurnTableStatus] = false
        }else{
            dict[kCalibrationScan] = true
//            dict[kPartReconst] = str_high
            dict[kRunCreateMask] = false
            dict[kRunMetrology] = false
            dict[kRunPhotoScan] = true
            dict[kScan] = true
            dict[kTurnTableStatus] = false
        }
        if !isVideoUpload{
            dict[kPixelSize] = "0.0018" //let's see for now
            dict[kProfilePic] = "profilePic/profilePic.png"
            dict[kVideo] = false
        }else{
            dict[kPixelSize] = "0.0018"
            dict[kVideo] = true
            dict["videoFps"] = 30
            dict["videoQuality"] = "video [4k]"
        }
        
        dict[kShootTime] = scanInfo[kShootTime] as! String
        dict[kUnitName] = scanInfo[kScanName] as! String
        dict[kuseAustralis] = false
        dict[kAppSelectionType] = scanInfo[kAppSelectionType] as! String
//        let type = UserSession.shared.getUserSelection()
//        if type == str_digital_twin {
//            dict[kAppSelectionType] = str_3d_model
//        }else{
//            dict[kAppSelectionType] = str_measurements
//        }
        if UserSession.shared.getUserData()?.accountType == "ConstructionAndRenovation" {
            dict[kType] = "construction"
            //dict[kObjectType] = scanInfo[kObjectType]
            dict[kObjectPosition] = scanInfo[kObjectPosition]
            dict["notes"] = scanInfo[kUnitNotes]
            dict[kUnitSold] = scanInfo[kUnitSold]
            
            var objectTypeNameDict = [String: Any]()
            objectTypeNameDict[kName] = "other"
            objectTypeNameDict[kCode] = "other"
            objectTypeNameDict[kType] = "Window"
            dict[kObjectType] = objectTypeNameDict
            
            var roomTypeDict = [String: Any]()
            roomTypeDict[kName] = "other"
            roomTypeDict[kCode] = "other"
            roomTypeDict[kType] = "room"
            dict[kRoomType] = roomTypeDict
        }else if UserSession.shared.getUserData()?.accountType == "general"{
            dict[kType] = "general"
        }else{
            dict[kType] = "scan"
        }
        
        let shootTime = Int(dict[kShootTime] as! String)
        var sec = shootTime! / 1000
        let min = sec / 60
        sec = sec - (min * 60)
        //        let nwSpeedValue = helperGetFormattedShootTime(timeMin: min, timeSec: sec)
        
        if UserDefaults.standard.dictionary(forKey: "mergePartDict_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))") != nil {
            let mergePartDict = UserDefaults.standard.dictionary(forKey: "mergePartDict_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
            UserDefaults.standard.setValue(mergePartDict, forKey: kMergePartUnitDict)
        } else {
            UserDefaults.standard.setValue(dict, forKey: kMergePartUnitDict)
            UserDefaults.standard.setValue(dict, forKey: "mergePartDict_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
        }
        LogConfig.logD(message:"Create JSON - Dict created - \(dict)", displayToThirdParty: true)
        
        UserDefaults.standard.setValue((partInfo[kPartName] as! String), forKey: "uploadingPartName")
        //        UserDefaults.standard.setValue((scanInfo[kRoomType] as! String), forKey: "uploadingLocationName")
        UserDefaults.standard.setValue((partInfo[kPartDesc] as! String), forKey: "uploadingPartDesc")
        
        UserDefaults.standard.setValue((scanInfo[kDisplayName] as! String), forKey: "uploadingScanName")
        UserDefaults.standard.setValue(isVideoUpload, forKey: "isVideoUpload")
        
        if isVideoUpload {
            //nwSpeedValue = (scanInfo[kObjectTypeName] as! String)
            self.uploadUpdateDelegate?.textInfoUpdated(projectName: (partInfo[kPartName] as! String), windowName: (scanInfo[kDisplayName] as! String), uploadCount: 1, totalUploadsCount: 1, progress: 0, location: (scanInfo[kRoomType] as? String) ?? "other", isVideo: isVideoUpload,partDesc: partInfo[kPartDesc] as? String ?? "")
            self.filePath = helperGetAWSBucketPathForVideo(withPartId: partId, scanName: scanName)
            self.logFilePath = helperGetAWSBucketPathForLogFile(withPartId: partId, scanName: scanName)
            //UserDefaults.standard.setValue("Window Type: \(nwSpeedValue)", forKey: "photosUploadedLblText")
            UserDefaults.standard.setValue("Uploading 0%", forKey: "uploadStatusLblText")
            UserDefaults.standard.setValue(0.0, forKey: "uploadProgress")
            
        #if ARKIT
            self.uploadAllVideosToServer()
        #else
            let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let documentsDirectory = paths[0] as NSString
            let fileURL = URL(fileURLWithPath: documentsDirectory.appendingPathComponent(self.scanInfo[kVideoLocalPath] as! String))
            
            LogConfig.logD(message:"IS JOB UPLOADING -\(helperGetAppDeleate().dbWrapper.checkForJobsUploading())", displayToThirdParty: true)
            LogConfig.logD(message:"JOB UPLOADING IS: - \(helperGetAppDeleate().dbWrapper.getUploadingJobs())", displayToThirdParty: true)
            
            uploadVideo(localURL: fileURL, fileName: videoName)
        #endif
            
        }
    }
    
    func uploadAllVideosToServer() {
        let arrSavedVideos = UserSession.shared.getAllVideoInfoByScanName(scanName: UploadHelper.sharedInstance.scanToUpload)
        debugPrint("Number of available Video =============\(arrSavedVideos.count)")
        if arrSavedVideos.count > 0 {
            let videoInfo = arrSavedVideos[0]
            let videoName = URL(string: videoInfo.newFileURLStr)?.lastPathComponent ?? ""
            
            let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let documentsDirectory = paths[0] as NSString
            var fileURL = URL(fileURLWithPath: documentsDirectory.appendingPathComponent(videoInfo.customAlbumName))
            fileURL = fileURL.appendingPathComponent(URL(string: videoInfo.newFileURLStr)?.lastPathComponent ?? "")
            
            // This will update the progress bar status if some parts of video already uploaded
            // and we are trying to upload cancelled shoot
            onVideoUploadProgress(progress: 0.005)
            
            UserDefaults.standard.setValue("", forKey: kVideoUploadingEnd)
            UserDefaults.standard.setValue("yes", forKey: kVideoUploadingStart)
            
            //let fileURL = URL(string: videoInfo.newFileURLStr)
            debugPrint("Upload Video ====invalidate======\(fileURL.absoluteString )  \(arrSavedVideos.count)")
            LogConfig.logD(message:"Upload Video \(fileURL.absoluteString )", displayToThirdParty: true)
            uploadVideo(localURL: fileURL, fileName: videoName)
        }else{
            if self.scanToUploadNext[kMergePartDone] as? Bool ?? false {
                LogConfig.logD(message:"Merge Part API is done. Call Add inpection job API", displayToThirdParty: true)
                invalidateTimers()
                //                self.updateSuccessOnApiCall()
                self.createAddInspectionDict()
                return
            } else {
                helperGetAppDeleate().dbWrapper.updateLocalScan(scanData: self.scanInfo , uploadStatus: UPLOADSTATUS.UPLOAD_FILES_SUCCESS.rawValue, uploadStatusStr: str_uploading, callback: {
                    invalidateTimers()
                    self.updateSuccessOnApiCall()
                    UploadHelper.sharedInstance.callMergePart()
                })
                return
            }
        }
        
    }
    
    func addImgToArray(uploadImage:UIImage) {
        Logger.debug("")
        self.imagesToUpload.append(uploadImage)
    }
    
    func secondsToHoursMinutesSeconds (seconds : Int) -> (Int, Int, Int) {
        return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
    }
    
    func cancelUpload(callback: (() -> ())) {
        LogConfig.logD(message:"Cancel Upload called", displayToThirdParty: true)
        AWSS3Manager.shared.cancelUploads(callback: {
            videoFileName = ""
            let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
            if (uploadingJobs.count != 0) {
                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: uploadingJobs[0], unitStatus: str_cancelled) {
                }
                UploadHelper.sharedInstance.uploadScreen?.uploadInProgress = false
                helperGetAppDeleate().hideActivityView()
                self.checkForJobsInQueue()
            }
            callback()
        })
        let session = Alamofire.Session.default
        session.cancelAllRequests()
        invalidateTimers()
    }
    
    func cancelAWSUploadAndTriggerCallback() {
        LogConfig.logD(message: "Cancel aws and trigger fallback ", displayToThirdParty: true)
        AWSS3Manager.shared.cancelUploads(callback: {
//            callForFallback(fileName: <#String#>)
        })
    }
    
    func pauseUpload(callback: (() -> ())) {
        LogConfig.logD(message:"Pause Upload called", displayToThirdParty: true)
        AWSS3Manager.shared.pauseUploads(callback: {
            
            let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
            if (uploadingJobs.count != 0) {
                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: uploadingJobs[0], unitStatus: str_paused) {
                }
                UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
                helperGetAppDeleate().hideActivityView()
                self.checkForJobsInQueue()
            }
            callback()
        })
        invalidateTimers()
    }
    
    func queueUpload() {
        LogConfig.logD(message:"Queue Ongoing Upload called", displayToThirdParty: true)
        AWSS3Manager.shared.cancelUploads(callback: {
            videoFileName = ""
            let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
            if (uploadingJobs.count != 0) {
                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: uploadingJobs[0], unitStatus: str_queued) {
                }
                UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
                helperGetAppDeleate().hideActivityView()
                if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                    helperGetAppDeleate().allUploadScreen.setupScanDetails()
                }
                //                helperGetAppDeleate().uploadScreen.showNetworkDisconnectionScreen()
                UserDefaults.standard.setValue(true, forKey: "showRedSnackBar")
            }
        })
        invalidateTimers()
    }
    
    
    func changeToRetryUploadDueToNetworkIssues(isMergePartDone: Bool) {
        LogConfig.logD(message:"Retry Upload called", displayToThirdParty: true)
        let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        if (uploadingJobs.count != 0) {
            if isMergePartDone{
                helperGetAppDeleate().dbWrapper.updateMergePartOfScan(scanData: uploadingJobs[0])
            }
            helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: uploadingJobs[0], unitStatus: str_retry_upload) {
                AWSS3Manager.shared.cancelUploads(callback: {
                    videoFileName = ""
                    UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
                    helperGetAppDeleate().hideActivityView()
                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                        helperGetAppDeleate().allUploadScreen.setupScanDetails()
                    }
                    if let unitName = uploadingJobs[0][kUnitName] as? String{
                        self.uploadUpdateDelegate?.uploadFailed(for: unitName, isInternetAvailable: false)
                    }
                    //                    helperGetAppDeleate().uploadScreen.showNetworkDisconnectionScreen()
                    UserDefaults.standard.setValue(true, forKey: "showRedSnackBar")
                    //                    helperGetAppDeleate().partScreen.handleScreenSpecificRedSnackBarChange()
                })
            }
            invalidateTimers()
        }
    }
    
    func changeToRetryUpload(isMergePartDone: Bool) {
        LogConfig.logD(message:"Retry Upload called", displayToThirdParty: true)
        let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        if (uploadingJobs.count != 0) {
            if isMergePartDone{
                helperGetAppDeleate().dbWrapper.updateMergePartOfScan(scanData: uploadingJobs[0])
            }
            helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: uploadingJobs[0], unitStatus: str_retry_upload) {
                AWSS3Manager.shared.cancelUploads(callback: {
                    videoFileName = ""
                    UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
                    helperGetAppDeleate().hideActivityView()
                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                        helperGetAppDeleate().allUploadScreen.setupScanDetails()
                    }
                    if let unitName = uploadingJobs[0][kUnitName] as? String{
                        self.uploadUpdateDelegate?.uploadFailed(for: unitName, isInternetAvailable: true)
                    }
                    //                    helperGetAppDeleate().uploadScreen.showNetworkDisconnectionScreen()
                    UserDefaults.standard.setValue(true, forKey: "showRedSnackBar")
                    //                    helperGetAppDeleate().partScreen.handleScreenSpecificRedSnackBarChange()
                })
                
            }
            invalidateTimers()
        }
    }
    
    func changeFromRetryToQueued() {
        var (isRetryQueued, retryScanList) = helperGetAppDeleate().dbWrapper.checkForRetryUploadJobs()
        let (isQueued, _) = helperGetAppDeleate().dbWrapper.checkForJobsQueued()
        if isRetryQueued {
            retryScanList.sort { (first, second) -> Bool in
                return helperGetServerTimeInMillis(serverTime: first[kLocalShootTime] as! String) < helperGetServerTimeInMillis(serverTime: second[kLocalShootTime] as! String)
            }
            
            for scan in retryScanList {
                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scan, unitStatus: str_queued) {
                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                        helperGetAppDeleate().allUploadScreen.setupScanDetails()
                    }
                }
            }
            if !helperGetAppDeleate().isOffline {
                UploadHelper.sharedInstance.checkForJobsInQueue()
            }
        }else{
            if isQueued{
                if !helperGetAppDeleate().dbWrapper.checkForJobsUploading(){
                    if !helperGetAppDeleate().isOffline {
                        UploadHelper.sharedInstance.checkForJobsInQueue()
                    }
                }
            }
        }
    }
    
    func retryUpload(unitName: String, callback: (() -> ())) {
        
        LogConfig.logD(message:"Retry Upload clicked", displayToThirdParty: true)
        var scanList = [Dictionary<String, Any>]()
        scanList = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        if scanList.count != 0 {
            helperGetAppDeleate().dbWrapper.queueRetryUploadJobs()
            return
        }
        helperGetAppDeleate().dbWrapper.updateScansForRetryUpload(unitName: unitName, callback: {
            
        })
        scanList = helperGetAppDeleate().dbWrapper.getUploadingJobs()
        if scanList.count == 0 {
            return
        }
        scanToUploadNext = scanList[0]
        let partId = scanToUploadNext[kPartId] as! String
        if partId.contains("dummy") {
            //create part
            let partInfo = helperGetAppDeleate().dbWrapper.getSinglePartFromTable(partId: partId)
            if !partInfo.isEmpty {
                let partName = partInfo[0][kPartName] as! String
                let partDesc = partInfo[0][kPartDesc] as! String
                let partCustomer = partInfo[0][kPartCustomer] as! String
                let partZipcode = partInfo[0][kZipCode] as! String
                let partAddress = partInfo[0][kAddress] as! String
                let partTimeCreation = partInfo[0][kLocalPartTimeCreation] as! String
                var addPartInfo = [String: Any]()
                addPartInfo[kPartName] = partName
                addPartInfo[kPartCustomer] = partCustomer
                addPartInfo[kZipCode] = partZipcode
                addPartInfo[kAddress] = partAddress
                if partDesc != "" {
                    addPartInfo[kPartDesc] = partDesc
                }else{
                    addPartInfo[kPartDesc] = " "
                }
                addPartInfo[kPartCatergoryName] = "scan"
//                addPartInfo[kPartReconst] = str_high
                //                    addPartInfo[kPartTypeName] = "tire"
                addPartInfo[kLocalPartTimeCreation] = partTimeCreation
                
                if !NetworkState.isConnected() {
                    return
                }
                //                helperGetAppDeleate().backend.delegate = self
                helperGetAppDeleate().showActivityView()
                if !uploadingDummyPart {
                    self.uploadingDummyPart = true
                    //                    helperGetAppDeleate().backend.addPart(addPartInfo)
                }
            }
        }else{
            helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scanToUploadNext, unitStatus: str_uploading) {
            }
            if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                helperGetAppDeleate().allUploadScreen.setupScanDetails()
            }
            UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
            UploadHelper.sharedInstance.scanToUpload = (scanToUploadNext[kUnitId] as! String)
            uploadStatusDelegate?.notifyStatusChange()
            
            if scanList[0][kAction] as! String == str_update_scan {
                UploadHelper.sharedInstance.scanType = str_update_scan //"scanToUpDate_NewPart18Jan_Four_scan_1611150980712"
                let scanToUpdate = UserDefaults.standard.value(forKey: "scanToUpDate_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
                UploadHelper.sharedInstance.scanToUpdateInfo = scanToUpdate as! [String : Any]
                copyFilesForUpdateScan()
            }else if scanList[0][kAction] as! String == str_re_scan {
                UploadHelper.sharedInstance.scanType = str_re_scan
                UploadHelper.sharedInstance.createJson()
            }else{
                UploadHelper.sharedInstance.scanType = str_new_scan
                UploadHelper.sharedInstance.createJson()
            }
        }
    }
    
    func callForFallback(fileName: String){
        if videoFileName == fileName {
            LogConfig.logD(message:"same file name so upload returned", displayToThirdParty: true)
            return
        }else{
            LogConfig.logD(message:"New file name so upload continue", displayToThirdParty: true)
            videoFileName = fileName
            var bucketName = String()
            if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
                bucketName = str_s3ProdBucketName
            } else {
                bucketName = str_s3BucketName
            }
            let path = "\(bucketName)/\(self.filePath)"
            LogConfig.logD(message: "Path for fallback \(path)\nFilename \(fileName)", displayToThirdParty: true)
            APIClient.delegate = self
            do{
                let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
                let documentsDirectory = paths[0] as NSString
                let fileURL = URL(fileURLWithPath: documentsDirectory.appendingPathComponent(self.scanInfo[kVideoLocalPath] as! String))
                let videoData = try Data(contentsOf: fileURL)
                APIClient.uploadVideoToServer(videoData: videoData, name: "file", fileName: fileName, path: path) { [weak self] progress in
                    self?.onVideoUploadProgress(progress: progress)
                } completion: { [weak self]  uploadedFileUrl, error in
                    self?.onVideoUploadCompletionViaFallback(uploadedFileUr: uploadedFileUrl, error: error)
                }
            }
            catch {
                LogConfig.logE(message: "Video data not found", displayToThirdParty: true)
            }
        }
    }
}




extension UploadHelper: NetworkSpeedUpdater {
    func updateNetworkSpeed(speed: String) {
        self.uploadUpdateDelegate?.updateNetworkSpeed(speed: speed)
    }
}

extension UploadHelper: CopyUpdateToUploadHelperDelegate {
    
    func percentageCopyUpdated(progress: Float) {
        LogConfig.logD(message:"progress : \(progress)", displayToThirdParty: true)
        if progress == 100.0 {
            UploadHelper.sharedInstance.createJson()
            //            helperGetAppDeleate().backend.delegate = self
        }
    }
}


extension UploadHelper : ServerWrapperDelegate{
    
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        LogConfig.logE(message:"Request Failed \(requestId), errorInfo - \(errorInfo)", displayToThirdParty: true)
        if requestId == RequestId.RID_ADD_INSPECTION_JOB {
            videoFileName = ""
            helperGetAppDeleate().scheduleNotification(msg: "Failure in uploading scans")
            UploadHelper.sharedInstance.noOfRetries = 0
            UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: true)
        }else if requestId == RequestId.RID_MERGE_PART_UNIT{
            //added coz otherwise the uploaVideo function will throw out since the video is already uploaded, after adding this it will go inside the func and only all merge part api
            videoFileName = ""
            helperGetAppDeleate().scheduleNotification(msg: "Failure in uploading scans")
            UploadHelper.sharedInstance.noOfRetries = 0
            UploadHelper.sharedInstance.changeToRetryUpload(isMergePartDone: false)
        }
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: errorInfo.message)
    }
    
    func loggedIn(_ results: LoginResponse) {
        LogConfig.logD(message:"Results \(results)", displayToThirdParty: true)
        UserSession.shared.setUserData(data: results)
        UserSession.shared.setGuestUserData(data: results)
        UserSession.shared.setUserTypeAsGuest()
        checkForJobsInQueue()
    }
    
    func partUnitMerged(_ results: MergePartResponse) {
        self.etagCalledForMergePart = true
        
        if NetStatus.shared.isConnected && !helperGetAppDeleate().isOffline {
            helperGetAppDeleate().allUploadScreen.restartEtagTimer()
        }
        
        LogConfig.logD(message:"POINT D - PART UNIT MERGED\(results)", displayToThirdParty: true)
        
        UserDefaults.standard.removeObject(forKey: "mergePartDict_\(String(describing: UploadHelper.sharedInstance.scanToUpload!))")
        LogConfig.logD(message:"\(UserDefaults.standard.value(forKey: scanToUpload) as! [String : Any])", displayToThirdParty: true)
        if let unitData = UserDefaults.standard.value(forKey: scanToUpload) as? [String : Any]{
            var tempDict = unitData
            tempDict[kMergePartDone] = true
            UserDefaults.standard.setValue(tempDict, forKey: scanToUpload)
        }
        
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().dbWrapper.updateLocalScan(scanData: scanInfo, uploadStatus: UPLOADSTATUS.MERGE_PART_API_CALL_DONE.rawValue, uploadStatusStr: str_uploading, callback: {
            self.createAddInspectionDict()
        })
    }
    
    func inspectionJobAdded(_ results: AddInspectionJobResponse) {
        LogConfig.logD(message:"POINT F - inspectionJobAdded\(results)", displayToThirdParty: true)
        self.etagCalledForInspectionJob = true
        
        if NetStatus.shared.isConnected && !helperGetAppDeleate().isOffline {
            helperGetAppDeleate().allUploadScreen.restartEtagTimer()
        }
        
        helperGetAppDeleate().scheduleNotification(msg: str_scan_uploaded_successfully)
        helperGetAppDeleate().hideActivityView()
        UploadHelper.sharedInstance.uploadScreen!.uploadInProgress = false
        
        var scanDetails = scanInfo
        if UploadHelper.sharedInstance.addInspectionJobTask {
            scanDetails = scanToUploadNext
        }
        
        helperGetAppDeleate().dbWrapper.updateInspectionJobScan(scanData: scanDetails, uploadStatus: UPLOADSTATUS.ADD_INSPECTION_JOB_DONE.rawValue) {
            if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                helperGetAppDeleate().allUploadScreen.setupScanDetails()
            }
            self.checkForJobsInQueue()
        }
        
        uploadStatusDelegate?.notifyStatusChange()
    }
    
    func newPartAdded(_ results: AddPartResponse) {
        let newPartInfo : [String: Any] = [kPartName : results.partName ?? "",
                                             kPartId : results.id ?? "",
                                        kPartCustomer: results.partCustomer ?? "",
                                             kAddress: results.address ?? "",
                                             kZipCode: results.zipCode ?? "",
                                           kPartDesc : results.partDescription ?? " ",
                              kLocalPartTimeCreation : results.localPartTimeCreation ?? "",
                                    kLatestShootTime : results.localPartTimeCreation ?? ""]
        LogConfig.logD(message:"NEW Part Info AT Upload Helper 1: \(newPartInfo)",displayToThirdParty: true )
        
        helperGetAppDeleate().dbWrapper.updatePartInfoFor(partId: scanToUploadNext[kPartId] as! String, partName: newPartInfo[kPartName] as! String, newPartId: newPartInfo[kPartId] as! String,localPartTimeCreation: newPartInfo[kLocalPartTimeCreation] as! String)
        
        let part = helperGetAppDeleate().dbWrapper.getPartFromTable(withPartId: newPartInfo[kPartId] as! String)
        print("PART: \(part)")
        
        helperGetAppDeleate().dbWrapper.updatePartIdForScan(dummyPartId: scanToUploadNext[kPartId] as! String, partId: newPartInfo[kPartId] as! String)
        
        let scan = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: newPartInfo[kPartId] as! String)
        
        print("Scan: \(scan)")
        
        let scanDetail = scan[0]
        let unitId = scanDetail[kUnitId]
        
        scanInfo = UserDefaults.standard.value(forKey: unitId as! String) as! [String : Any]
        scanInfo[kPartDetails] = part
        scanInfo[kScanDetails] = scan
        UserDefaults.standard.set(scanInfo, forKey: unitId as! String)

        
//        if (scanToUploadNext[kPartId] as? String != nil) {
//
//        } else {
//            if let partDetails = scanToUploadNext[kPartDetails] as? [String : Any] {
//                if (partDetails[kPartId] as? String != nil) {
//                    helperGetAppDeleate().dbWrapper.updatePartIdForScan(dummyPartId: partDetails[kPartId] as! String, partId: newPartInfo[kPartId] as! String)
//                    //                    if helperGetAppDeleate().navigation.viewControllers.contains(helperGetAppDeleate().allScans) {
//                    //                        if helperGetAppDeleate().allScans.partDetails[kPartId] as! String == partDetails[kPartId] as! String {
//                    //                            helperGetAppDeleate().allScans.partDetails[kPartId] = newPartInfo[kPartId]
//                    //                        }
//                    //                    }
//                }
//            }
//        }
        
        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
            helperGetAppDeleate().allUploadScreen.setupScanDetails()
        }
        self.uploadingDummyPart = false
        self.checkForJobsInQueue()
        helperGetAppDeleate().hideActivityView()
    }
}


//server calls
extension UploadHelper{
    func callMergePart(){
        UserDefaults.standard.setValue("", forKey: kVideoUploadingStart)
        UserDefaults.standard.setValue("yes", forKey: kVideoUploadingEnd)
        
        LogConfig.logD(message:"POINT C - callMergePart", displayToThirdParty: true)
        var dict = UserDefaults.standard.value(forKey: kMergePartUnitDict) as! [String : Any]
        dict[kUploadTime] = self.uploadTimeStr
        var requestId = helperGetCurrentTimeStamp()
        let scanList = helperGetAppDeleate().dbWrapper.getScanByUnitName(unitName: dict["unitName"] as! String)
        if scanList.count > 0{
            let scanObj = scanList[0]
            if let savedRequestId = scanObj[kRequestId] as? String, savedRequestId != "" {
                requestId = savedRequestId
            }else{
                helperGetAppDeleate().dbWrapper.updateRequestId(forUnitName: scanObj["unitName"] as! String,requestId: requestId)
            }
        }
        dict[kRequestId]  = requestId
        APIClient.delegate = self
        if helperGetAppDeleate().allUploadScreen.currentScreen == .uploadScreen{
            helperGetAppDeleate().showActivityView()
        }
        APIClient.mergePart(request: dict)
    }
    
    
    func createAddInspectionDict() {
        LogConfig.logD(message:"ScanToUpload -   : \(self.scanToUploadNext)", displayToThirdParty: true)
        LogConfig.logD(message:"POINT E - create inspection job dict", displayToThirdParty: true)
        if !NetworkState.isConnected() {
            return
        }
        
        let uploadedPartDetails = UserDefaults.standard.value(forKey: kMergePartUnitDict) as! [String : Any]
        let action = str_new
        let video = UploadHelper.sharedInstance.addInspectionJobTask ? self.scanToUploadNext[kVideo] as! Bool : self.scanInfo[kVideo] as! Bool
        var videoType = false
        if video {
            videoType = true
        }else{
            videoType = false
        }
        
        var requestId = helperGetCurrentTimeStamp()
        let scanList = helperGetAppDeleate().dbWrapper.getScanByUnitName(unitName: uploadedPartDetails["unitName"] as! String)
        if scanList.count > 0{
            let scanObj = scanList[0]
            if let savedRequestId = scanObj[kRequestId] as? String, savedRequestId != "" {
                requestId = savedRequestId
            }else{
                helperGetAppDeleate().dbWrapper.updateRequestId(forUnitName: scanObj["unitName"] as! String,requestId: requestId)
            }
        }
    
        
        let inspectionJobRequest = AddInspectionJobRequest(partId: uploadedPartDetails[kPartId] as? String ?? "", action: action, source: str_app, partUnitName: uploadedPartDetails[kUnitName] as? String ?? "", video: videoType, inspectionType: str_unit,requestId: requestId)
        APIClient.delegate = self
        if helperGetAppDeleate().allUploadScreen.currentScreen == .uploadScreen{
            helperGetAppDeleate().showActivityView()
        }
        APIClient.adInspectionJob(request: inspectionJobRequest)
    }
}

extension UploadHelper {
//    func prepareAddInspectionJobs(scanList: [Dictionary<String, Any>]) {
//        print(scanList)
//        for scan in scanList {
//            if scan[kUnitId] as? String != nil {
//                let uploadingJobs = helperGetAppDeleate().dbWrapper.getUploadingJobs()
//                if (uploadingJobs.count > 0) {
//                    let uploadingScan = uploadingJobs[0]
//                    if uploadingScan[kUnitId] as! String != scan[kUnitId] as! String {
//                        helperGetAppDeleate().dbWrapper.updateUnitStatusOfScanByID(scanID: scan[kUnitId] as! String, unitStatus: str_queued) {
//                            UploadHelper.sharedInstance.checkForJobsInQueue()
//                        }
//                    }
//                }
//            }
//        }
//    }
}

