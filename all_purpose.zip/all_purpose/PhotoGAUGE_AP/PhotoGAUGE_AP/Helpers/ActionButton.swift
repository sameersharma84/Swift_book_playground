// ActionButton.swift

import UIKit

public typealias ActionButtonAction = (ActionButton) -> Void

open class ActionButton: NSObject {
    
    /// The action the button should perform when tapped
    open var action: ActionButtonAction?

    /// The button's background color : set default color and selected color
    open var backgroundColor: UIColor = UIColor(red: 238.0/255.0, green: 130.0/255.0, blue: 34.0/255.0, alpha:1.0) {
        willSet {
            floatButton.backgroundColor = newValue
            backgroundColorSelected = newValue
        }
    }
    
    /// The button's background color : set default color
    open var backgroundColorSelected: UIColor = UIColor(red: 238.0/255.0, green: 130.0/255.0, blue: 34.0/255.0, alpha:1.0)
    
    /// Indicates if the buttons is active (showing its items)
    fileprivate(set) open var active: Bool = false
    
    /// An array of items that the button will present
    internal var items: [ActionButtonItem]? {
        willSet {
            for abi in self.items! {
                abi.view.removeFromSuperview()
            }
        }
        didSet {
            placeButtonItems()
            showActive(true)
        }
    }
    
    /// The button that will be presented to the user
    fileprivate var floatButton: UIButton!
    
    /// View that will hold the placement of the button's actions
    fileprivate var contentView: UIView!
    
    /// View where the *floatButton* will be displayed
    fileprivate var parentView: UIView!
    
    /// Blur effect that will be presented when the button is active
    fileprivate var blurVisualEffect: UIVisualEffectView!
    
    // Distance between each item action
    fileprivate let itemOffset = -65
    
    /// the float button's radius
    fileprivate let floatButtonRadius = 50
    
    /// the float button's radius
    fileprivate var floatButtonWidth = 150
    
    /// the float button's radius
    fileprivate var floatButtonHeight = 70
    
    /// the float button's trailing padding
    fileprivate let floatButtonTrailingPadding: CGFloat = -25
    
    /// the float button's bottom padding
    fileprivate let floatButtonBottomPadding: CGFloat = -25
    
    fileprivate var widthConstraint: [NSLayoutConstraint] = []
    
    fileprivate var heightConstraint:[NSLayoutConstraint] = []
    
    public init(attachedToView view: UIView, items: [ActionButtonItem]?, width:Int, height:Int) {
        super.init()
        
        floatButtonWidth    = width
        floatButtonHeight   = height
        
        self.parentView = view
        self.items = items
        let bounds = self.parentView.bounds
        
        self.floatButton = UIButton(type: .custom)
       // self.floatButton.layer.cornerRadius = CGFloat(floatButtonRadius / 2)
        self.floatButton.layer.shadowOpacity = 1
        self.floatButton.layer.shadowRadius = 2
        self.floatButton.layer.shadowOffset = CGSize(width: 1, height: 1)
        self.floatButton.layer.shadowColor = UIColor.gray.cgColor
        self.floatButton.setTitle("+", for: UIControl.State())
        self.floatButton.setImage(UIImage.init(named: "Camera"), for: UIControl.State())
        self.floatButton.backgroundColor = self.backgroundColor
        self.floatButton.titleLabel!.font = UIFont(name: "HelveticaNeue-Light", size: 35)
        self.floatButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 8, right: 0)
        self.floatButton.isUserInteractionEnabled = true
        self.floatButton.translatesAutoresizingMaskIntoConstraints = false
        
        self.floatButton.addTarget(self, action: #selector(ActionButton.buttonTapped(_:)), for: .touchUpInside)
        self.floatButton.addTarget(self, action: #selector(ActionButton.buttonTouchDown(_:)), for: .touchDown)
        self.parentView.addSubview(self.floatButton)

        self.contentView = UIView(frame: bounds)
        self.contentView.backgroundColor = .clear
        //self.parentView.backgroundColor = .yellow
        self.blurVisualEffect = UIVisualEffectView(effect: UIBlurEffect(style: .regular))
        self.blurVisualEffect.frame = self.contentView.frame
        //self.contentView.addSubview(self.blurVisualEffect)
        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        //self.blurVisualEffect.translatesAutoresizingMaskIntoConstraints = false
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(ActionButton.backgroundTapped(_:)))
        self.contentView.addGestureRecognizer(tap)
        
        self.installConstraints()
    }
    
    func hideAndShowActionButton(hidden:Bool) {
        floatButton.isHidden = hidden
    }
    
    required public init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Set Methods
    open func setTitle(_ title: String?, forState state: UIControl.State) {
        floatButton.setImage(nil, for: state)
        floatButton.setTitle(title, for: state)
        floatButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 8, right: 0)
    }
    
    open func setImage(_ image: UIImage?, forState state: UIControl.State) {
        setTitle(nil, forState: state)
        floatButton.setImage(image, for: state)
        floatButton.adjustsImageWhenHighlighted = false
        floatButton.contentEdgeInsets = UIEdgeInsets.zero
    }
    
    //MARK: - Auto Layout Methods
    /**
        Install all the necessary constraints for the button. By the default the button will be placed at 15pts from the bottom and the 15pts from the right of its *parentView*
    */
    fileprivate func installConstraints() {
        let views: [String: UIView] = ["floatButton":self.floatButton, "parentView":self.parentView]
        widthConstraint = NSLayoutConstraint.constraints(withVisualFormat: "H:[floatButton(\(floatButtonWidth))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
        heightConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:[floatButton(\(floatButtonHeight))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
        self.floatButton.addConstraints(widthConstraint)
        self.floatButton.addConstraints(heightConstraint)
        
        //safeAreaLayoutGuide issue
        if #available(iOS 11.0, *) {
            let guide = self.parentView.safeAreaLayoutGuide
            self.floatButton.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: (floatButtonTrailingPadding)).isActive = true
            self.floatButton.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: floatButtonBottomPadding).isActive = true
        }
        else {
            let trailingSpacing = NSLayoutConstraint.constraints(withVisualFormat: "V:[floatButton]-\(floatButtonTrailingPadding)-|", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
            let bottomSpacing = NSLayoutConstraint.constraints(withVisualFormat: "H:[floatButton]-\(floatButtonBottomPadding)-|", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
            self.parentView.addConstraints(trailingSpacing)
            self.parentView.addConstraints(bottomSpacing)
        }
    }
    
    //MARK: - Button Actions Methods
    @objc func buttonTapped(_ sender: UIControl) {
        animatePressingWithScale(1.0)
        
        if let unwrappedAction = self.action {
            unwrappedAction(self)
        }
    }
    
    @objc func buttonTouchDown(_ sender: UIButton) {
        animatePressingWithScale(0.9)
    }
    
    //MARK: - Gesture Recognizer Methods
    @objc func backgroundTapped(_ gesture: UIGestureRecognizer) {
        if self.active {
            self.toggle()
        }
    }
    
    //MARK: - Custom Methods
    /**
        Presents or hides all the ActionButton's actions
    */
    open func toggleMenu() {
        self.placeButtonItems()
        self.toggle()
    }
    
    //MARK: - Action Button Items Placement
    /**
        Defines the position of all the ActionButton's actions
    */
    fileprivate func placeButtonItems() {
        if let optionalItems = self.items {
            for item in optionalItems {
                item.view.center = CGPoint(x: self.floatButton.center.x - 83, y: self.floatButton.center.y)
                item.view.removeFromSuperview()
                
                self.contentView.addSubview(item.view)
                item.view.translatesAutoresizingMaskIntoConstraints = false
                
                if #available(iOS 11.0, *) {
                    let guide = self.contentView.safeAreaLayoutGuide
                    item.view.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: (floatButtonTrailingPadding)).isActive = true
                    item.view.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: floatButtonBottomPadding).isActive = true
                }
                else {
                    item.view.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: (floatButtonTrailingPadding)).isActive = true
                    item.view.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: floatButtonBottomPadding).isActive = true
                }
                
                item.view.widthAnchor.constraint(equalToConstant: 200).isActive = true
                item.view.heightAnchor.constraint(equalToConstant: 50).isActive = true
            }
        }
    }
    
    //MARK - Float Menu Methods
    /**
        Presents or hides all the ActionButton's actions and changes the *active* state
    */
    fileprivate func toggle() {
        self.animateMenu()
        self.showBlur()
        
        self.active = !self.active
        self.floatButton.backgroundColor = self.active ? backgroundColorSelected : backgroundColor
        self.floatButton.isSelected = self.active
        
        
        floatButton.removeConstraints(widthConstraint)
        floatButton.removeConstraints(heightConstraint)
        if self.active {
            self.setImage(UIImage.init(named: "floating_btn_Cross"), forState: .normal)
            let views: [String: UIView] = ["floatButton":self.floatButton, "parentView":self.parentView]
            widthConstraint = NSLayoutConstraint.constraints(withVisualFormat: "H:[floatButton(\(70))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
            heightConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:[floatButton(\(70))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
            self.floatButton.addConstraints(widthConstraint)
            self.floatButton.addConstraints(heightConstraint)
        }else{
            
            if floatButtonWidth == 70 {
                self.setImage(UIImage.init(named: "floating_btn_camera"), forState: .normal)
            }else{
                self.setImage(UIImage.init(named: "Camera transition"), forState: .normal)
            }
            
            let views: [String: UIView] = ["floatButton":self.floatButton, "parentView":self.parentView]
            widthConstraint = NSLayoutConstraint.constraints(withVisualFormat: "H:[floatButton(\(floatButtonWidth))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
            heightConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:[floatButton(\(floatButtonHeight))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
            self.floatButton.addConstraints(widthConstraint)
            self.floatButton.addConstraints(heightConstraint)
        }
    }
    func updateHeight(width:Int,height:Int) {
        floatButtonWidth = width
        floatButtonHeight = height
        
        floatButton.removeConstraints(widthConstraint)
        floatButton.removeConstraints(heightConstraint)
        if floatButtonWidth == 70 {
            self.setImage(UIImage.init(named: "floating_btn_camera"), forState: .normal)
        }else{
            self.setImage(UIImage.init(named: "Camera transition"), forState: .normal)
        }
        
        let views: [String: UIView] = ["floatButton":self.floatButton, "parentView":self.parentView]
        widthConstraint = NSLayoutConstraint.constraints(withVisualFormat: "H:[floatButton(\(floatButtonWidth))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
        heightConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:[floatButton(\(floatButtonHeight))]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views)
        self.floatButton.addConstraints(widthConstraint)
        self.floatButton.addConstraints(heightConstraint)
    }
    
    fileprivate func animateMenu() {
        let rotation = self.active ? 0 : CGFloat(Double.pi / 4)
        
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.1, options: UIView.AnimationOptions.allowAnimatedContent, animations: {
            
            if self.floatButton.imageView?.image == nil {
                self.floatButton.transform = CGAffineTransform(rotationAngle: rotation)
            }
    
            self.showActive(false)
        }, completion: {completed in
            if self.active == false {
                self.hideBlur()
            }
        })
    }
    
    fileprivate func showActive(_ active: Bool) {
        if self.active == active {
            self.contentView.alpha = 1.0
            
            if let optionalItems = self.items {
                for (index, item) in optionalItems.enumerated() {
                    let offset = index + 1
                    let translation = self.itemOffset * offset
                    item.view.transform = CGAffineTransform(translationX: 0, y: CGFloat(translation))
                    item.view.alpha = 1
                }
            }
        } else {
            self.contentView.alpha = 0.0
            
            if let optionalItems = self.items {
                for item in optionalItems {
                    item.view.transform = CGAffineTransform(translationX: 0, y: 0)
                    item.view.alpha = 0
                }
            }
        }
    }
    
    fileprivate func showBlur() {
        self.parentView.insertSubview(self.contentView, belowSubview: self.floatButton)
        self.contentView.trailingAnchor.constraint(equalTo: self.parentView.trailingAnchor).isActive = true
        self.contentView.bottomAnchor.constraint(equalTo: self.parentView.bottomAnchor).isActive = true
        self.contentView.topAnchor.constraint(equalTo: self.parentView.topAnchor).isActive = true
        self.contentView.leadingAnchor.constraint(equalTo: self.parentView.leadingAnchor).isActive = true
        
//        self.blurVisualEffect.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor).isActive = true
//        self.blurVisualEffect.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor).isActive = true
//        self.blurVisualEffect.topAnchor.constraint(equalTo: self.contentView.topAnchor).isActive = true
//        self.blurVisualEffect.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor).isActive = true
    }
    
    fileprivate func hideBlur() {
        self.contentView.removeFromSuperview()
    }
    
    /**
        Animates the button pressing, by the default this method just scales the button down when it's pressed and returns to its normal size when the button is no longer pressed
    
        - parameter scale: how much the button should be scaled
    */
    fileprivate func animatePressingWithScale(_ scale: CGFloat) {
        UIView.animate(withDuration: 0.2, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.1, options: UIView.AnimationOptions.allowAnimatedContent, animations: {
            self.floatButton.transform = CGAffineTransform(scaleX: scale, y: scale)
        }, completion: nil)
    }
}
