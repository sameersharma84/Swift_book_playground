//
//  CustomTextField.swift
//  PhotoGauge
//
//  Created by User on 8/8/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation
import UIKit

class CustomTextField: UITextField {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpTextField()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpTextField()
    }
    
    func setUpTextField(){
    }
}
extension UITextField {
    
    func setTFCornerRadius(){
        self.layer.cornerRadius = 5.0
        self.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        self.layer.borderWidth = 1.0
    }
}
