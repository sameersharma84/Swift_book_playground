//
//  NetStatus.swift
//  PhotoGauge
//
//  Created by Swathi Shenoy on 27/05/21.
//  Copyright © 2021 Photo Gauge. All rights reserved.
//

import Foundation
import Network

class NetStatus {
    
    // MARK: - Properties
    
    static let shared = NetStatus()
    var monitor: NWPathMonitor?
    var isMonitoring = false
    var didStartMonitoringHandler: (() -> Void)?
    var didStopMonitoringHandler: (() -> Void)?
    var netStatusChangeHandler: (() -> Void)?
    let REMOTE_URL: String = "http://captive.apple.com"
    
    var isConnected: Bool {
        guard let monitor = monitor else { return false }
        return monitor.currentPath.status == .satisfied
    }
    var isInternetAvailable: Bool = true
    
    var interfaceType: NWInterface.InterfaceType? {
        guard let monitor = monitor else { return nil }
        
        return monitor.currentPath.availableInterfaces.filter {
            monitor.currentPath.usesInterfaceType($0.type) }.first?.type
    }
    
    
    var availableInterfacesTypes: [NWInterface.InterfaceType]? {
        guard let monitor = monitor else { return nil }
        return monitor.currentPath.availableInterfaces.map { $0.type }
    }
    
    
    var isExpensive: Bool {
        return monitor?.currentPath.isExpensive ?? false
    }
    
    
    // MARK: - Init & Deinit
    private init() {}
    
    deinit {
        stopMonitoring()
    }
    
    
    // MARK: - Method Implementation
    
    func startMonitoring() {
        guard !isMonitoring else { return }
        
        monitor = NWPathMonitor()
        let queue = DispatchQueue(label: "NetStatus_Monitor")
        monitor?.start(queue: queue)
        
        monitor?.pathUpdateHandler = { _ in
            self.netStatusChangeHandler?()
//            self.pingHost(self.REMOTE_URL)
        }
        
        isMonitoring = true
        didStartMonitoringHandler?()
    }
    
    
    func stopMonitoring() {
        guard isMonitoring, let monitor = monitor else { return }
        monitor.cancel()
        self.monitor = nil
        isMonitoring = false
        didStopMonitoringHandler?()
    }
    
    func pingHost(_ fullURL: String) {
        
        if let url = URL(string: fullURL) {
            var request = URLRequest(url: url)
            request.httpMethod = "HEAD"
            
            URLSession(configuration: .default)
                .dataTask(with: request) { (_, response, error) in
                    guard error == nil else {
                        print("Internet Error:", error ?? "")
                        DispatchQueue.main.async {
                            self.isInternetAvailable = false
                            self.netStatusChangeHandler?()
                        }
                        return
                    }
                    
                    guard (response as? HTTPURLResponse)?
                            .statusCode == 200 else {
                                print("Internet Offline")
                                DispatchQueue.main.async {
                                    self.isInternetAvailable = false
                                    self.netStatusChangeHandler?()
                                }
                                return
                            }
                    
                    print("Internet Online")
                    DispatchQueue.main.async {
                        self.isInternetAvailable = true
                        self.netStatusChangeHandler?()
                    }
                }
                .resume()
        }else {
            self.netStatusChangeHandler?()
        }
    }
    
}

