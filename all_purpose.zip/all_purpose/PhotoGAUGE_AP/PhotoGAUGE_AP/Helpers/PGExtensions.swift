//
//  PGExtensions.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import UIKit
import CoreMedia

extension CMTime {
    var durationText:String {
        let totalSeconds = Int(CMTimeGetSeconds(self))
        let hours:Int = Int(totalSeconds / 3600)
        let minutes:Int = Int(totalSeconds % 3600 / 60)
        let seconds:Int = Int((totalSeconds % 3600) % 60)

        if hours > 0 {
            return String(format: "%i:%02i:%02i", hours, minutes, seconds)
        } else {
            return String(format: "%02i:%02i", minutes, seconds)
        }
    }
}
extension Encodable{
    var dictionary: [String: Any]? {
       guard let data = try? JSONEncoder().encode(self) else { return nil }
       return (try? JSONSerialization.jsonObject(with: data, options: .allowFragments)).flatMap { $0 as? [String: Any] }
     }
}

extension Notification.Name {
    static let NetworkStatusChanged = Notification.Name("NetworkStatusChangedNotification")
}

extension UIViewController {
    
    // With this extension you can access the MainViewController from the child view controllers.
    func revealViewController() -> AllUploadsViewController? {
        var viewController: UIViewController? = self
        
        if viewController != nil && viewController is AllUploadsViewController {
            return viewController! as? AllUploadsViewController
        }
        while (!(viewController is AllUploadsViewController) && viewController?.parent != nil) {
            viewController = viewController?.parent
        }
        if viewController is AllUploadsViewController {
            return viewController as? AllUploadsViewController
        }
        return nil
    }
}

extension UIButton {
    func buttonSize(iconName: String, widthConstraints: NSLayoutConstraint) {
//        self.backgroundColor = UIColor(red: 0, green: 118/255, blue: 254/255, alpha: 1)
        
        if iconName.count > 0 {
            self.backgroundColor = Color.themeBlueColor
            self.setTitleColor(.white, for: .normal)
            self.borderColor = .clear
            self.setImage(UIImage(named: iconName), for: .normal)
            self.setImage(UIImage(named: iconName), for: .highlighted)
            let imageWidth = self.imageView!.frame.width
            let textWidth =  (self.title(for: .normal))!.size(withAttributes:[NSAttributedString.Key.font:self.titleLabel!.font!]).width
            let width = textWidth + imageWidth + 32
            widthConstraints.constant = width
        } else {
            self.backgroundColor = .white
            self.setTitleColor(Color.themeGreyColor, for: .normal)
            self.borderColor = Color.themeGreyColor
            self.setImage(nil, for: .normal)
            self.setImage(nil, for: .highlighted)
            let textWidth = (self.title(for: .normal))!.size(withAttributes:[NSAttributedString.Key.font:self.titleLabel!.font!]).width
            let width = textWidth + 32
            widthConstraints.constant = width
        }
        self.sizeToFit()
        self.layoutIfNeeded()
    }
}
