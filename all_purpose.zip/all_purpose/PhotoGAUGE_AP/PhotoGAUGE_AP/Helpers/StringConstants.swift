//
//  StringConstants.swift
//  PhotoGauge
//
//  Created by apple on 04/08/20.
//  Copyright © 2020 Photo Gauge. All rights reserved.
//

import Foundation


let str_no_network_connection = "No Network connection"
let str_done = "Done"
let str_ok = "Ok"
let str_cancel = "Cancel"
let str_Cancel = "CANCEL"
let str_exit = "Exit"
let str_s3BucketName = "photogauge-company-accounts"
let str_s3ProdBucketName = "prod-photogauge-company-accounts"

//LOGIN
let str_invalid_email = "Invalid Email"
let str_please_enter_email = "Please enter email"
let str_please_enter_password = "Please enter password"
let str_account_created_success = "Your account has been created. An email has been sent to activate your new account"
let str_measurements = "Measurements"
let str_digital_twin = "Digital Twin"
let str_3d_model = "3D Model"

//SIGN UP
let str_please_confirm_enter_password = "Please confirm enter password"
let str_password_confirm_password_not_match = "Password and Confirm password doest not match"
let str_signup_sucess = "SignUp successfully"

//Database
let str_parts = "parts"
let str_queued = "Queued"
let str_uploading = "Uploading"
let str_uploaded = "Uploading"
let str_updating = "Updating"
let str_waiting_for_upload = "Waiting for upload"
let str_cancelled = "Cancelled"
let str_paused = "Paused"
let str_retry_upload = "Retry Upload"
let str_fail = "Fail"
let str_reconst_fail = "Reconstruction fail"
let str_pending = "pending"
let str_pending_caps = "Pending"
let str_phone = "phone"
let str_Uploaded = "Uploaded"

//Uploading
let str_new_scan = "new-scan"
let str_re_scan = "Rescan"
let str_re = "RE"
let str_up = "UP"
let str_new = "NEW"
let str_update_scan = "update-scan"
let str_unit = "unit"
let str_low = "low"
let str_high = "medium"
let str_app = "app"
let str_scan_uploaded_successfully = "Video uploaded successfully"
let str_upload_is_queued = "Your upload is queued as another upload is in progress"
let str_generic_phone = "Generic_Phone"
let str_iPhone = "iPhone"
let str_false = "false"
let str_image = "image"
let str_auto1 = "Auto1"
let str_profile_pic_path = "profilePic/profilePic.jpg"
let str_none = "none"
let str_red = "red"
let str_blue = "blue"
let str_green = "green"
let str_bg_none = "none"
let str_bg_red = "red"
let str_bg_blue = "blue"
let str_bg_green = "green"
let str_Yes = "Yes"
let str_No = "No"
let str_choose_bg = "Choose Background"
let str_go_online = "GO ONLINE"
let str_go_online_mode = "Do you want to go to online mode?"
let str_do_you_want_to_cancel_current_shoot = "Do you want to cancel the current shoot?"
let str_delete_confirmation_text = "Are you sure you want to delete this record?"
let str_do_you_want_to_exit_from_texture_assessment = "Do you want to exit from texture assessment?"
let str_texture_assessment_exit_info = "This is texture assessment screen. Press 'Exit' to reach shoot screen"
let str_texture_assessment_screen = "This is texture assessment screen"
let str_choose_option = "Choose Option"
let str_choose_mode = "Choose mode"
let str_photo = "photo"
let str_video = "video"

let str_please_capture_more_than_one_photo = "Please capture more than one photo"
let str_unit_name_exists = "Unit name already exists"
let str_server_error_msg = "Request failed, server error"

let str_point_one = "0.1"
let str_point_two = "0.2"
let str_point_three = "0.3"
let str_point_four = "0.4"
let str_point_five = "0.5"
let str_point_six = "0.6"
let str_point_seven = "0.7"
let str_point_eight = "0.8"
let str_point_nine = "0.9"
let str_one = "1.0"

//Settings
let str_change_password = "Change Password"
let str_check_updates = "Check for Updates"
let str_app_guidelines = "App guidelines"
let str_send_debug_info = "Send Debug Info"
let str_download_pdf = "Download PhotoGAUGE Target"
let str_help_faq = "Help & FAQ"
let str_about = "About"
let str_logout = "Logout"

//change password
let str_newpass_confirmpass_should_be_same = "New password and Confirm password should be same"
let str_please_enter_current_password = "Please enter current password"
let str_please_enter_new_password = "Please enter new password"
let str_offline_upload_alert = "You are in offline mode. Upload feature is only available in online mode"
let str_please_enter_confirm_password = "Please enter confirm password"

//addLabel
let str_please_enter_video_name = "Please enter video name"
let str_please_enter_video_description = "Please enter additional details"


let str_no_record_found_while_search = "Please make sure you've typed the correct term and then try again."
let str_no_record_found_while_filter = "Please try with a different filter."
let str_processing_upload = "Processing Uploads"
