//
//  UIImageViewExtension.swift
//  Demo App
//
//  Created by Swathi on 10/05/21.
//

import Foundation
import UIKit

extension UIImageView {
    func loadImage(at photoKey: String) {
        self.showLoading()
        UIImageLoader.loader.load(photoKey, for: self, completion: { success in
            self.stopLoading()
        })
    }

    func cancelImageLoad() {
        self.stopLoading()
        UIImageLoader.loader.cancel(for: self)
    }
}
