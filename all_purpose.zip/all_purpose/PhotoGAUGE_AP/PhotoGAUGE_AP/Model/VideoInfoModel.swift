//
//  VideoInfoModel.swift
//  PhotoGAUGE for Doors
//
//  Created by apple on 10/10/22.
//

import Foundation

struct VideoInfoModel : Codable{
    
    let dateStrToSave,videoLink,customAlbumName : String!
    let fileName,newFileURLStr : String!
    let videoSize : Int64!
    let timeStampArr : [String]!
    let videoTimeElapased : Int!
    var isVideoUploaded : Bool = false
}
