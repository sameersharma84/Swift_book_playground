//
//  Login.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation

struct LoginRequest: Codable{
    var loginId = ""
    var timezone = ""
    var password = ""
    var deviceUUID = ""
}

struct LoginResponse: Codable {
    let accountEmail, planEndDate: String
    let superUser: Bool
    let authToken, roleID: String
    let accountUID, userType: String
    let accountName, lastName, companyName, firstName: String
    let trial: Bool
    let accountType: String
    let daysLeft: Int
    let partCount : Int
    let refreshToken, companyUID: String
    let authTokenExpiry: Double
    let contactNumber: String?
    //    let manualReport: Bool
    //showAllParts: Bool
    //    let refreshTokenExpiry: Int
    //    let roleName, userID: String?
    enum CodingKeys: String, CodingKey {
        case accountEmail, planEndDate, superUser, authToken
        case roleID = "roleId"
        case accountUID = "accountUId"
//        case userID = "userId"
        case userType, accountName, lastName, companyName, firstName, trial, accountType, daysLeft, refreshToken,partCount
        case companyUID = "companyUId"
        case authTokenExpiry, contactNumber
    }
}

