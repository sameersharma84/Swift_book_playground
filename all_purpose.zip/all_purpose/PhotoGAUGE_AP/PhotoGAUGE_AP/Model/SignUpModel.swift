//
//  SignUpModel.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 18/05/22.
//

import Foundation


struct SignUpRequest: Codable{
    var loginId = ""
    var timezone = ""
    var password = ""
    var deviceUUID = ""
}


struct SignUpResponse: Codable {
    let code, message: String
}
