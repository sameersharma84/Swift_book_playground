//
//  File.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 10/12/21.
//

import Foundation

//MARK: DummyModels
struct Uploads{
    var name: String?
    var type: String?
    var duration: String?
    var thumbnail: String?
    var status: UploadStatus?
}

struct VideoData{
    var name: String?
    var additionalDescription: String?
}

enum UploadStatus: String{
    case Uploaded = "Uploaded"
    case Uploading = "Uploading"
    case Failed = "Failed"
}

// MARK: - AddPartRequest
struct AddPartRequest: Codable{
    var partName: String
    var zipCode: String
    var partCustomer: String
    var address: String
    var partTypeName = "" // not sending part type as server will configure it by itself for AllPurpose
    var partCategoryName = "scan"
    var partReconstruction = "medium"
    var localPartTimeCreation: String
    var partDescription: String = ""
}

// MARK: - RenamePartRequest
struct RenamePartRequest: Codable{
    var id: String
    var partName: String
    var partCategoryName = "scan"
    var partTypeName = ""
    var partReconstruction = "medium"
    var localPartTimeCreation: String
}

struct RenamePartResponse: Codable {
    let id: String?
    let partDescription: String?
    let partCustomer: String?
    let partType: PartType?
    let address, zipCode, localPartTimeCreation: String?
    let partName: String?
}


// MARK: - AddPartResponse
struct AddPartResponse: Codable {
//    let tiePoints: Int?
    let id: String?
//    let scaling: Bool?
    let partDescription: String?
//    let length: Int?
//    let runCreateTexture, runCreateMask, runSegmentation: Bool?
//    let measureUnit: String?
//    let useCustomScript, boundingBox, runMetrology, manualSTL: Bool?
//    let meshQuality: String?
//    let manualReport, excelFile: Bool?
    let partCustomer: String?
//    let useManualMask, optimizeMarkers: Bool?
    let partType: PartType?
//    let reconstructionTool: String?
//    let buildDepthMap: Bool?
//    let chiOptimizationDXO: String?
//    let partCategory: PartCategory?
//    let partSerialNumber: String?
//    let chiOptimizationFlag, useAustralis: Bool?
//    let deviceType, partCategoryName: String?
//    let manualOBJ: Bool?
//    let action, chiOptimizationPhone, partSetupStatus: String?
//    let keyPoints: Int?
//    let partReconstruction, denseMasks: String?
//    let reprojectionThreshold: Double?
//    let runInterpolation: Bool?
//    let breadth: Int?
//    let buildDenseCloud: Bool?
//    let scriptLevel, channelFlag: String?
//    let triad, groundTruth: Bool?
    let address, zipCode, localPartTimeCreation: String?
//    let fps: Int?
//    let runPhotoScan: Bool?
//    let height: Int?
//    let useMaskInDenseCloud: Bool?
    let partName: String?
    
}

// MARK: - PartCategory
struct PartCategory: Codable {
    let id, categoryName: String?
}

// MARK: - PartType
struct PartType: Codable {
    let typeName: String?
}

// MARK: - MergePartRequest
struct MergePartRequest: Codable {
    let roomType: ObjectTypeClass
    let pixelSize: Int
    let objectType: ObjectTypeClass
    let turntableStatus, runPhotoScan: Bool
    let locationLat: Double
    let runCreateMask: Int
    let videoQuality: String
    let calibrationScan: Bool
    let objectPosition: String
    let shootTime, partReconstruction: String
    let video: Bool
    let unitSold: Int
    let type, localShootTimeStr, channelFlag: String
    let folders: [Folder]
    let action: String
    let locationLng: Double
    let unitName, displayName: String
    let scan, runMetrology: Bool
    let partId, deviceType, deviceSerialNo, appVersion: String
    let uploadTime, localShootTime, notes: String
    let videoFpd: Int
    let useAustralis: Bool
    
    
}

// MARK: - Folder
struct Folder: Codable {
    let unitFiles: [UnitFile]
    let folderName: String
}

// MARK: - UnitFile
struct UnitFile: Codable {
    let fileName, fileType: String
    let fileHeight: Int
    let masked, fileOriginalName: String
    let fileWidth: Int
}

// MARK: - ObjectTypeClass
struct ObjectTypeClass: Codable {
    let type, name, code: String?
}

// MARK: - MergePartResponse
struct MergePartResponse: Codable {
    let code: Code?
    let message: String?
    let unitId: String?
}
// MARK: - AddInspectionJobRequest
struct AddInspectionJobRequest: Codable {
    let partId, action, source: String
    let partUnitName: String
    let video: Bool
    let inspectionType: String
    let requestId: String
    
}

// MARK: - AddInspectionJobResponse
struct AddInspectionJobResponse: Codable{
    let code: Code?
    let message: String?
}

// MARK: - Part
struct AllPartData: Codable {
    let partsData: [PartsDatum]?
    let etagId: String?
}

// MARK: - PartsDatum
struct PartsDatum: Codable {
   
//    let unitsDataArrangedByRoomType: UnitsDataArrangedByRoomType?
//    let partFps: Int?
    //    let excelDownload: Bool?
    //    let deleted: Bool?
    //    let partCategoryName: String?
    //    let soldWindows, : Int?
    //    let partCreatedBy: String?
    //    let totalWindows: Int?
    //    let unitSold: Bool?
    //    let resultsCount: Int?
    //    let sharpnessAssessment: Bool?
    let address: String?
    let zipCode: String?
    let locationLng: Double?
    let partCreatedOn: String?
    let unitCount: Int?
    let partId: String?
    let locationLat: Double?
    let video: Bool?
    let partCustomer: String?
    let partName: String?
    let scanCount, photosCount: Int?
   let profilePic: String?
    let unitsData: [UnitsDatum]?
    let localPartTimeCreation: String?
    let partDesc: String?
    
    
    // MARK: - UnitsDatum
    struct UnitsDatum: Codable {
        let parentScanId, unitName: String?
        let  unitDisplayName: String?
        let unitId: String?
        let unitCreatedOn: String?
        let photosCount: Int?
        let subUnits: [SubUnit]?
//        let unitUpdatedOn,orderStatus: String?
//        let locationLng: Double?
        
//        let revisionCount: Int?
//        let locationLat: Double?
//        let videoName: String?
//        let videoQuality: String?
//        let video: Bool?
//        let videoFps: Int?
       
//        let fps: Int?
//        let objectPosition: String?
       
//        let roomType: ObjectTypeClass?
//        let unitNotes: String?
//        let shootTime: Int?
//        let unitSold: Bool?
//        let objectType: ObjectTypeClass?
       
//        let sharpnessAssessment: Bool?
    }
    
    // MARK: - SubUnit
    struct SubUnit: Codable {
        let parentScanId, unitName: String?
        let orderStatus: String?
        let locationLng: Double?
        let unitDisplayName: String?
        let deviceType: String?
        let locationLat: Double?
        let video: Bool?
        let videoFps: Int?
        let unitId: String?
        let videoQuality: String?
        let unitCreatedOn: String?
        let photosCount: Int?
        let localShootTime: String?
        let shootTime: Int?
        let unitStatus: String?
        let localShootTimeStr: String?
        let appSelectionType: String?
        let jobIds: [String]?
        let jobNames: [String]?
        let jobStatus: [String]?
        let tinyUrl: String?
//        let revisionCount: Int?
//        let action, unitUpdatedOn: String?
//        let videoName: String?
//        let fps: Int?
//        let inspectorName: String?
//        let objectPosition: String?
//        let roomType: ObjectTypeClass?
//        let unitDetails: [String]?
//        let unitNotes: String?
//        let unitSold: Bool?
//        let objectType: ObjectTypeClass?
//        let appDisplayStatus: String?
//        let sharpnessAssessment: Bool?
    }
 
    
    // MARK: - Encode/decode helpers
    
    class JSONNull: Codable, Hashable {
        
        public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
            return true
        }
        
        public var hashValue: Int {
            return 0
        }
        
        public init() {}
        
        public required init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            if !container.decodeNil() {
                throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
            }
        }
        
        public func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            try container.encodeNil()
        }
    }
    
    class JSONCodingKey: CodingKey {
        let key: String
        
        required init?(intValue: Int) {
            return nil
        }
        
        required init?(stringValue: String) {
            key = stringValue
        }
        
        var intValue: Int? {
            return nil
        }
        
        var stringValue: String {
            return key
        }
    }
    
    class JSONAny: Codable {
        
        let value: Any
        
        static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
            let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
            return DecodingError.typeMismatch(JSONAny.self, context)
        }
        
        static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
            let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
            return EncodingError.invalidValue(value, context)
        }
        
        static func decode(from container: SingleValueDecodingContainer) throws -> Any {
            if let value = try? container.decode(Bool.self) {
                return value
            }
            if let value = try? container.decode(Int64.self) {
                return value
            }
            if let value = try? container.decode(Double.self) {
                return value
            }
            if let value = try? container.decode(String.self) {
                return value
            }
            if container.decodeNil() {
                return JSONNull()
            }
            throw decodingError(forCodingPath: container.codingPath)
        }
        
        static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
            if let value = try? container.decode(Bool.self) {
                return value
            }
            if let value = try? container.decode(Int64.self) {
                return value
            }
            if let value = try? container.decode(Double.self) {
                return value
            }
            if let value = try? container.decode(String.self) {
                return value
            }
            if let value = try? container.decodeNil() {
                if value {
                    return JSONNull()
                }
            }
            if var container = try? container.nestedUnkeyedContainer() {
                return try decodeArray(from: &container)
            }
            if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
                return try decodeDictionary(from: &container)
            }
            throw decodingError(forCodingPath: container.codingPath)
        }
        
        static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
            if let value = try? container.decode(Bool.self, forKey: key) {
                return value
            }
            if let value = try? container.decode(Int64.self, forKey: key) {
                return value
            }
            if let value = try? container.decode(Double.self, forKey: key) {
                return value
            }
            if let value = try? container.decode(String.self, forKey: key) {
                return value
            }
            if let value = try? container.decodeNil(forKey: key) {
                if value {
                    return JSONNull()
                }
            }
            if var container = try? container.nestedUnkeyedContainer(forKey: key) {
                return try decodeArray(from: &container)
            }
            if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
                return try decodeDictionary(from: &container)
            }
            throw decodingError(forCodingPath: container.codingPath)
        }
        
        static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
            var arr: [Any] = []
            while !container.isAtEnd {
                let value = try decode(from: &container)
                arr.append(value)
            }
            return arr
        }
        
        static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
            var dict = [String: Any]()
            for key in container.allKeys {
                let value = try decode(from: &container, forKey: key)
                dict[key.stringValue] = value
            }
            return dict
        }
        
        static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
            for value in array {
                if let value = value as? Bool {
                    try container.encode(value)
                } else if let value = value as? Int64 {
                    try container.encode(value)
                } else if let value = value as? Double {
                    try container.encode(value)
                } else if let value = value as? String {
                    try container.encode(value)
                } else if value is JSONNull {
                    try container.encodeNil()
                } else if let value = value as? [Any] {
                    var container = container.nestedUnkeyedContainer()
                    try encode(to: &container, array: value)
                } else if let value = value as? [String: Any] {
                    var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                    try encode(to: &container, dictionary: value)
                } else {
                    throw encodingError(forValue: value, codingPath: container.codingPath)
                }
            }
        }
        
        static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
            for (key, value) in dictionary {
                let key = JSONCodingKey(stringValue: key)!
                if let value = value as? Bool {
                    try container.encode(value, forKey: key)
                } else if let value = value as? Int64 {
                    try container.encode(value, forKey: key)
                } else if let value = value as? Double {
                    try container.encode(value, forKey: key)
                } else if let value = value as? String {
                    try container.encode(value, forKey: key)
                } else if value is JSONNull {
                    try container.encodeNil(forKey: key)
                } else if let value = value as? [Any] {
                    var container = container.nestedUnkeyedContainer(forKey: key)
                    try encode(to: &container, array: value)
                } else if let value = value as? [String: Any] {
                    var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                    try encode(to: &container, dictionary: value)
                } else {
                    throw encodingError(forValue: value, codingPath: container.codingPath)
                }
            }
        }
        
        static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
            if let value = value as? Bool {
                try container.encode(value)
            } else if let value = value as? Int64 {
                try container.encode(value)
            } else if let value = value as? Double {
                try container.encode(value)
            } else if let value = value as? String {
                try container.encode(value)
            } else if value is JSONNull {
                try container.encodeNil()
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
        
        public required init(from decoder: Decoder) throws {
            if var arrayContainer = try? decoder.unkeyedContainer() {
                self.value = try JSONAny.decodeArray(from: &arrayContainer)
            } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
                self.value = try JSONAny.decodeDictionary(from: &container)
            } else {
                let container = try decoder.singleValueContainer()
                self.value = try JSONAny.decode(from: container)
            }
        }
        
        public func encode(to encoder: Encoder) throws {
            if let arr = self.value as? [Any] {
                var container = encoder.unkeyedContainer()
                try JSONAny.encode(to: &container, array: arr)
            } else if let dict = self.value as? [String: Any] {
                var container = encoder.container(keyedBy: JSONCodingKey.self)
                try JSONAny.encode(to: &container, dictionary: dict)
            } else {
                var container = encoder.singleValueContainer()
                try JSONAny.encode(to: &container, value: self.value)
            }
        }
    }
}

//code value of any type
enum Code: Codable {
    case integer(Int)
    case string(String)

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let x = try? container.decode(Int.self) {
            self = .integer(x)
            return
        }
        if let x = try? container.decode(String.self) {
            self = .string(x)
            return
        }
        throw DecodingError.typeMismatch(Code.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for Code"))
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .integer(let x):
            try container.encode(x)
        case .string(let x):
            try container.encode(x)
        }
    }
}
