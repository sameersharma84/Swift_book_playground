//
//  Password.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 31/12/21.
//

import Foundation

// MARK: - PasswordRequest
struct PasswordRequest: Codable {
    let newPassword, oldPassword: String
}

// MARK: - PasswordResponse
struct PasswordResponse: Codable {
    let message, code: String
}
