//
//  LearnMoreModel.swift
//  PhotoGAUGE_AP
//
//  Created by Ellyn on 07/06/22.
//

import UIKit

struct LearnMoreModel{
    var icon: UIImage
    var title: String
    var content: String
    var outputImage: UIImage
}
