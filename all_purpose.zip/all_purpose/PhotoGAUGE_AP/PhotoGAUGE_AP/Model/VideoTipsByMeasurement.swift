//
//  VideoTipsByMeasurement.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 13/05/22.
//

import Foundation

struct VideoTipsByMeasurement:Codable{
    let id: String
    let deleted: Bool
    let createdOn, updatedOn, createdBy, type: String
    let tipsURL: String

    enum CodingKeys: String, CodingKey {
        case id, deleted, createdOn, updatedOn, createdBy, type
        case tipsURL = "tipsUrl"
    }
}
