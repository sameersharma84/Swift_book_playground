//
//  ETag.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 12/01/22.
//

import Foundation


struct EtagResponse: Codable {
    let etagId: String?
    let partsData: [PartsDatum]?
}
