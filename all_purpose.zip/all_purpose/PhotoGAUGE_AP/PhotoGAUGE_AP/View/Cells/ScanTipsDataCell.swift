//
//  ScanTipsDataCell.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 30/05/22.
//

import UIKit

class ScanTipsDataCell: UITableViewCell {

    @IBOutlet weak var tipImage: UIImageView!
    @IBOutlet weak var tipTitle: UILabel!
    @IBOutlet weak var tipDescription: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell(scanTip:ScanTips) {
        tipImage.image = UIImage.init(named: scanTip.image)
        tipTitle.text = scanTip.title
        tipDescription.text = scanTip.descritpion
    }
    
}
