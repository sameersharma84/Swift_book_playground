//
//  UploadCell.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 10/12/21.
//

import UIKit
import SDWebImage

class UploadCell: UITableViewCell {
    
    @IBOutlet var thumbnail: UIImageView!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblType: UILabel!
    @IBOutlet var lblStatus: UILabel!
    @IBOutlet var imgStatus: UIImageView!
    var viewPartDetails: (()->())? = nil
    var reloadTableOnRename: (()->())? = nil
    var onReuse: () -> Void = {}
    @IBOutlet weak var btnOptions: UIButton!
    @IBOutlet weak var btnCross: UIButton!
    @IBOutlet weak var detailStackView: UIStackView!
    
    @IBOutlet weak var progressBarStackView: UIStackView!
    @IBOutlet weak var progressBar: UIView!
    @IBOutlet weak var progressBarLeadingCons: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    var partData: PartsDatum?{
        didSet{
            if let picture = partData?.profilePic, picture != "" {
                thumbnail.loadImage(at: picture)
            }else{
                thumbnail.image = UIImage(named: "Placeholder")
            }
            lblName.text = partData?.partName
            lblType.text = partData?.partDesc
            //            if partData?.unitsData?.count ?? 0>0{
            //                lblStatus.text = partData?.unitsData![0].orderStatus
            //            }
            //            switch pardData?.status{
            //            case .Uploaded:
            //                imgStatus.image = UIImage(systemName:"checkmark.circle.fill")
            //            case .Uploading:
            //                imgStatus.image = UIImage(systemName:"checkmark.circle.fill")
            //            case .Failed:
            //                imgStatus.image = UIImage(systemName:"exclamationmark.circle.fill")
            //            case .none:
            //                break
            //            }
        }
    }
    
    var partDict: [String: Any]?{
        didSet{
            //            if let picture = partDict?[kProfilePic] as? String, picture != ""{
            //                thumbnail.loadImage(at: picture)
            //            }else{
            //                thumbnail.image = UIImage(named: "Placeholder")
            //            }
            //            if let name = partDict?[kPartName] as? String{
            //                lblName.text = name
            //            }
        }
    }
    
    func displayActionSheet(){
        
        let optionMenu = UIAlertController(title: nil, message: str_choose_option, preferredStyle: .actionSheet)
        if lblStatus.text == str_uploading {
            let cancelUploadAction = UIAlertAction(title: "Cancel Upload", style: .default) { (action) in
                let alert = UIAlertController(title: str_cancel, message: str_do_you_want_to_cancel_current_shoot, preferredStyle: UIAlertController.Style.alert)
                let yesAction = UIAlertAction(title: str_Yes, style: .default) {  (_) in
                    LogConfig.logD(message:"Cancel Upload confirmed", displayToThirdParty: true)
                    UploadHelper.sharedInstance.cancelUpload {
                        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                            helperGetAppDeleate().allUploadScreen.setupScanDetails()
                        }
                    }
                }
                alert.addAction(UIAlertAction(title: str_No, style: .cancel, handler: nil))
                alert.addAction(yesAction)
                helperGetAppDeleate().navigation.present(alert, animated: true, completion: nil)
                LogConfig.logD(message:"cancelUploadAction clicked", displayToThirdParty: true)
            }
            
            //            let pauseUploadAction = UIAlertAction(title: "Pause", style: .default){ (action) in
            //                UploadHelper.sharedInstance.pauseUpload {
            //                    helperGetAppDeleate().allUploadScreen.setupScanDetails()
            //                }
            //                LogConfig.logD(message:"pauseUploadAction clicked")
            //            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
                LogConfig.logD(message:"Cancel clicked", displayToThirdParty: true)
            }
            
            //            optionMenu.addAction(pauseUploadAction)
            optionMenu.addAction(cancelUploadAction)
            optionMenu.addAction(cancelAction)
            helperGetAppDeleate().navigation.present(optionMenu, animated: true, completion: nil)
        }else if lblStatus.text == str_queued {
            let cancelUploadAction = UIAlertAction(title: "Cancel Upload", style: .default) { (action) in
                let alert = UIAlertController(title: str_cancel, message: str_do_you_want_to_cancel_current_shoot, preferredStyle: UIAlertController.Style.alert)
                let yesAction = UIAlertAction(title: str_Yes, style: .default) {  (_) in
                    if let partID = self.partDict?[kPartId] as? String{
                        let scans = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: partID)
                        helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scans[0], unitStatus: str_cancelled) {
                        }
                        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                            helperGetAppDeleate().allUploadScreen.setupScanDetails()
                        }
                    }
                }
                alert.addAction(UIAlertAction(title: str_No, style: .cancel, handler: nil))
                alert.addAction(yesAction)
                helperGetAppDeleate().navigation.present(alert, animated: true, completion: nil)
                LogConfig.logD(message:"cancelUploadAction clicked", displayToThirdParty: true)
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
                LogConfig.logD(message:"Cancel clicked", displayToThirdParty: true)
            }
            
            optionMenu.addAction(cancelUploadAction)
            optionMenu.addAction(cancelAction)
            helperGetAppDeleate().navigation.present(optionMenu, animated: true, completion: nil)
        } else if lblStatus.text == str_cancelled {
            let retryUploadAction = UIAlertAction(title: "Retry", style: .default) { (action) in
                LogConfig.logD(message:"retry Action clicked", displayToThirdParty: true)
                if let partID = self.partDict?[kPartId] as? String{
                    let scans = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: partID)
                    helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scans[0], unitStatus: str_queued) {
                        helperGetAppDeleate().allUploadScreen.uploadingProgressValue  = 0.005
                        UploadHelper.sharedInstance.checkForJobsInQueue()
                        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                            helperGetAppDeleate().allUploadScreen.setupScanDetails()
                        }
                    }
                    
                }
//                if UploadHelper.sharedInstance.scanType != str_update_scan {
//                    helperGetAppDeleate().navigation.pushViewController(UploadHelper.sharedInstance.uploadScreen!, animated: true)
//                } else {
//                    UploadHelper.sharedInstance.pushCopyScreen = true
//                }
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
                LogConfig.logD(message:"Cancel clicked", displayToThirdParty: true)
            }
            
            optionMenu.addAction(retryUploadAction)
            optionMenu.addAction(cancelAction)
            helperGetAppDeleate().navigation.present(optionMenu, animated: true, completion: nil)
        } else if lblStatus.text == str_paused {
            
            //            let resumeUploadAction = UIAlertAction(title: "Resume", style: .default){ (action) in
            //                helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: self.sectionData, unitStatus: str_queued) {
            //                }
            //                UploadHelper.sharedInstance.checkForJobsInQueue()
            //                helperGetAppDeleate().allUploadScreen.setupScanDetails()
            //                LogConfig.logD(message:"resumeUploadAction clicked")
            //            }
            //
            //            let cancelUploadAction = UIAlertAction(title: "Cancel Upload", style: .default) { (action) in
            //
            //                let alert = UIAlertController(title: str_cancel, message: str_do_you_want_to_cancel_current_shoot, preferredStyle: UIAlertController.Style.alert)
            //                let yesAction = UIAlertAction(title: str_Yes, style: .default) { [unowned alert] _ in
            //                    helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: self.sectionData, unitStatus: str_cancelled) {
            //                    }
            //                    helperGetAppDeleate().allUploadScreen.setupScanDetails()
            //                }
            //                alert.addAction(UIAlertAction(title: str_No, style: .cancel, handler: nil))
            //                alert.addAction(yesAction)
            //                helperGetAppDeleate().navigation.present(alert, animated: true, completion: nil)
            //                LogConfig.logD(message:"cancelUploadAction clicked")
            //            }
            //
            //            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
            //                LogConfig.logD(message:"Cancel clicked")
            //            }
            //
            //            optionMenu.addAction(resumeUploadAction)
            //            optionMenu.addAction(cancelUploadAction)
            //            optionMenu.addAction(cancelAction)
            
        } else if lblStatus.text == str_retry_upload {
            let retryUploadAction = UIAlertAction(title: "Retry Upload", style: .default) { (action) in
                if NetStatus.shared.isConnected{
                    if let partID = self.partDict?[kPartId] as? String{
                        let scans = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: partID)
                        if let scanUnitName = scans[0][kUnitName] as? String{
                            UploadHelper.sharedInstance.retryUpload(unitName: scanUnitName, callback: {
                                if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                                    helperGetAppDeleate().allUploadScreen.setupScanDetails()
                                }
                            })
                        }
                        LogConfig.logD(message:"Retry Upload clicked", displayToThirdParty: true)
                    }
                }else{
                    helperGetAppDeleate().showAlert(titleStr: helperGetAppName(), msg: "Internet is unavailable please check your network and try again")
                }
                
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
                LogConfig.logD(message:"Cancel clicked", displayToThirdParty: true)
            }
            
            optionMenu.addAction(retryUploadAction)
            optionMenu.addAction(cancelAction)
            helperGetAppDeleate().navigation.present(optionMenu, animated: true, completion: nil)
        } else {
            helperGetAppDeleate().allUploadScreen.isUserInteractingWithMyUplodsPageFunctionalities = true
            let renamePartAction = UIAlertAction(title: "Rename Part", style: .default){ (action) in
                LogConfig.logD(message:"Rename Part clicked", displayToThirdParty: true)
                let ac = UIAlertController(title: "Rename part", message: nil, preferredStyle: .alert)
                ac.addTextField { (textField) in
                    textField.text = (self.partDict?[kPartName] as! String)
                }

                let submitAction = UIAlertAction(title: "Rename", style: .default) { [unowned ac] _ in
                    let answer = ac.textFields![0].text
                    if !NetworkState.isConnected() {
                        helperGetAppDeleate().allUploadScreen.isUserInteractingWithMyUplodsPageFunctionalities = false
                        return
                    } else {
                        let renamePartRequest = RenamePartRequest(id: self.partDict?[kPartId] as? String ?? "" , partName: answer ?? "", localPartTimeCreation: self.partDict?[kLocalPartTimeCreation] as? String ?? "")
                        
                        APIClient.delegate = self
                        helperGetAppDeleate().showActivityView()
                        APIClient.renamePart(request: renamePartRequest)
                    }
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ _ in
                    debugPrint("Rename Cancelled")
                    helperGetAppDeleate().allUploadScreen.isUserInteractingWithMyUplodsPageFunctionalities = false
                }

                ac.addAction(submitAction)
                ac.addAction(cancelAction)

                helperGetAppDeleate().navigation.present(ac, animated: true, completion: nil)
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
                LogConfig.logD(message:"Cancel clicked", displayToThirdParty: true)
            }

            optionMenu.addAction(renamePartAction)
            optionMenu.addAction(cancelAction)
            helperGetAppDeleate().navigation.present(optionMenu, animated: true, completion: nil)
        }
    }
    
    @IBAction func optionsMenuClicked(_ sender: Any){
        displayActionSheet()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        onReuse()
        thumbnail.image = nil
        thumbnail.cancelImageLoad()
    }
    
    @IBAction func onClickCancelUpload(_ sender: Any) {
        let alert = UIAlertController(title: str_cancel, message: str_do_you_want_to_cancel_current_shoot, preferredStyle: UIAlertController.Style.alert)
        let yesAction = UIAlertAction(title: str_Yes, style: .default) { (_) in
            if let partID = self.partDict?[kPartId] as? String{
                if self.lblStatus.text == str_uploading {
                    UploadHelper.sharedInstance.cancelUpload {
                        UserDefaults.standard.setValue("yes", forKey: kVideoUploadingEnd)
                        if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                            helperGetAppDeleate().allUploadScreen.setupScanDetails()
                        }
                    }
                }else if self.lblStatus.text == str_queued {
                    let scans = helperGetAppDeleate().dbWrapper.getScansForPartFromTable(partID: partID)
                        helperGetAppDeleate().dbWrapper.updateUnitStatusOfScan(scanData: scans[0], unitStatus: str_cancelled) {
                    }
                    UserDefaults.standard.setValue("yes", forKey: kVideoUploadingEnd)
                    if helperGetAppDeleate().allUploadScreen.currentScreen == .allUploadScreen {
                        helperGetAppDeleate().allUploadScreen.setupScanDetails()
                    }
                }
            }
        }
        alert.addAction(UIAlertAction(title: str_No, style: .cancel, handler: nil))
        alert.addAction(yesAction)
        helperGetAppDeleate().navigation.present(alert, animated: true, completion: nil)
        LogConfig.logD(message:"cancelUploadAction clicked", displayToThirdParty: true)
        
    }
    
}


extension UploadCell: ServerWrapperDelegate{
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse) {
        helperGetAppDeleate().allUploadScreen.isUserInteractingWithMyUplodsPageFunctionalities = false
    }
    
    func partRenamed(_ results: RenamePartResponse) {
        
        if results.id == partDict?[kPartId] as? String {
            partDict?[kPartName] = results.partName
            helperGetAppDeleate().dbWrapper.updatePartNameFor(partId: results.id ?? "", partName: results.partName ?? "")
            self.lblName.text = results.partName
            self.reloadTableOnRename!()
            
        }
        LogConfig.logD(message:"Part renamed!! - Allscan , \(results)", displayToThirdParty: true)
        helperGetAppDeleate().hideActivityView()
        helperGetAppDeleate().allUploadScreen.isUserInteractingWithMyUplodsPageFunctionalities = false
    }
}
