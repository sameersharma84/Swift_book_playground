//
//  ScanTipsScreenPagerCell.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 30/05/22.
//

import UIKit

struct ScanTips{
    let image : String!
    let title : String!
    let descritpion: String!
}


class ScanTipsScreenPagerCell: UICollectionViewCell {

    @IBOutlet weak var tblScanTips: UITableView!
    var arrScanTips  : [ScanTips] = []
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        tblScanTips.dataSource = self
        tblScanTips.delegate = self
        tblScanTips.register(UINib.init(nibName: "ScanTipsDataCell", bundle: nil), forCellReuseIdentifier: "ScanTipsDataCell")
    }
    
    func setupCellWtihData(arrData:[ScanTips]) {
        arrScanTips = arrData
        tblScanTips.reloadData()
    }
    
}

extension ScanTipsScreenPagerCell : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScanTipsDataCell", for: indexPath) as! ScanTipsDataCell
        cell.configureCell(scanTip: arrScanTips[indexPath.row])
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrScanTips.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    
}
