//
//  NetworkReponse.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation
import Alamofire
struct NetworkError{
    static var networkConnectionFailure = "Problem with network connection"
    static var internetOffline = "URLSessionTask failed with error: A server with the specified hostname could not be found."
    static var noNetwork = "No Network connection"
}

enum ApiError: Error{
    case internalServerError
}


enum ApiErrorCodes: Int{
    case responseErrorCode = 100
    case parsingJsonErrorCode = 101
    case internalServerError = 102
    case success = 103
    case sessionTimedOut = 104
}

struct ErrorMessageResponse: Codable{
    let code: Int
    let message: String
}
