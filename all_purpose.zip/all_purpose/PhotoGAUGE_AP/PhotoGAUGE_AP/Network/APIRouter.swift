//
//  APIRouter.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation
import Alamofire

enum APIRouter: URLRequestConvertible {
    case login([String: Any])
    case refreshToken(String)
    case addPart([String: Any])
    case addInspectionJob([String: Any])
    case adMergePart([String: Any])
    case allParts([String: Any])
    case changePassword([String: Any])
    case forgotPassword(String)
    case eTag(String)
    case renmaePart([String: Any])
    case uploadVideo(data: Data, name: String, filename: String, path: String)
    case signUp([String: Any])
    case loginByUUID([String: Any])
    case updateCredentialsByUUID([String: Any])
    case videoTipsByMeasurement(String)
    
    // MARK: - HTTPMethod
    private var method: HTTPMethod {
        switch self {
        case .login:
            return .post
        case .refreshToken:
            return .get
        case .addPart:
            return .post
        case .addInspectionJob:
            return .post
        case .adMergePart:
            return .post
        case .allParts:
            return .get
        case .changePassword:
            return .post
        case.forgotPassword:
            return .get
        case .eTag:
            return .get
        case .renmaePart:
            return .post
        case .uploadVideo:
            return .post
        case .signUp:
            return .post
        case .loginByUUID:
            return .post
        case .updateCredentialsByUUID:
            return .post
        case .videoTipsByMeasurement:
            return .get
        }
    }
    
    // MARK: - Path
    private var path: String {
        // fetch serverurl strings
        switch self {
        case .login:
            return "pgRestServices/pg/rest/v1/login"
        case .refreshToken(let token):
            return "pgRestServices/pg/rest/v1/refreshToken/\(token)"
        case .addPart:
            return "pgRestServices/pg/rest/v1/part/mergePart"
        case .addInspectionJob:
            return "pgRestServices/pg/rest/v1/job/addInspectionJobV2"
        case .adMergePart:
            return "pgRestServices/pg/rest/v1/part/mergePartUnit"
        case .allParts:
            return "pgRestServices/pg/rest/v1/part/getAllCompanyPartsOffline"
        case .changePassword:
            return "pgRestServices/pg/rest/v1/user/changePassword"
        case .forgotPassword(let emailID):
            return "pgRestServices/pg/rest/v1/forgotPassword/\(emailID)"
        case .eTag(let tagID):
            return "pgRestServices/pg/rest/v1/part/getAllCompanyPartsOfflineWithEtag/\(tagID)"
        case .renmaePart:
            return "pgRestServices/pg/rest/v1/part/mergePart"
        case .uploadVideo:
            return "pgRestServices/fileController/uploadS3"
        case .signUp:
            return "pgRestServices/pg/rest/v1/signUpByUUID"
        case .loginByUUID:
            return "pgRestServices/pg/rest/v1/loginByUUID"
        case .updateCredentialsByUUID:
            return "pgRestServices/pg/rest/v1/updateCredentialsByUUID"
        case .videoTipsByMeasurement(let measurementType):
            return "pgRestServices/pg/rest/v1/training/getTipsVideoByMeasurementType/\(measurementType)"
        }
    }
    
    // MARK: - Parameters
    private var parameters: Parameters? {
        switch self {
        case .login(let body):
            return body
        case .refreshToken:
            return nil
        case .forgotPassword:
            return nil
        case .addPart(let body):
            return body
        case .addInspectionJob(let body):
            return body
        case .adMergePart(let body):
            return body
        case .allParts:
            return nil
        case .changePassword(let body):
            return body
        case .eTag:
            return nil
        case .renmaePart(let body):
            return body
        case .uploadVideo:
            return nil
        case .signUp(let body):
            return body
        case .loginByUUID(let body):
            return body
        case .updateCredentialsByUUID(let body):
            return body
        case .videoTipsByMeasurement:
            return nil
        }
    }
    
    private var headers: HTTPHeaders{
        if let token = UserSession.shared.getUserData()?.authToken{
        let authToken = "Bearer \(token)"
            return HTTPHeaders([HTTPHeader(name: "Authorization", value: authToken)])
        }else{
            return HTTPHeaders()
        }
    }
    
    func getServerURL() -> String {
        if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_PRODUCTION {
            return(NetworkConstants.Server.BASE_URL_PRODUCTION)
        } else if helperGetEnvironment() == ENVIRONMENT.ENVIRONMENT_QA {
            return(NetworkConstants.Server.BASE_URL_QA)
        } else {
            return(NetworkConstants.Server.BASE_URL_DEV)
        }
    }
    
    
    
    // MARK: - URLRequestConvertible
    func asURLRequest() throws -> URLRequest {
        
        var urlString = ""
        urlString = getServerURL()
        
        let url = try urlString.asURL()
        var urlRequest = URLRequest(url: url.appendingPathComponent(path))
        
        // HTTP Method
        urlRequest.httpMethod = method.rawValue
        
        // Common Headers
        urlRequest.headers = headers
        urlRequest.setValue(ContentType.json.rawValue, forHTTPHeaderField: HTTPHeaderField.acceptType.rawValue)
        urlRequest.setValue(ContentType.json.rawValue, forHTTPHeaderField: HTTPHeaderField.contentType.rawValue)
        
        //LogConfig.logD(message:"Request Parameters -   : \(self.parameters ?? [:])", displayToThirdParty: true)
        
        // Parameters
        if let parameters = parameters {
            do {
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            } catch {
                throw AFError.parameterEncodingFailed(reason: .jsonEncodingFailed(error: error))
            }
        }
        
        return urlRequest
    }
    
    // MARK: MultipartFormData
        var multipartFormData: MultipartFormData {
            let multipartFormData = MultipartFormData()
            switch self {
            case .uploadVideo(let data, let name, let filename, let path):
                multipartFormData.append(data, withName: name, fileName: filename, mimeType: "video/mp4")
                multipartFormData.append(path.data(using: .utf8)!, withName: "path")
            default: ()
            }

            return multipartFormData
        }
}
