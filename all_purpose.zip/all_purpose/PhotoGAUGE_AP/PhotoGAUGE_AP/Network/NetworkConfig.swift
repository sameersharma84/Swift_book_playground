//
//  NetworkConfig.swift
//  PhotoGAUGE_AP
//
//  Created by apple on 04/05/22.
//

import Foundation

import Alamofire

class NetworkConfig {

  static let APIManager: Session = {
      let configuration = URLSessionConfiguration.default
      configuration.timeoutIntervalForRequest = 60
      let delegate = Session.default.delegate
      let manager = Session.init(configuration: configuration,
                                 delegate: delegate,
                                 startRequestsImmediately: true,
                                 cachedResponseHandler: nil)
      return manager
  }()
}
