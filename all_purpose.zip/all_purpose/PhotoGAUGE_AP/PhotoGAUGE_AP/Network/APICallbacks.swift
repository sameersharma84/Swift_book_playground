//
//  APICallbacks.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation

// MARK: Request Ids

enum RequestId : Int {
    
    case RID_LOGIN
    case RID_CREATE_ACCOUNT
    case RID_FORGOT_PASSWORD
    case RID_CHANGE_PASSWORD
    case RID_GET_ALL_COMPANY_PARTS_OFFLINE
    case RID_ADD_PART
    case RID_GET_ALL_COMPANY_PARTS_WITH_ETAG
    case RID_RENAME_PART
    case RID_GET_PART_UNIT_BY_ID
    case RID_VERIFY_UNIT_NAME
    case RID_GET_PART_BY_ID
    case RID_MERGE_PART_UNIT
    case RID_ADD_INSPECTION_JOB
    case RID_RENAME_PART_UNIT
    case RID_CHECK_NW_CONNECTED
    case RID_REFRESH_TOKEN
    case RID_GET_ALL_ROOMS
}

// MARK: ServerWrapperDelegate

protocol ServerWrapperDelegate : AnyObject {
    
    // required
    func requestFailed(_ requestId: RequestId, errorInfo: ErrorMessageResponse)
    // optional
    func loggedIn(_ results: LoginResponse)
    func newTokenRecieved(_ results: LoginResponse)
    func newPartAdded(_ results: AddPartResponse)
    func inspectionJobAdded(_ results: AddInspectionJobResponse)
    func allPartsRecieved(_ results: AllPartData)
    func partUnitMerged(_ results: MergePartResponse)
    func passwordChanged(_ results: PasswordResponse)
    func passwordRecovered(_ results: PasswordResponse)
    func allPartsWithEtagRecieved(_ results: EtagResponse)
    func partRenamed(_ results: RenamePartResponse)
    func accountCreated(_ results: [String:Any])
    func partUnitByIdRecieved(_ results: [String:Any])
    func unitDisplayNameVerified (_ results: [String: Any])
    func partByIdRecieved(_ results: [String:Any])
    func getETagDelegate() -> ETagDelegate?
    func partUnitRenamed(_ results: [String:Any])
    func checkedIfNetConnected(_ results: [String:Any])
    func allRoomsRecieved(_ results: [Any])
    func signUpSuccess(_ results: SignUpResponse)
    func videoTipsUrlReceive(_ results: VideoTipsByMeasurement)
}

protocol ETagDelegate : AnyObject {
    func allPartsWithEtagRecieved(_ results: EtagResponse)
}

// MARK: ServerWrapperDelegate Extension

extension ServerWrapperDelegate {
    func loggedIn(_ results: LoginResponse) {}
    func newPartAdded(_ results: AddPartResponse) {}
    func inspectionJobAdded(_ results: AddInspectionJobResponse) {}
    func partUnitMerged(_ results: MergePartResponse) {}
    func newTokenRecieved(_ results: LoginResponse) {}
    func allPartsRecieved(_ results: AllPartData) {}
    func passwordChanged(_ results: PasswordResponse) {}
    func allPartsWithEtagRecieved(_ results: EtagResponse) {}
    func accountCreated(_ results: [String:Any]) {}
    func passwordRecovered(_ results: PasswordResponse) {}
    func partRenamed(_ results: RenamePartResponse) {}
    func partUnitByIdRecieved(_ results: [String:Any]) {}
    func unitDisplayNameVerified (_ results: [String: Any]) {}
    func partByIdRecieved(_ results: [String:Any]) {}
    func getETagDelegate() -> ETagDelegate? { return nil }
    func partUnitRenamed(_ results: [String:Any]){}
    func checkedIfNetConnected(_ results: [String:Any]){}
    func allRoomsRecieved(_ results: [Any]) {}
    func signUpSuccess(_ results: SignUpResponse) {}
    func videoTipsUrlReceive(_ results: VideoTipsByMeasurement){}
   
}


