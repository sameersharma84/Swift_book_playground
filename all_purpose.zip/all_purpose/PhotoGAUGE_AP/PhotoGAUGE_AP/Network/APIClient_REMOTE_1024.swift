//
//  APIClient.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation
import Alamofire

class APIClient {
    static weak var delegate: ServerWrapperDelegate?
    static var errorResponse = ErrorMessageResponse(code: 0, message: "")
    
    @discardableResult
    private static func performRequest<T:Decodable>(route:APIRouter, decoder: JSONDecoder = JSONDecoder(), completion:@escaping (Result<T, AFError>)->Void) -> DataRequest {
        return AF.request(route)
            .responseDecodable (decoder: decoder){ (response: DataResponse<T, AFError>) in
                completion(response.result)
            }
    }
    
    
    
    static func login(request: LoginRequest) {
        var dataDict = [String: Any]()
        if request.dictionary != nil{
            dataDict = request.dictionary!
        }
        //        performRequest(route: APIRouter.login(dataDict)) { (result: Result<LoginResponse, AFError>) in
        //            switch result {
        //            case .success(let success):
        //                self.delegate?.loggedIn(success)
        //                break
        //            case .failure(let failure):
        //                handleErrorResponse(error: failure, logError: "loginError", requestID: RequestId.RID_LOGIN, errorCode: code)
        //            }
        //        }
        
        performTheRequest(route: APIRouter.login(dataDict)) { (code, result: Result<LoginResponse, AFError>?)  in
            if let response = result{
                switch response {
                case .success(let success):
                    self.delegate?.loggedIn(success)
                    break
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "loginError", requestID: RequestId.RID_LOGIN,errorCode: code )
                }
            }
        }
    }
    
    static func getNewToken() {
        if let refreshToken = UserSession.shared.getUserData()?.refreshToken{
            Logger.debug("\n\n ######URL : Get New Token URL called \n \n ")
            performTheRequest(route: APIRouter.refreshToken(refreshToken)) { (code, result: Result<LoginResponse, AFError>?) in
                if let result = result{
                    switch result {
                    case .success(let success):
                        //                self.delegate?.newTokenRecieved(success)
                        UserSession.shared.setUserData(data: success)
                        break
                    case .failure(let failure):
                        handleErrorResponse(error: failure, logError: "getNewToken", requestID: RequestId.RID_REFRESH_TOKEN, errorCode: code)
                    }
                }
            }
        }
    }
    
    static func addPart(request: AddPartRequest){
        var dataDict = [String: Any]()
        if request.dictionary != nil{
            dataDict = request.dictionary!
        }
        performTheRequest(route: APIRouter.addPart(dataDict)) { (code, result: Result<AddPartResponse, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    self.delegate?.newPartAdded(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "addPart", requestID: RequestId.RID_ADD_PART, errorCode: code)
                }
            }
        }
    }
    
    static func mergePart(request: [String: Any]){
        performTheRequest(route: APIRouter.adMergePart(request)) { (code, result: Result<MergePartResponse, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    print(success)
                    self.delegate?.partUnitMerged(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "mergePart", requestID: RequestId.RID_MERGE_PART_UNIT, errorCode: code)
                }
            }
        }
    }
    
    static func adInspectionJob(request: AddInspectionJobRequest){
        var dataDict = [String: Any]()
        if request.dictionary != nil{
            dataDict = request.dictionary!
        }
        performTheRequest(route: APIRouter.addInspectionJob(dataDict)) { (code, result: Result<AddInspectionJobResponse, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    self.delegate?.inspectionJobAdded(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "addInspectionJob", requestID: RequestId.RID_ADD_INSPECTION_JOB, errorCode: code)
                }
                
            }
        }
    }
    
    static func changePassword(request: PasswordRequest){
        var dataDict = [String: Any]()
        if request.dictionary != nil{
            dataDict = request.dictionary!
        }
        performTheRequest(route: APIRouter.changePassword(dataDict)) { (code, result: Result<PasswordResponse, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    self.delegate?.passwordChanged(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "changePassword", requestID: RequestId.RID_CHANGE_PASSWORD, errorCode: code)
                }
            }
        }
    }
    
    static func getAllParts(){
        performTheRequest(route: APIRouter.allParts([:])) { (code, result: Result<AllPartData, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    self.delegate?.allPartsRecieved(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "getAllParts", requestID: RequestId.RID_GET_ALL_COMPANY_PARTS_OFFLINE, errorCode: code)
                }
            }
        }
    }
    
    static func forgotPassword(for emailID: String){
        performTheRequest(route: APIRouter.forgotPassword(emailID)) { (code, result: Result<PasswordResponse, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    self.delegate?.passwordRecovered(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "forgotPassword", requestID: RequestId.RID_FORGOT_PASSWORD, errorCode: code)
                }
            }
        }
    }
    
    static func getAllPartsWithEtag(etag: String){
        let etagStr = etag.stringByAddingPercentEncodingForRFC3986()
        performTheRequest(route: APIRouter.eTag(etagStr)) { (code, result: Result<EtagResponse, AFError>?) in
            if let result = result{
                switch result {
                case .success(let success):
                    self.delegate?.allPartsWithEtagRecieved(success)
                case .failure(let failure):
                    handleErrorResponse(error: failure, logError: "getAllPartsWithEtag", requestID: RequestId.RID_GET_ALL_COMPANY_PARTS_OFFLINE, errorCode: code)
                }
            }
        }
    }
    
    static func handleErrorResponse(error: AFError, logError: String, requestID: RequestId, errorCode: ApiErrorCodes){
//        let errorString = error.localizedDescription
//        helperGetAppDeleate().showAlert(titleStr: "", msg: errorString)
//        let errorType = error as Error
//        let validErro = decodingErrorDescription(error: errorType)
//        print(validErro)
        
        //        if error == "URLSessionTask failed with error: The request timed out." {
        //            helperGetAppDeleate().showAlert(titleStr: "", msg: NetworkError.networkConnectionFailure)
        //        } else if error == "URLSessionTask failed with error: The Internet connection appears to be offline." {
        //            helperGetAppDeleate().showAlert(titleStr: "", msg: NetworkError.noNetwork)
        //        } else if error == "URLSessionTask failed with error: A server with the specified hostname could not be found." {
        //            helperGetAppDeleate().showAlert(titleStr: "", msg: NetworkError.noNetwork)
        //        }
        
        
        switch errorCode {
        case .responseErrorCode:
            break
        case .parsingJsonErrorCode:
            errorResponse = ErrorMessageResponse(code: 1001, message: "Parsing error")
        case .internalServerError:
            errorResponse = ErrorMessageResponse(code: 1001, message: str_server_error_msg)
        case .success:
            errorResponse = ErrorMessageResponse(code: 200, message: "Sucess")
        }
        
        
        self.delegate?.requestFailed(requestID, errorInfo:  errorResponse)
        Logger.debug("\(logError) error: \(String(describing: error))")
        helperGetAppDeleate().hideActivityView()
    }
    
    
    
    static func decodingErrorDescription(error: Error)->APIError{
        if let error = error as? DecodingError {
            var errorToReport = error.localizedDescription
            switch error {
            case .dataCorrupted(let context):
                let details = context.underlyingError?.localizedDescription ?? context.codingPath.map { $0.stringValue }.joined(separator: ".")
                errorToReport = "\(context.debugDescription) - (\(details))"
            case .keyNotFound(let key, let context):
                let details = context.underlyingError?.localizedDescription ?? context.codingPath.map { $0.stringValue }.joined(separator: ".")
                errorToReport = "\(context.debugDescription) (key: \(key), \(details))"
            case .typeMismatch(let type, let context), .valueNotFound(let type, let context):
                let details = context.underlyingError?.localizedDescription ?? context.codingPath.map { $0.stringValue }.joined(separator: ".")
                errorToReport = "\(context.debugDescription) (type: \(type), \(details))"
            @unknown default:
                break
            }
            return .decodingError(errorToReport)
        }  else {
            return .decodingError(error.localizedDescription )
        }
    }
    
    
    
    enum APIError: Error{
        case decodingError(String)
        case httpError
        case unknown(String)
    }
}


extension APIClient{
    @discardableResult
    private static func performTheRequest<T:Decodable>(route:APIRouter, decoder: JSONDecoder = JSONDecoder(), completion:@escaping (ApiErrorCodes, AFResult<T>?)->Void) -> DataRequest {
        
        return AF.request(route)
            .responseData { responseData in
                guard let response = responseData.response else {
                    completion(.internalServerError, nil)
                    return
                }
                print("RESPONSE DATA: \(responseData.result)")
                
                switch response.statusCode {
                case 200...299 : //This case will parse the T type.
                    
                    guard let data = responseData.data else {
                        completion(.responseErrorCode, nil)
                        return
                    }
                    
                    do {
                        let responseCodableObject = try decoder.decode(T.self, from: data)
//                        print("responseCodableObject: \(responseCodableObject)")
                        completion(.success,.success(responseCodableObject))
                    } catch let error {
                        print("Parsing Error: \(error)")
                        completion(.parsingJsonErrorCode, .failure(AFError.responseSerializationFailed(reason: AFError.ResponseSerializationFailureReason.jsonSerializationFailed(error: error))))
                    }
                    
                case 400: //This case will parse the ErrorMessageResponse type
                    
                    guard let data = responseData.data else {
                        completion(.internalServerError, nil)
                        return
                    }
                    do {
                        let errorMessage = try decoder.decode(ErrorMessageResponse.self, from: data)
                        print("errorMessage: \(errorMessage)")
                        errorResponse = errorMessage
                        completion(.responseErrorCode, .failure(AFError.explicitlyCancelled))
                    } catch let error {
                        print("Parsing Error: \(error)")
                        completion(.parsingJsonErrorCode,
                                   .failure( AFError.responseSerializationFailed(reason: AFError.ResponseSerializationFailureReason.jsonSerializationFailed(error: error))))
                    }
                    
                default:
                    completion(.internalServerError,.failure(AFError.sessionDeinitialized))
                }
            }
//            .responseString { response in
//                print("response in string format \(response)")
//            }
    }
}
