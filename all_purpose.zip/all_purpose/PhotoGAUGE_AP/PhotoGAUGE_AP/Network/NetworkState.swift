//
//  NetworkState.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation
import Alamofire

class NetworkState {
    class func isConnected() -> Bool {
        return NetworkReachabilityManager()!.isReachable
    }
}
