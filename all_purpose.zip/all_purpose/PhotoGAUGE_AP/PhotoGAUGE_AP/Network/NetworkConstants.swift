//
//  NetworkConstants.swift
//  PhotoGAUGE_AP
//
//  Created by Surbhi Lath on 26/11/21.
//

import Foundation

struct NetworkConstants {
    struct Server {
        static let BASE_URL_PRODUCTION = "https://app.photogauge.com/"
        static let BASE_URL_QA = "https://qa.photogauge.com/"
        static let BASE_URL_DEV = "https://dev.photogauge.com/"
    }
    
}

enum HTTPHeaderField: String {
    case authentication = "Authorization"
    case contentType = "Content-Type"
    case acceptType = "Accept"
    case acceptEncoding = "Accept-Encoding"
}

enum ContentType: String {
    case json = "application/json"
}

enum ENVIRONMENT : Int {
    case ENVIRONMENT_PRODUCTION = 100
    case ENVIRONMENT_QA = 101
    case ENVIRONMENT_DEV = 102
}

let HTTP_STATUS_CODE_200 = 200
let HTTP_STATUS_CODE_10001 = 10001

let REQUEST_TIMEOUT_30: TimeInterval = 30
let REQUEST_TIMEOUT_60: TimeInterval = 60

